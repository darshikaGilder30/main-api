#!/bin/bash
# Swtich app directory and run deploy script. Get deployment environment from command line argument.
# Usage: ./deploy.sh [environment]
# Example: ./deploy.sh dev
# Example: ./deploy.sh production
# Example: ./deploy.sh staging

# Get deployment environment from command line argument
ENV=$1

# List of apps folders

declare -a apps=("levis-theme-app" "levis-cart-trackorder" "levis-checkout-ui" "levis-myaccount" "levis-proxy-functions" "levis-find-in-store")

# Loop through apps folders and run deploy script

for app in "${apps[@]}"

do
  # Switch app directory
  cd $app

  # Run deploy script

  if [ "$ENV" = "dev" ]; then
    echo "Deploying to dev environment..."
    npm run deploy:dev -- -f
  elif [ "$ENV" = "production" ]; then
    echo "Deploying to prod environment..."
    npm run deploy:production -- -f
  elif [ "$ENV" = "staging" ]; then
    echo "Deploying to stage environment..."
    npm run deploy:staging -- -f
  else
    echo "Invalid environment. Please specify dev, prod, test, qa, or stage."
  fi

  # Switch back to root directory
  cd ..
done