import {
  useApi,
  useTranslate,
  reactExtension,
  View,
  Button,
  BlockStack,
  InlineSpacer,
  BlockSpacer,
  Modal,
  Form,
  Grid,
  GridItem,
  TextField,
  useApplyMetafieldsChange,
  useMetafields,
} from "@shopify/ui-extensions-react/checkout";
import { useEffect, useState } from "react";

export default reactExtension("purchase.checkout.block.render", () => (
  <Extension />
));

function Extension() {
  const translate = useTranslate();
  const { ui } = useApi();
  const [taxIDError, setTaxIDError] = useState(null);
  const metas = useMetafields();
  const [taxAddress, setTaxAddress] = useState("");
  const [taxID, setTaxID] = useState("");
  const applyMetafieldsChange = useApplyMetafieldsChange();
  useEffect(() => {
    const taxAddressValue = metas.filter(
      (value) => value.key === "tax_address"
    )[0];
    if (taxAddressValue?.value) {
      setTaxAddress(`${taxAddressValue.value}`);
    }
    const taxIdValue = metas.filter((value) => value.key === "tax_id")[0];
    if (taxIdValue?.value) {
      setTaxID(`${taxIdValue.value}`);
    }
  }, []);

  const handleSubmit = () => {
    setTaxIDError(null);
    if (taxID?.trim().length === 13) {
      applyMetafieldsChange({
        key: "tax_id",
        namespace: "custom",
        type: taxID.length ? "updateMetafield" : "removeMetafield",
        value: taxID,
        valueType: "string",
      });
      applyMetafieldsChange({
        key: "tax_address",
        namespace: "custom",
        type: taxAddress.length ? "updateMetafield" : "removeMetafield",
        value: taxAddress,
        valueType: "string",
      });
      ui.overlay.close("tax-modal");
    } else {
      setTaxIDError(translate("taxIDError"));
    }
    console.log("Submitted!=>", taxAddress, taxID);
  };

  const renderModal = () => (
    <Modal id="tax-modal" padding title={translate("taxInformation")}>
      <Form
        onSubmit={() => {
          handleSubmit();
        }}
      >
        <Grid columns={["100%"]} spacing="base">
          <GridItem>
            <TextField
              label={translate("taxAddress")}
              value={taxAddress}
              onChange={setTaxAddress}
            />
          </GridItem>
          <GridItem>
            <TextField
              label={translate("taxID")}
              value={taxID}
              onChange={setTaxID}
              maxLength={13}
              multiline={false}
              required
              error={taxIDError}
            />
          </GridItem>
        </Grid>
        <BlockSpacer />

        <Grid columns={["45%", "fill"]} spacing="base">
          <View border="none" padding="none"></View>
          <View border="none" padding="none">
            <Button accessibilityRole="submit" appearance="monochrome">
              <InlineSpacer spacing="loose" />
              {translate("save")}
              <InlineSpacer spacing="loose" />
            </Button>
          </View>
        </Grid>
      </Form>
    </Modal>
  );

  return (
    <BlockStack>
      <View>
        <Button appearance="monochrome" overlay={renderModal()}>
          {translate("taxInvoiceRequest")}
        </Button>
      </View>
    </BlockStack>
  );
}
