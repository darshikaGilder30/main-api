import {
  reactExtension,
  useBuyerJourneyIntercept,
  useTranslate,
  useShippingAddress,
} from "@shopify/ui-extensions-react/checkout";

export default reactExtension("purchase.checkout.block.render", () => (
  <Extension />
));

function Extension() {
  const { city,address2 } = useShippingAddress();
  
  const translate = useTranslate();
  useBuyerJourneyIntercept(async () => {
    if (!city?.length||!address2?.length) {
      return {
        behavior: "block",
        reason: "addressNotCompleted",
        errors: [
          {
            message: translate(!city?.length&&!address2?.length?'cityDistrictRequired':!city?.length?'cityRequired':'districtRequired'),
          },
        ],
      };
    }

    return { behavior: "allow" };
  });

  return null;
}
