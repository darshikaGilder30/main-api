import {
  reactExtension,
  View,
  TextBlock,
  Heading,
  TextField,
  Button,
  InlineLayout,
  InlineSpacer,
  BlockSpacer,
  Link,
  BlockStack,
  useSelectedPaymentOptions,
  useTranslate,
  useShippingAddress,
  Popover,
  useApi,
  useApplyAttributeChange,
  Banner,
} from "@shopify/ui-extensions-react/checkout";
import { useEffect, useState } from "react";

export default reactExtension("purchase.checkout.block.render", () => (
  <Extension />
));

function Extension() {
  const options = useSelectedPaymentOptions();
  const translate = useTranslate();
  const { sessionToken, ui, shop, attributes } = useApi();
  const { phone } = useShippingAddress();
  const [otp, setOtp] = useState("");
  const [showOtpSentMessage, setShowOtpSentMessage] = useState(false);
  const [otpError, setOtpError] = useState(null);
  const [loading, setLoading] = useState(false);
  const appllyAttributeChange = useApplyAttributeChange();
  const [phoneNumber, setPhoneNumber] = useState(phone);
  useEffect(() => {
    setPhoneNumber(phone);
    const optVerified = attributes.current.filter(
      (t) => t.key === "_otp_verified"
    );
    console.log(
      "phone===>",
      phone,
      attributes,
      attributes.current.filter(
        (t) => t.key === "_otp_verified" && t?.value === `${phone}`
      ).length
    );
    if (optVerified.length && optVerified[0].value !== `${phone}`) {
      appllyAttributeChange({
        type: "updateAttribute",
        key: "_otp_verified",
        value: "",
      });
    }
  }, [phone]);

  const sendOTP = (value, resend) => {
    sessionToken.get().then((token) => {
      if (!value?.length) {
        return;
      }
      const requestData = {
        username: value,
      };
      var requestOptions = {
        method: "POST",
        body: JSON.stringify(requestData),
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          Authorization: `Bearer ${token}`,
        },
      };

      fetch(
        `${shop.storefrontUrl}/apps/levis-custom-api/shopify-proxy-otp/send-otp`,
        requestOptions
      )
        .then((response) => {
          response
            .json()
            .then((data) => {
              if (data.data) {
                if(resend){
                  setShowOtpSentMessage(true);
                  setTimeout(() => {
                    setShowOtpSentMessage(false);
                  }, 5000);
                }
              } else {
                setOtpError(data.message);
              }
            })
            .catch(() => {})
            .finally(() => {});
        })
        .catch((error) => {
          console.error(error);
        })
        .finally(() => {});
    });
  };
  const handleSubmit = () => {
    setOtpError(null);
    sessionToken.get().then((token) => {
      if (!otp?.length) {
        setOtpError(translate("otpRequired"));
        return;
      }
      const requestData = {
        username: phoneNumber,
        otp: otp,
      };
      var requestOptions = {
        method: "POST",
        body: JSON.stringify(requestData),
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          Authorization: `Bearer ${token}`,
        },
      };
      setLoading(true);
      fetch(
        `${shop.storefrontUrl}/apps/levis-custom-api/shopify-proxy-otp/verify-otp`,
        requestOptions
      )
        .then((response) => {
          response
            .json()
            .then((data) => {
              console.log("data.data.message", data);
              if (data.data) {
                appllyAttributeChange({
                  type: "updateAttribute",
                  key: "_otp_verified",
                  value: `${phoneNumber}`,
                });
                ui.overlay.close("otp-verification");
              } else {
                setOtpError(data.message);
              }
            })
            .catch(() => {})
            .finally(() => {
              setLoading(false);
            });
        })
        .catch((error) => {
          console.error(error);
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const renderPhoneNumber = () => {
    if (phoneNumber?.length) {
      return (
        <TextBlock>
          {translate("otpMessage", {
            phone: phoneNumber.slice(
              phoneNumber.length - 4,
              phoneNumber.length
            ),
          })}
        </TextBlock>
      );
    }
    return null;
  };

  const renderModal = () => (
    <Popover
      id="otp-verification"
      onOpen={() => {
        sendOTP(phoneNumber, false);
      }}
    >
      <BlockStack>
        <View maxInlineSize={350} padding="base">
          <Heading>{translate("twoStepVerification")}</Heading>
          <BlockSpacer spacing="none" />
          {renderPhoneNumber()}
          <BlockSpacer spacing="base" />

          <InlineLayout columns={["70%", "fill"]}>
            <View padding="none">
              <TextField
                label={translate("enterOTP")}
                value={otp}
                onChange={(value) => setOtp(value)}
                icon="lock"
                required
                error={otpError}
              />
            </View>
            <View padding="none">
              <InlineSpacer spacing="base" />
              <Button
                appearance="monochrome"
                onPress={handleSubmit}
                loading={loading}
              >
                {translate("submit")}
              </Button>
            </View>
          </InlineLayout>
          <BlockSpacer spacing="base" />
          <Link
            to=""
            onPress={() => {
              sendOTP(phoneNumber, true);
            }}
          >
            {translate("didntReceiveTheCode")}
          </Link>
          {showOtpSentMessage ? (
            <Banner status="success" title={translate('otpSuccess')} />
          ) : null}
        </View>
      </BlockStack>
    </Popover>
  );
  if (options.some((option) => option.type === "paymentOnDelivery")) {
    return (
      <>
        {attributes.current.filter(
          (t) => t.key === "_otp_verified" && t?.value === `${phoneNumber}`
        ).length ? null : (
          <Button appearance="critical" overlay={renderModal()}>
            {translate("verifyOtp")}
          </Button>
        )}
      </>
    );
  }

  return null;
}
