import {
  reactExtension,
  useAppliedGiftCards,
  useBuyerJourneyIntercept,
  useApplyGiftCardChange,
  useSettings,
  Banner,
  useTranslate,
  useAvailablePaymentOptions,
  useApi,
} from "@shopify/ui-extensions-react/checkout";
import { AppliedGiftCard } from "@shopify/ui-extensions/src/surfaces/checkout";

// Define the extension
export default reactExtension("purchase.checkout.block.render", () => (
  <Extension />
));

function Extension() {
  const giftCards = useAppliedGiftCards();
  const translate = useTranslate();
  const changeGiftCard = useApplyGiftCardChange();
  const paymentMethods = useAvailablePaymentOptions();
  const settings = useSettings();
  const { cost, i18n } = useApi();
  const subtotal = cost.subtotalAmount.current.amount;
  const maxGiftCardCount = +settings.max_gift_card_count || 2;
  const minOrderAmount = +settings.min_order_amount || 0;

  const restrictGiftCardCount = (giftCards: AppliedGiftCard[]) => {
    if (maxGiftCardCount && giftCards.length > maxGiftCardCount) {
      const giftCardsToRemove = giftCards.slice(maxGiftCardCount);
      giftCardsToRemove.forEach((giftCard) => {
        changeGiftCard({
          type: "removeGiftCard",
          code: giftCard.lastCharacters,
        })
          .then((result) => {
            console.log("Gift card removed:", giftCard.lastCharacters, result);
          })
          .catch((error) => {
            console.error("Failed to remove gift card:", error);
          });
      });
    }
  };

  // useEffect(() => {
  //   restrictGiftCardCount(giftCards);
  // }, [giftCards]);

  // Intercept buyer journey
  useBuyerJourneyIntercept(({ canBlockProgress }) => {
    if (maxGiftCardCount && giftCards.length > maxGiftCardCount) {
      // Block progress to ensure the gift card removal process completes
      if (canBlockProgress) {
        return {
          behavior: "block",
          reason: translate("maxGiftCardCount", {
            maxGiftCardCount,
          }),
          perform: () => {},
        };
      }
    }

    // Allow progress if no conditions are met
    return {
      behavior: "allow",
      perform: () => {},
    };
  });

  if (
    !paymentMethods.find(
      (paymentMethod) => paymentMethod.type === "redeemable"
    ) &&
    minOrderAmount &&
    subtotal < minOrderAmount
  ) {
    return (
      <Banner
        status="warning"
        title={translate("giftCardPaymentWarning", {
          minOrderAmount: i18n.formatCurrency(
            minOrderAmount
          ),
        })}
      />
    );
  }

  // show error message if gift card count exceeds the limit using shopify-ui-extensions
  return maxGiftCardCount && giftCards.length > maxGiftCardCount ? (
    <Banner
      status="warning"
      title={translate("maxGiftCardCount", {
        maxGiftCardCount,
      })}
    />
  ) : null;
}
