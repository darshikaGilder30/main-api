import {
  reactExtension,
  Link,
  useTranslate,
  Checkbox,
  Text,
  View,
  useApplyAttributeChange,
  useApi,
} from "@shopify/ui-extensions-react/checkout";
import { useEffect, useState } from "react";

export default reactExtension("purchase.checkout.block.render", () => (
  <Extension />
));

function Extension() {
  const translate = useTranslate();
  const {shop} =useApi()
  const appllyAttributeChange = useApplyAttributeChange();
  const [checked, setChecked] = useState(true);

  useEffect(() => {
    appllyAttributeChange({
      type: "updateAttribute",
      key: "_terms_conditions_accepted",
      value: `${checked ? 1 : 0}`,
    });
  }, [checked]);

  return (
    <View>
      <Checkbox
        id="checkbox"
        name="checkbox"
        checked={checked}
        onChange={(value) => {
          setChecked(value);
        }}
      >
        {translate("message")}
        {' '}<Link external to={`${shop.storefrontUrl}${translate("url")}`}>{translate("termsAndConditions")}</Link> {' '} 
        {translate("messageEnd")}
      </Checkbox>
    </View>
  );
}
