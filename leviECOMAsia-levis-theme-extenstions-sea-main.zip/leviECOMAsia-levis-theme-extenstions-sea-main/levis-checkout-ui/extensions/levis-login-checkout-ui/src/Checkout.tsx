import {
  Banner,
  useApi,
  useTranslate,
  reactExtension,
  Link,
  BlockStack,
} from "@shopify/ui-extensions-react/checkout";

export default reactExtension("purchase.checkout.block.render", () => (
  <Extension />
));

function Extension() {
  const translate = useTranslate();
  const { shop, buyerIdentity } = useApi();

  return !buyerIdentity.customer?.current?.id ? (
    <BlockStack>
      <Banner status="critical" title="Already a registered user">
        <Link to={`${shop.storefrontUrl}/account/login`}>{translate('loginHere')}</Link>
      </Banner>
    </BlockStack>
  ) : null;
}
