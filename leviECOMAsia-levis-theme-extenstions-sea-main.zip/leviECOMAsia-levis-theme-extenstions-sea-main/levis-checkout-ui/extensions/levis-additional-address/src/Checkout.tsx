import {
  useApi,
  reactExtension,
  Select,
  useTranslate,
  useApplyShippingAddressChange,
  useShippingAddress,
  View,
  BlockStack,
} from "@shopify/ui-extensions-react/checkout";

import { useEffect, useState } from "react";
import { getCity, getDisticts } from "./districts";

export default reactExtension(
  "purchase.checkout.delivery-address.render-after",
  () => <Extension />
);

function Extension() {
  const { shippingAddress } = useApi();
  const { provinceCode } = useShippingAddress();
  const [district, setDistrict] = useState("");
  const [selectedCity, setSelectedCity] = useState(
    shippingAddress?.current.city || ""
  );
  const [districts, setDistricts] = useState([]);
  const [cities, setCities] = useState([]);
  const translate = useTranslate();
  const applyShippingAddressChange = useApplyShippingAddressChange();

  const districtChange = async (value) => {
    await applyShippingAddressChange({
      type: "updateShippingAddress",
      address: {
        address2: value,
      },
    });
  };
  const cityChange = async (value) => {
    await applyShippingAddressChange({
      type: "updateShippingAddress",
      address: {
        city: value,
      },
    });
  };

  useEffect(() => {
    if (provinceCode) {
      setCities(
        getCity(
          shippingAddress?.current.countryCode,
          shippingAddress?.current.provinceCode
        ).map((a) => ({ ...a, label: a.city, value: a.city }))
      );
    }
  }, [provinceCode]);

  useEffect(() => {
    if (selectedCity) {
      setDistricts(
        getDisticts(shippingAddress?.current.countryCode, selectedCity).map(
          (a) => ({ ...a, label: a.district, value: a.district })
        )
      );
    }
  }, [selectedCity]);

  return (
    <BlockStack border="none">
      <View  padding="none">
        <Select
          key={"City"}
          label={translate("city")}
          value={selectedCity}
          onChange={(value) => {
          cityChange(value);
            setSelectedCity(value);
          }}
          options={cities}
        />
      </View>
      {selectedCity.length ? (
        <View  padding="none">
          <Select
            key={"district"}
            label={translate("district")}
            value={district}
            onChange={(value) => {
              districtChange(value);
              setDistrict(value);
            }}
            options={districts}
          />
        </View>
      ) : null}
    </BlockStack>
  );
}
