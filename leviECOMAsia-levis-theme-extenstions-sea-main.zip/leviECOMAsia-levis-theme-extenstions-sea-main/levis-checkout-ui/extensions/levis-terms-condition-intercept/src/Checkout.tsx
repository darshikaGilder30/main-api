import {
  useApi,
  reactExtension,
  useBuyerJourneyIntercept,
  useTranslate,
  useSelectedPaymentOptions,
} from "@shopify/ui-extensions-react/checkout";
import { useState } from "react";

export default reactExtension("purchase.checkout.block.render", () => (
  <Extension />
));

function Extension() {
  const {
    attributes,
  } = useApi();
  const translate = useTranslate();
  useBuyerJourneyIntercept(async () => {
    const otpVerified = attributes.current.filter(
      (t) => t.key === "_terms_conditions_accepted" && t.value != null&&t.value === '1'
    )[0];
    if (!otpVerified) {
      return {
        behavior: "block",
        reason: "termsNotAccepted",
        errors: [
          {
            // In addition, show an error at the page level
            message: translate('message'),
          },
        ],
      };
    }

    return { behavior: "allow" };
  });

  return null;
}
