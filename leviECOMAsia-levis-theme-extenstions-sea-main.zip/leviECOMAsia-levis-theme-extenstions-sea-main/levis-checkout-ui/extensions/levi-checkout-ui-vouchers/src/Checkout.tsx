import { useCallback, useEffect, useState } from "react";
import {
  Banner,
  useApi,
  reactExtension,
  View,
  Button,
  BlockStack,
  Divider,
  Modal,
  Spinner,
  useDiscountCodes,
  useTranslate,
  useApplyDiscountCodeChange,
  useCurrency,
} from "@shopify/ui-extensions-react/checkout";

import DiscountItem from "./DiscountItem";

export default reactExtension(
  "purchase.checkout.reductions.render-after",
  () => <Extension />
);

function Extension() {
  const { buyerIdentity, sessionToken, shop } = useApi();
  const translate = useTranslate();
  const currency = useCurrency()
  const applyDiscount = useApplyDiscountCodeChange();
  const appliedDiscounts = useDiscountCodes();
  const [defaultDiscounts, setDefaultDiscounts] = useState(appliedDiscounts);
  const [vouchers, setVoucherData] = useState({
    vouchers: [],
    loading: true,
    settings: { maxDiscountCodesApplyOnCheckout: 1 },
  });
  const [discount, setDiscount] = useState({
    loading: false,
    code: null,
    message: null,
  });

  const updateDiscounts = useCallback(async () => {
    const existingdiscounts = defaultDiscounts.filter((x) =>
      appliedDiscounts.some((y) => y.code === x.code)
    );
    const index = vouchers.settings?.maxDiscountCodesApplyOnCheckout || 1;
    let discountsList = existingdiscounts.splice(
      0,
      appliedDiscounts.length - Number(index)
    );

    const token = await sessionToken.get();

    if (!token) {
      return;
    }

    for (let i = 0; i < discountsList.length; i++) {
      await applyDiscount({
        type: "removeDiscountCode",
        code: discountsList[i].code,
      });
      await fetch(
        `${shop.storefrontUrl}/apps/levis-custom-api/shopify-proxy-discount/remove-voucher`,
        {
          method: "POST",
          body: JSON.stringify({
            code: discountsList[i].code,
          }),
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );
    }
    setDefaultDiscounts(appliedDiscounts);
  }, [appliedDiscounts, defaultDiscounts, vouchers.settings]);

  useEffect(() => {
    if (
      appliedDiscounts.length >
      vouchers.settings?.maxDiscountCodesApplyOnCheckout
    ) {
      updateDiscounts();
    } else {
      setDefaultDiscounts(appliedDiscounts);
    }
  }, [appliedDiscounts]);

  const getVouchers = useCallback(() => {
    sessionToken.get().then((token) => {
      if (!token) {
        return;
      }

      fetch(
        `${shop.storefrontUrl}/apps/levis-custom-api/shopify-proxy-discount/vouchers`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      )
        .then((response) => {
          response.json().then((data) => {
            if (data.data.vouchers) {
              setVoucherData({
                vouchers: data.data.vouchers,
                loading: false,
                settings: data.data.settings,
              });
            }
          });
        })
        .catch((error) => {
          console.error(error);
          setVoucherData({ vouchers: [], loading: false, settings: { maxDiscountCodesApplyOnCheckout: 1 } });
        });
    });
  }, []);

  useEffect(() => {
    if (buyerIdentity.customer?.current?.id) {
      getVouchers();
    }
  }, [buyerIdentity]);

  const renderModalBody = useCallback(
    () =>
      vouchers.vouchers.length ? (
        vouchers.vouchers.map((voucher, index) => (
          <DiscountItem voucher={voucher} key={index} />
        ))
      ) : vouchers.loading ? (
        <View inlineAlignment={"center"} padding={"extraLoose"}>
          <Spinner />
        </View>
      ) : (
        <View inlineAlignment={"center"} padding={"extraLoose"}>
          {translate('noVoucherFound')}
        </View>
      ),
    [vouchers, discount]
  );

  const renderModal = () => (
    <Modal
      id="my-modal"
      padding
      title={translate('availableVoucherCodes')}
      onOpen={() => {
        setDiscount({
          loading: false,
          code: appliedDiscounts[0]?.code,
          message: null,
        });
      }}
    >
      {renderModalBody()}
    </Modal>
  );

  return (
    <BlockStack>
      <View>
        {buyerIdentity.customer?.current?.id ? (
          <>
            <Button appearance="critical" overlay={renderModal()}>
              {translate("redTab")}
            </Button>
          </>
        ) : currency.isoCode === 'IDR' ? <Banner title={translate("loggedIn")} status="critical" /> : null}
      </View>
      <Divider />
    </BlockStack>
  );
}
