import { useState } from "react";
import moment = require("moment");
import {
  useApi,
  View,
  Text,
  Button,
  InlineSpacer,
  InlineLayout,
  TextBlock,
  useApplyDiscountCodeChange,
  useDiscountCodes,
  useCustomer,
  useTranslate,
} from "@shopify/ui-extensions-react/checkout";

function DiscountItem({ voucher }) {
  const { ui, shop, sessionToken, analytics, i18n } = useApi();
  const translate = useTranslate();
  const customer = useCustomer();
  const applyDiscount = useApplyDiscountCodeChange();
  const appliedDiscount = useDiscountCodes();
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState(null);

  const applyDiscountAction = async () => {
    setLoading(true);
    setMessage(null);

    try {
      const token = await sessionToken.get();
      const requestData = {
        code: voucher.id,
      };

      try {
        await fetch(
          `${shop.storefrontUrl}/apps/levis-custom-api/shopify-proxy-discount/apply-voucher`,
          {
            method: "POST",
            body: JSON.stringify(requestData),
            headers: {
              "Content-Type": "application/json",
              Accept: "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        );

        try {
          const value = await applyDiscount({
            type: "addDiscountCode",
            code: voucher.id,
          });

          if (value.type === "success") {
            ui.overlay.close("my-modal");
          } else {
            let customErrorMessage = value?.message;

            if(voucher.code.startsWith('STW')) {
              const customStwErrorMessage = translate('voucherValidationError', {id: voucher.id}) as string;
              customErrorMessage = customStwErrorMessage;
            }

            setMessage(customErrorMessage);
            analytics
              .publish("hm_push_event", {
                event_category: "engagement",
                event_action: "error_coupon",
                event_label: customErrorMessage,
                coupon_code: voucher.id,
                error_type: value.type,
                user_id: customer.id,
                page_type: "checkout",
                market: "{ph}",
                page_category: "coupon",
                event_name: "engagement_error",
                event: "hm_push_event",
              })
              .catch(console.error);
          }
        } catch (err) {
          setMessage(translate("couponNotValid"));
        }
      } catch (err) {
        setMessage(translate("couponNotValid"));
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <InlineLayout columns={["100%"]} key={voucher.code}>
      <View padding="base">
        <Text size="extraLarge">{voucher.id}</Text>
        <TextBlock>{voucher.name}</TextBlock>
        {voucher?.validTo ? (
          <Text size="medium">
            {translate("validUntil", {
              date: moment(voucher.validTo, "DD-MM-YYYY HH:mm:ss").format(
                "DD-MM-yyyy"
              ),
            })}
          </Text>
        ) : null}
        {/* show discount value based on type */}
        {voucher?.type === "Discount" ? (
          <TextBlock size="medium">
            {translate("discountPercentage", {
              value: voucher.value,
            })}
          </TextBlock>
        ) : (
          <TextBlock size="medium">
            {translate("discountCash", {
              value: i18n.formatCurrency(voucher.value ?? 0),
            })}
          </TextBlock>
        )}
        {message ? (
          <TextBlock appearance="critical">{message}</TextBlock>
        ) : null}
      </View>
      <View padding="base">
        <Button
          loading={loading}
          disabled={
            appliedDiscount.filter((d) => d.code === voucher.id).length > 0
          }
          appearance="critical"
          onPress={() => {
            applyDiscountAction();
          }}
        >
          <InlineSpacer spacing="loose" />
          {translate(
            appliedDiscount[0]?.code === voucher.code ? "applied" : "apply"
          )}
          <InlineSpacer spacing="loose" />
        </Button>
      </View>
    </InlineLayout>
  );
}

export default DiscountItem;
