import {
  reactExtension,
  Select,
  useTranslate,
  useApplyShippingAddressChange,
  useShippingAddress,
  View,
  BlockStack,
  useApi,
} from "@shopify/ui-extensions-react/checkout";

import { useEffect, useState } from "react";

export default reactExtension(
  "purchase.checkout.delivery-address.render-after",
  () => <Extension />
);

function Extension() {
  const translate = useTranslate();
  const { sessionToken, shop } = useApi();
  const { shippingAddress } = useApi();
  const { provinceCode } = useShippingAddress();
  const [cities, setCities] = useState(
    shippingAddress?.current.city
      ? [
          {
            label: shippingAddress?.current.city,
            value: shippingAddress?.current.city,
          },
        ]
      : []
  );
  const [selectedCity, setSelectedCity] = useState(
    shippingAddress?.current.city || ""
  );
  const [barangay, setBarangay] = useState(
    shippingAddress.current.address2 || ""
  );
  const [barangays, setBarangays] = useState([]);
  const applyShippingAddressChange = useApplyShippingAddressChange();
  useEffect(() => {
    getAddresses();
  }, [provinceCode]);

  const getAddresses = () => {
    sessionToken.get().then((token) => {
      var requestOptions = {
        method: "GET",

        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          Authorization: `Bearer ${token}`,
        },
      };
      setCities([]);
      fetch(
        `${shop.storefrontUrl}/apps/levis-custom-api/shopify-proxy-address/addresses?limit=500&provinceShortName=${provinceCode?.replace('PH-','') || ''}`,
        requestOptions
      )
        .then((response) => {
          response
            .json()
            .then((data) => {
              setSelectedCity((prev) =>
                prev === shippingAddress?.current.city ? prev : provinceCode
              );
              setCities(
                data.data.addresses.map((a) => ({
                  ...a,
                  label: a.city,
                  value: a.city,
                }))
              );
              if (data.data) {
                // label
              } else {
              }
            })
            .catch(() => {})
            .finally(() => {});
        })
        .catch((error) => {
          console.error(error);
        })
        .finally(() => {});
    });
  };

  const barangayChange = async (value) => {
    await applyShippingAddressChange({
      type: "updateShippingAddress",
      address: {
        address2: value,
      },
    });
  };
  const cityChange = async (value) => {
    await applyShippingAddressChange({
      type: "updateShippingAddress",
      address: {
        city: value,
      },
    });
  };
  useEffect(() => {
    if (selectedCity) {
      if (shippingAddress?.current.city !== selectedCity) {
        setBarangay("");
        setBarangays([]);
      }
      sessionToken.get().then((token) => {
        var requestOptions = {
          method: "GET",

          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: `Bearer ${token}`,
          },
        };

        fetch(
          `${shop.storefrontUrl}/apps/levis-custom-api/shopify-proxy-address/addresses?limit=500&city=${selectedCity}`,
          requestOptions
        )
          .then((response) => {
            response
              .json()
              .then((data) => {
                console.log("data.data", data.data.addresses.length);
                setBarangays(
                  data.data.addresses.map((a) => ({
                    label: a.district,
                    value: a.district,
                  }))
                );
                if (data.data) {
                  // label
                } else {
                }
              })
              .catch(() => {})
              .finally(() => {});
          })
          .catch((error) => {
            console.error(error);
          })
          .finally(() => {});
      });
    }
  }, [selectedCity]);

  return (
    <BlockStack border="none">
      <View padding="none">
        <Select
          key={"City"}
          label={translate("city")}
          value={selectedCity}
          onChange={(value) => {
            cityChange(value);
            console.log("value", value);

            setSelectedCity(value);
          }}
          options={cities}
        />
      </View>
      {selectedCity ? (
        <View padding="none">
          <Select
            key={"barangay"}
            label={translate("barangay")}
            value={barangay}
            onChange={(value) => {
              barangayChange(value);
              setBarangay(value);
            }}
            options={barangays}
          />
        </View>
      ) : null}
    </BlockStack>
  );
}
