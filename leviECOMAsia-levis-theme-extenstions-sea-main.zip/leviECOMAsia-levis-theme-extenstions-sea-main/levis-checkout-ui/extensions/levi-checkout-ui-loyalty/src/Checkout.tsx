import { useEffect, useState } from "react";
import {
  Banner,
  useApi,
  reactExtension,
  View,
  Text,
  Disclosure,
  BlockStack,
  Icon,
  InlineSpacer,
  Divider,
  InlineLayout,
  Checkbox,
  Spinner,
  useDiscountCodes,
  Pressable,
  useApplyAttributeChange,
  useTranslate,
  useDiscountAllocations,
  useAppMetafields,
} from "@shopify/ui-extensions-react/checkout";

export default reactExtension(
  "purchase.checkout.reductions.render-after",
  () => <Extension />
);

function Extension() {
  const { buyerIdentity, sessionToken, cost, attributes, i18n, shop } =
    useApi();
  const translate = useTranslate();
  const applyAttributeChange = useApplyAttributeChange();
  const [loyalty, setLoyalty] = useState(null);
  const [failedRules, setFailedRules] = useState([]);
  const [showLoyalty, setShowLoyalty] = useState(false);
  const [showLoyaltyErrorMessage, setShowLoyaltyErrorMessage] = useState(false);
  const [showLoyaltyNAMessage, setShowLoyaltyNAMessage] = useState(false);
  const [loyaltyLoader, setLoyaltyLoader] = useState<boolean>(true);
  const [loading, setLoading] = useState<boolean>(false);
  const metafields = useAppMetafields({
    type: "customer",
    namespace: "custom",
  });
  const appliedDiscount = useDiscountCodes();
  const discountAllocations = useDiscountAllocations();
  const [userChecked, setUserChecked] = useState<boolean>(false);
  const [loyaltyChecked, setLoyaltyChecked] = useState<boolean>(
    discountAllocations.findIndex((v) =>
      v["title"]?.toLowerCase().includes("redtab")
    ) > -1
  );

  useEffect(() => {
    const checked =
      discountAllocations.findIndex((v) =>
        v["title"]?.toLowerCase().includes("redtab")
      ) > -1;

    checkLoyalty(checked);

    if (userChecked) {
      setLoyaltyChecked(checked);
      setShowLoyaltyNAMessage(!checked);
    }
  }, [discountAllocations, appliedDiscount]);

  async function checkLoyalty(status: boolean) {
    const loyaltyAttribute = attributes.current.find(
      (a) => a.key === "_loyalty_redemption_payload"
    );

    if (!status && loyaltyAttribute?.value !== "e30=") {
      applyAttributeChange({
        type: "updateAttribute",
        key: "_loyalty_redemption_payload",
        value: "e30=",
      });
    }

    if (!buyerIdentity?.customer?.current?.id) {
      return;
    }

    setLoyaltyLoader(true);

    try {
      const token = await sessionToken.get();
      let response = await fetch(
        `${shop.storefrontUrl}/apps/levis-custom-api/shopify-proxy-discount/loyalty-points`,
        // 'https://anz-levis-custom-api-dev.nexxbuzz.com/shopify-proxy-discount/loyalty-points?shop=anz-dev.myshopify.com',
        {
          method: "POST",
          body: JSON.stringify({
            subtotalAmount: cost.subtotalAmount.current.amount,
            totalAmount: cost.totalAmount.current.amount,
            totalShippingAmount: cost.totalShippingAmount?.current?.amount ?? 0,
            totalTaxAmount: cost.totalTaxAmount.current.amount,
            totalDiscount: discountAllocations
              .filter((v) => !v["title"]?.toLowerCase().includes("redtab"))
              .reduce(
                (total: number, c) => (total += c.discountedAmount.amount),
                0
              ),
            applyLoyalty: status,
          }),
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );
      const json = await response.json();
      setShowLoyaltyErrorMessage(false);
      setLoyalty(json.data.calculation);
      setFailedRules(json.data.failedRules);

      if (json.data.attributes) {
        json.data.attributes.forEach((attribute) => {
          const loyaltyAttribute = attributes.current.find(
            (a) => a.key === "_loyalty_redemption_payload"
          );

          if (!loyaltyAttribute || loyaltyAttribute.value !== attribute.value) {
            applyAttributeChange({
              type: "updateAttribute",
              key: attribute.key,
              value: attribute.value,
            });
          }
        });
      }
    } catch (err) {
      console.error(err);
      setShowLoyaltyErrorMessage(true);
    } finally {
      setLoading(false);
      setLoyaltyLoader(false);
    }
  }

  function handleChange(value) {
    setLoading(true);
    setUserChecked(value);
    setLoyaltyChecked(value);
    checkLoyalty(value);
  }

  function renderPoints() {
    const loylatyMetafield =
      metafields?.find((metafield) => metafield.metafield.key === "loyalty")
        ?.metafield?.value === "true"
        ? true
        : false;
    return buyerIdentity?.customer?.current?.id ? (
      loylatyMetafield ? (
        <View>
          <Disclosure defaultOpen>
            <Pressable
              toggles="one"
              onPress={() => {
                setShowLoyalty(!showLoyalty);
              }}
            >
              <InlineLayout
                columns={["fill", "auto"]}
                blockAlignment={"center"}
              >
                <Text size="large">{translate("useRewardPoints")}</Text>
                <InlineSpacer spacing="loose" />
                <Icon source={showLoyalty ? "chevronUp" : "chevronDown"} />
              </InlineLayout>
            </Pressable>
            <View id="one">
              {loyaltyLoader ? (
                <View padding={["loose", "none", "tight", "none"]}>
                  <Spinner />
                </View>
              ) : showLoyaltyErrorMessage ? (
                <View>
                  <Text size="medium">{translate("redTabErrorMessage")}</Text>
                </View>
              ) : loyalty?.redeemablePoints > 0 ? (
                <InlineLayout columns={["fill"]}>
                  <View padding={["loose", "none", "tight", "none"]}>
                    {loading ? (
                      <Spinner />
                    ) : (
                      <>
                        <Checkbox
                          id="redeem-checkbox"
                          name="redeem-checkbox"
                          onChange={handleChange}
                          value={loyaltyChecked}
                        >
                          {translate("redeemValue", {
                            redeemablePoints: loyalty?.redeemablePoints ?? "0",
                            redeemableCash: i18n.formatCurrency(
                              loyalty?.redeemableCash ?? 0
                            ),
                          })}
                        </Checkbox>
                        {showLoyaltyNAMessage && (
                          <BlockStack
                            spacing={"tight"}
                            padding={["tight", "none"]}
                          >
                            <Banner
                              status="warning"
                              title={translate("notApplicable")}
                            />
                          </BlockStack>
                        )}
                      </>
                    )}
                  </View>
                </InlineLayout>
              ) : (
                <InlineLayout columns={["fill"]}>
                  <View padding={["loose", "none", "tight", "none"]}>
                    <Text size="medium">
                      {failedRules.length > 0
                        ? translate(failedRules[0], {
                            minRedeemableLoyaltyPoints:
                              loyalty?.minRedeemableLoyaltyPoints ?? "0",
                            minCartValue: i18n.formatCurrency(
                              loyalty?.minCartValue ?? 0
                            ),
                          })
                        : translate("insufficientPointsBalance", {
                            minRedeemableLoyaltyPoints:
                              loyalty?.minRedeemableLoyaltyPoints ?? "0",
                          })}
                    </Text>
                  </View>
                </InlineLayout>
              )}
            </View>
          </Disclosure>
        </View>
      ) : (
        <Banner title={translate("nonRTPMember")} status="critical" />
      )
    ) : (
      <Banner title={translate("loggedIn")} status="critical" />
    );
  }

  return (
    <BlockStack>
      <Divider />
      <View>
        <Text size="extraLarge">{translate("availablePoints")}</Text>
      </View>
      {renderPoints()}
    </BlockStack>
  );
}
