import { useState } from "react";
import {
  useApi,
  reactExtension,
  useBuyerJourneyIntercept,
  useApplyAttributeChange,
  useTranslate,
} from "@shopify/ui-extensions-react/checkout";

export default reactExtension("purchase.checkout.block.render", () => (
  <Extension />
));

function Extension() {
  const {
    sessionToken,
    buyerIdentity,
    discountAllocations,
    cost,
    shop,
    attributes,
  } = useApi();
  const [processed, setProcessed] = useState(false);
  const [loading, setLoading] = useState(false);
  const translate = useTranslate();
  const applyAttributeChange = useApplyAttributeChange();

  useBuyerJourneyIntercept(async ({ canBlockProgress }) => {
    if (loading || !buyerIdentity.customer?.current?.id) {
      return { behavior: "allow" };
    }

    setLoading(true);

    const redTabDiscount = discountAllocations.current.filter(
      (t) => t["title"] === "RedTab™ Loyalty Points"
    )[0];

    if (!redTabDiscount || processed) {
      return { behavior: "allow" };
    }

    const status = await validateLoyalty();

    if (canBlockProgress && !status) {
      return {
        behavior: "block",
        reason: translate("loyaltyAlreadyRedeemed"),
        errors: [
          {
            // In addition, show an error at the page level
            message: translate("loyaltyAlreadyRedeemed"),
          },
        ],
      };
    } else {
      return { behavior: "allow" };
    }
  });

  const validateLoyalty = async () => {
    let validDiscount = false;

    try {
      setProcessed(false);

      const token = await sessionToken.get();
      const response = await fetch(
        `${shop.storefrontUrl}/apps/levis-custom-api/shopify-proxy-discount/loyalty-points`,
        {
          method: "POST",
          body: JSON.stringify({
            subtotalAmount: cost.subtotalAmount.current.amount,
            totalAmount: cost.totalAmount.current.amount,
            totalShippingAmount: cost.totalShippingAmount.current.amount,
            totalTaxAmount: cost.totalTaxAmount.current.amount,
            totalDiscount: discountAllocations.current
              .filter((v) => !v['title']?.toLowerCase()?.includes("redtab"))
              .reduce((total: any, c) => {
                total += c.discountedAmount.amount;
                return total;
              }, 0),
            applyLoyalty: true,
          }),
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );
      const data = await response.json();

      setProcessed(true);

      if (data.data.attributes) {
        data.data.attributes.map((attribute) => {
          const loyaltyAttribute = attributes.current.filter(
            (a) => a.key === "_loyalty_redemption_payload"
          );

          if (
            loyaltyAttribute.length === 0 ||
            loyaltyAttribute[0]?.value !== attribute.value
          ) {
            applyAttributeChange({
              type: "updateAttribute",
              key: attribute.key,
              value: attribute.value,
            });
          }
        });
      }
    } catch (e) {
      validDiscount = false;
    }

    return validDiscount;
  };

  return null;
}
