const minRedeemableLoyaltyPoints = 100;
const maxAllowedRedeemableLoyaltyPointPercentage = 100;
const maxAllowedRedeemableCashFromPointPercentage =
    minRedeemableLoyaltyPoints +
    minRedeemableLoyaltyPoints *
        (maxAllowedRedeemableLoyaltyPointPercentage / 100);
const maxCashRedeemable = 100;
const maxAllowedCashRedeemable = Math.min(
    maxCashRedeemable,
    maxAllowedRedeemableCashFromPointPercentage,
);
const userLoyalty = 13995;
const orderTotal = 29.95;
const rebate = '1:100:1:1';

function calcualteRedeemableLoyalty() {
    let maxRedeemableCash = 0;
    let maxRedeemablePoints = 0;
    if (userLoyalty > minRedeemableLoyaltyPoints) {
        const userLoyaltyToCash = rebateValueFromPoints(
            userLoyalty,
            rebate,
        );
        if (userLoyaltyToCash >= orderTotal) {
            maxRedeemablePoints = pointsFromCash(orderTotal, rebate);
            maxRedeemableCash = orderTotal;
        } else {
            // let orderTotalAfterPointsCashRedemption =
            //     orderTotal - userLoyaltyToCash;
            // const orderDecialValue = orderTotal % 1;
            // if (!Number.isInteger(orderTotalAfterPointsCashRedemption)) {
            //     maxRedeemableCash = Math.floor(
            //         orderTotal - orderTotalAfterPointsCashRedemption,
            //     );
            //     maxRedeemablePoints = pointsFromCash(
            //         maxRedeemableCash,
            //         rebate,
            //     );

            //     if (!Number.isInteger(orderDecialValue)) {
            //         maxRedeemableCash -= 1 - orderDecialValue;
            //         maxRedeemablePoints = pointsFromCash(
            //             maxRedeemableCash,
            //             rebate,
            //         );
            //     }
            // } else {
                maxRedeemablePoints = userLoyalty;
                maxRedeemableCash = userLoyaltyToCash;
            // }
        }

        // check max cash redeemable
        if (maxRedeemableCash > maxAllowedCashRedeemable) {
            // let orderTotalAfterPointsCashRedemption =
            //     orderTotal - maxAllowedCashRedeemable;
            // const orderDecialValue = orderTotal % 1;
            // if (!Number.isInteger(orderTotalAfterPointsCashRedemption)) {
            //     maxRedeemableCash = Math.floor(
            //         orderTotal - orderTotalAfterPointsCashRedemption,
            //     );
            //     maxRedeemablePoints = pointsFromCash(
            //         maxRedeemableCash,
            //         rebate,
            //     );

            //     // if (!Number.isInteger(orderDecialValue)) {
            //     //     maxRedeemableCash -= 1 - orderDecialValue;
            //     //     maxRedeemablePoints = pointsFromCash(
            //     //         maxRedeemableCash,
            //     //         rebate,
            //     //     );
            //     // }
            // } else {
                maxRedeemableCash = maxAllowedCashRedeemable;
                maxRedeemablePoints = pointsFromCash(maxRedeemableCash, rebate);
            // }
        }

        // Round down redeemable cash to avoid decimal value
        const maxRedeemableCashDecimal = maxRedeemableCash % 1;
        if (!Number.isInteger(maxRedeemableCashDecimal)) {
            maxRedeemableCash = Math.floor(
                maxRedeemableCash,
            );
            maxRedeemablePoints = pointsFromCash(
                maxRedeemableCash,
                rebate,
            );
        }
    }

    return {
        redeemablePoints: parseInt(maxRedeemablePoints.toFixed(0)),
        redeemableCash: parseFloat(maxRedeemableCash.toFixed(2)),
        userLoyalty,
        orderTotal,
        balancePayable: orderTotal - maxRedeemableCash,
        maxAllowedRedeemableCashFromPointPercentage,
        maxAllowedCashRedeemable,
        maxAllowedRedeemableLoyaltyPointPercentage,
        minRedeemableLoyaltyPoints,
        maxCashRedeemable,
    };
}

function rebateValueFromPoints(points, dollarToPointsRatio) {
    const dollarToPointsRatioArray = dollarToPointsRatio.split(':');
    const rebate = dollarToPointsRatioArray[0];
    const rebasePoint = dollarToPointsRatioArray[1];
    const dollarValue = (points / +rebasePoint) * +rebate;
    return dollarValue;
}

function pointsFromCash(cash, dollarToPointsRatio) {
    const dollarToPointsRatioArray = dollarToPointsRatio.split(':');
    const rebate = dollarToPointsRatioArray[0];
    const rebasePoint = dollarToPointsRatioArray[1];
    const points = (cash * +rebasePoint) / +rebate;
    return points;
}

console.log(calcualteRedeemableLoyalty());
