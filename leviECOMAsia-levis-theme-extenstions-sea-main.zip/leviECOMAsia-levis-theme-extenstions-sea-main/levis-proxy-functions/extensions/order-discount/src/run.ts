import type { RunInput, FunctionRunResult } from '../generated/api';
import { DiscountApplicationStrategy } from '../generated/api';
import { decode } from 'js-base64';

const result: FunctionRunResult = {
    discountApplicationStrategy: DiscountApplicationStrategy.First,
    discounts: [],
};

export function run(input: RunInput): FunctionRunResult {
    const buyerIdentity = input.cart?.buyerIdentity;
    if (!buyerIdentity?.isAuthenticated) {
        return result;
    }

    // Check if the discount node is enabled and the discount is applied to the full price of the product
    if (input.discountNode.metafield?.value === 'true') {
        const productFullPriceDiscount = input.cart.lines.filter((line) => {
            return !line.cost.compareAtAmountPerQuantity || line.cost.amountPerQuantity.amount === line.cost.compareAtAmountPerQuantity.amount;
        })

        if (productFullPriceDiscount?.length === 0) {
            
            return result;
        }
    }
    
    const attributeValue = input.cart?.attribute?.value;
    const loyaltyRedemptionPayload = attributeValue ? JSON.parse(
        decode(attributeValue),
    ) : null;

    if (loyaltyRedemptionPayload?.points) {
        const redeemableCash = loyaltyRedemptionPayload.calculation?.redeemableCash;

        console.log(`Redeemable Cash: ${redeemableCash}`);

        if (redeemableCash > 0) {
            result.discounts.push({
                targets: [
                    {
                        orderSubtotal: {
                            excludedVariantIds: [],
                        },
                    },
                ],
                message: 'RedTab™ Loyalty Points',
                value: {
                    fixedAmount: {
                        amount: redeemableCash.toString() || '0',
                    },
                },
            });
        }
    }

    return result;
}