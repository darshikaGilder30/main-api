import type { RunInput, FunctionRunResult } from '../generated/api';

const NO_CHANGES: FunctionRunResult = {
    operations: [],
};

type Configuration = {
    minOrderAmount?: number;
};

export function run(input: RunInput): FunctionRunResult {
    const configuration: Configuration = JSON.parse(
        input?.paymentCustomization?.metafield?.value ?? '{}',
    );

    const minOrderAmount = configuration.minOrderAmount ?? 0;
    const giftCardPayment = input.paymentMethods.find(
        (paymentMethod) => paymentMethod.name === 'Gift card',
    );
	const subtotalAmount = +input.cart.cost.subtotalAmount.amount;

    if (
        giftCardPayment &&
        minOrderAmount &&
        subtotalAmount < minOrderAmount
    ) {
        NO_CHANGES.operations.push({
            hide: {
                paymentMethodId: giftCardPayment.id,
            },
        });
    }

    return NO_CHANGES;
}
