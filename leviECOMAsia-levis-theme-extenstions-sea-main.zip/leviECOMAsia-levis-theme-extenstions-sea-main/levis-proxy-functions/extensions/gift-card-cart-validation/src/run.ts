import type {
    RunInput,
    FunctionRunResult,
    FunctionError,
} from '../generated/api';

export function run(input: RunInput): FunctionRunResult {
    const errors: FunctionError[] = [];
    const physicalProductExists = input.cart.lines.some(
        (line) =>
            (line.merchandise.__typename === 'ProductVariant' &&
                !line.merchandise.product.isGiftCard) ||
            (line.merchandise.__typename === 'CustomProduct' &&
                !line.merchandise.isGiftCard),
    );

    const giftCardExists = input.cart.lines.some(
        (line) =>
            (line.merchandise.__typename === 'ProductVariant' &&
                line.merchandise.product.isGiftCard) ||
            (line.merchandise.__typename === 'CustomProduct' &&
                line.merchandise.isGiftCard),
    );

    if (physicalProductExists && giftCardExists) {
        errors.push({
            localizedMessage:
                'Gift cards cannot be applied to physical products. Please remove any physical items from your cart to use your gift card.',
            target: '$.cart',
        });
    }

    return {
        errors,
    };
}
