import type { RunInput, FunctionRunResult } from '../generated/api';

const NO_CHANGES: FunctionRunResult = {
    operations: [],
};

const paymentToRename = [
    {
        name: '2C2P',
        country: ['ID'],
        rename: {
            "EN": 'Debit / Credit Card',
            "ID": 'Debit / Credit Card',
            "TH": 'Debit / Credit Card',
            "ZH_TW": "Debit / Credit Card",
        }
    },
    {
        name: '2C2P',
        country: ['PH'],
        rename: {
            "EN": 'Debit / Credit Card / 0% Installment',
            "ID": 'Debit / Credit Card',
            "TH": 'Debit / Credit Card',
            "ZH_TW": "Debit / Credit Card",
        }
    },
    {
        name: 'Payments By Xendit',
        country: ['PH'],
        rename: {
            "EN": 'Debit / Credit Card / Bank Transfer / eWallet / PayLater',
            "ID": 'Debit / Credit Card / Bank Transfer / eWallet / PayLater',
            "TH": 'Debit / Credit Card / Bank Transfer / eWallet / PayLater',
            "ZH_TW": "Debit / Credit Card / Bank Transfer / eWallet / PayLater",
        }
    },
    {
        name: 'Payments By Xendit',
        country: ['ID'],
        rename: {
            "EN": 'Bank Transfer / eWallet / PayLater',
            "ID": 'Bank Transfer / eWallet / PayLater',
            "TH": 'Bank Transfer / eWallet / PayLater',
            "ZH_TW": "Bank Transfer / eWallet / PayLater",
        }
    },
    {
        name: '2C2P',
        country: ['MY', 'HK'],
        rename: {
            "EN": 'Online Payment',
            "ID": 'Online Payment',
            "TH": 'Online Payment',
            "ZH_TW": "網上付款",
        }
    },
    {
        name: '2C2P',
        country: ['SG'],
        rename: {
            "EN": 'Online Payments',
            "ID": 'Online Payments',
            "TH": 'Online Payments',
            "ZH_TW": "網上付款",
        }
    },
    {
        name: '2C2P',
        country: ['TH'],
        rename: {
            "EN": 'Credit Card / Mobile Banking',
            "ID": 'Online Payment',
            "TH": 'บัตรเครดิต หรือ โอนผ่านธนาคาร',
            "ZH_TW": "網上付款",
        }
    },
    {
        name: 'Payments By Xendit',
        country: ['PH'],
        rename: {
            "EN": 'Bank Transfer / eWallet / BillEase',
            "ID": 'Debit / Credit Card / Bank Transfer / eWallet / PayLater',
            "TH": 'Debit / Credit Card / Bank Transfer / eWallet / PayLater',
            "ZH_TW": "Debit / Credit Card / Bank Transfer / eWallet / PayLater",
        }
    },
    {
        name: 'Shopify Payments',
        country: ['SG'],
        rename: {
            "EN": 'Visa / Mastercard',
            "ID": 'Visa / Mastercard',
            "TH": 'Visa / Mastercard',
            "ZH_TW": "網上付款",
        }
    },
];

type Configuration = {};

export function run(input: RunInput): FunctionRunResult {
    const configuration: Configuration = JSON.parse(
        input?.paymentCustomization?.metafield?.value ?? '{}',
    );
    const country = input.localization?.country?.isoCode ?? '';

    for (const method of input.paymentMethods) {
        for (const payment of paymentToRename) {
            if (
                method.name.includes(payment.name) &&
                (!payment.country || payment.country.includes(country))
            ) {
                NO_CHANGES.operations.push({
                    rename: {
                        name: payment.rename[input.localization?.language?.isoCode ?? 'EN'],
                        paymentMethodId: method.id,
                    },
                });
            }
        }
    }

    return NO_CHANGES;
}
