import type {
    RunInput,
    FunctionRunResult,
    FunctionError,
} from '../generated/api';
import { decode } from 'js-base64';

export function run(input: RunInput): FunctionRunResult {
    const errors: FunctionError[] = [];
    const attributeValue = input.cart?.attribute?.value || (input.cart?.lines?.length > 0 ? input.cart.lines[0].attribute?.value : null);
    const loyaltyRedemptionPayload = attributeValue ? JSON.parse(
        decode(attributeValue),
    ) : null;

    const cost = input.cart?.cost;

    if (loyaltyRedemptionPayload?.points) {
        const calculation = calcualteRedeemableLoyalty(
            loyaltyRedemptionPayload,
            cost.subtotalAmount.amount,
        );

        console.log(`Calculation: ${JSON.stringify(calculation, null, 2)}`);

        if (calculation.redeemableCash > 100) {
            errors.push({
                target: 'cart',
                localizedMessage:
                    'Loyalty already redeemed. Please remove the loyalty item from your cart.',
            });
        }
    }

    return {
        errors,
    };
}

function calcualteRedeemableLoyalty(loyaltyRedemptionPayload, orderTotal) {
    orderTotal = parseFloat(orderTotal);
    const userLoyalty = loyaltyRedemptionPayload?.points;
    const rebate = loyaltyRedemptionPayload?.dollarToPointsRatio;
    const maxAllowedRedeemableCashFromPointPercentage =
        loyaltyRedemptionPayload?.settings
            ?.maxAllowedRedeemableCashFromPointPercentage || 10000;
    const maxCashRedeemable =
        loyaltyRedemptionPayload?.settings?.maxCashRedeemable || 10000;
    const minRedeemableLoyaltyPoints =
        loyaltyRedemptionPayload?.settings?.minRedeemableLoyaltyPoints || 100;
    const maxAllowedCashRedeemable = Math.min(
        maxCashRedeemable,
        (orderTotal * maxAllowedRedeemableCashFromPointPercentage) / 100,
    );

    let maxRedeemableCash = 0;
    let maxRedeemablePoints = 0;
    if (userLoyalty > minRedeemableLoyaltyPoints) {
        const userLoyaltyToCash = rebateValueFromPoints(userLoyalty, rebate);
        if (userLoyaltyToCash >= orderTotal) {
            maxRedeemablePoints = pointsFromCash(orderTotal, rebate);
            maxRedeemableCash = orderTotal;
        } else {
            let orderTotalAfterPointsCashRedemption =
                orderTotal - userLoyaltyToCash;
            const orderDecialValue = orderTotal % 1;
            if (!Number.isInteger(orderTotalAfterPointsCashRedemption)) {
                maxRedeemableCash = Math.floor(
                    orderTotal - orderTotalAfterPointsCashRedemption,
                );
                maxRedeemablePoints = pointsFromCash(maxRedeemableCash, rebate);

                if (!Number.isInteger(orderDecialValue)) {
                    maxRedeemableCash -= 1 - orderDecialValue;
                    maxRedeemablePoints = pointsFromCash(
                        maxRedeemableCash,
                        rebate,
                    );
                }
            } else {
                maxRedeemablePoints = userLoyalty;
                maxRedeemableCash = userLoyaltyToCash;
            }
        }

        // check max cash redeemable
        if (maxRedeemableCash > maxAllowedCashRedeemable) {
            let orderTotalAfterPointsCashRedemption =
                orderTotal - maxAllowedCashRedeemable;
            const orderDecialValue = orderTotal % 1;
            if (!Number.isInteger(orderTotalAfterPointsCashRedemption)) {
                maxRedeemableCash = Math.floor(
                    orderTotal - orderTotalAfterPointsCashRedemption,
                );
                maxRedeemablePoints = pointsFromCash(maxRedeemableCash, rebate);

                if (!Number.isInteger(orderDecialValue)) {
                    maxRedeemableCash -= 1 - orderDecialValue;
                    maxRedeemablePoints = pointsFromCash(
                        maxRedeemableCash,
                        rebate,
                    );
                }
            } else {
                maxRedeemablePoints = userLoyalty;
                maxRedeemableCash = maxRedeemableCash;
            }
        }
    }

    return {
        redeemablePoints: parseInt(maxRedeemablePoints.toFixed(0)),
        redeemableCash: parseFloat(maxRedeemableCash.toFixed(2)),
        userLoyalty,
        orderTotal,
        balancePayable: orderTotal - maxRedeemableCash,
        maxAllowedRedeemableCashFromPointPercentage,
        maxAllowedCashRedeemable,
        minRedeemableLoyaltyPoints,
        maxCashRedeemable,
    };
}

function rebateValueFromPoints(points, dollarToPointsRatio) {
    const dollarToPointsRatioArray = dollarToPointsRatio.split(':');
    const rebate = dollarToPointsRatioArray[0];
    const rebasePoint = dollarToPointsRatioArray[1];
    const dollarValue = (points / +rebasePoint) * +rebate;
    return dollarValue;
}

function pointsFromCash(cash, dollarToPointsRatio) {
    const dollarToPointsRatioArray = dollarToPointsRatio.split(':');
    const rebate = dollarToPointsRatioArray[0];
    const rebasePoint = dollarToPointsRatioArray[1];
    const points = (cash * +rebasePoint) / +rebate;
    return points;
}
