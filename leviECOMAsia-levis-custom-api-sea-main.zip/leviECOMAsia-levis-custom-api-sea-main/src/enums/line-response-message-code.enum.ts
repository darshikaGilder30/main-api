export enum LineResponseMessageCode {
    Success = '1004',
    UserNotExists = '1041',
    AuthenticationFailed = '1003',
    InvalidData = '1016',
    AuthorizationFailed = '1030',
    SomethigWentWrong = '1000',
    UserIsLocked = '1037',
    UserIsNotActive = '1042',
    ServiceNotAuthorized = '1030',
    OtpSendLimitExceeded = '1053',
}