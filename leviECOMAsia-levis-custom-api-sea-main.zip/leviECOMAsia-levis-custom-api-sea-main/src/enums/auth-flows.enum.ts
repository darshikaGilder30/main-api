export enum AuthFlows {
    PASSWORD = 'password',
    OTP = 'otp',
    REGISTER = 'register',
    FORGOT_PASSWORD = 'forgot_password',
    RESET_PASSWORD = 'reset_password',
    Error = 'error',
    Redirect = 'redirect',
    Update = 'update',
    Terms = 'terms',
    None = 'none'
}