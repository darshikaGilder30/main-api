export enum AuthIdentifier {
    Email = 'email',
    Mobile = 'mobile',
}