export enum LoyaltyRedemption {
    NOT_ALLOWED = 'redemptionNotAllowed',
    MIN_ORDER_AMOUNT = 'minOrderAmount',
    MIN_POINTS = 'minPoints'
}
