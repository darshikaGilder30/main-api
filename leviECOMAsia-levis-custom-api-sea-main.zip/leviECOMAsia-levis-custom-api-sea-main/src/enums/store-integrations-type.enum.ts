export enum StoreIntegrationTypeEnum {
    Shopify = 'shopify',
    Ascentis = 'ascentis',
    Referrer = 'referrer',
    SMS = 'sms',
    Email = 'email',
    Line = 'line'
}
