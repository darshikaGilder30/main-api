export enum ShopifyCustomMeta {
    MembershipId = 'membership_id',
    Source = 'source',
    QrCode = 'qr_code',
    ReferralCode = 'referral_code',
    Gender = 'gender',
    DateOfBirth = 'birth_date',
    VerifiedSource = 'verified_source',
    Loyalty = 'loyalty',
    LoyaltyPoints = 'loyalty_points',
    MembershipTierCode = 'membership_tier_code',
    LoyaltyCardNo = 'loyalty_card_no',
    OpeningTime = 'opening_time',
    ClosingTime = 'closing_time',
    StoreCode = 'store_code',
    PostalCode = 'postal_code'
}
