export enum Lang {
    EN = 'en',
    TH = 'th'
}
