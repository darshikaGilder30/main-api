import {
    HttpException,
    HttpStatus,
    Injectable,
    NestMiddleware
} from '@nestjs/common';
import { GoogleRecaptchaService } from 'src/modules/google-recaptcha/google-recaptcha.service';

@Injectable()
export class GoogleRecaptchaValidateMiddleware implements NestMiddleware {
    constructor(
        private readonly googleRecaptchaService: GoogleRecaptchaService
    ) {}
    async use(req: any, res: any, next: () => void) {
        const token = req.body?.googleRecaptchaToken;
        if (!token) {
            throw new HttpException(
                'Google Recaptcha token is required',
                HttpStatus.FORBIDDEN
            );
        }

        const success = await this.googleRecaptchaService.verifyCaptcha(token);
        if (!success) {
            throw new HttpException(
                'Google Recaptcha token is invalid',
                HttpStatus.FORBIDDEN
            );
        }

        next();
    }
}
