import { GoogleRecaptchaValidateMiddleware } from './google-recaptcha-validate.middleware';

describe('GoogleRecaptchaValidateMiddleware', () => {
  it('should be defined', () => {
    expect(new GoogleRecaptchaValidateMiddleware()).toBeDefined();
  });
});
