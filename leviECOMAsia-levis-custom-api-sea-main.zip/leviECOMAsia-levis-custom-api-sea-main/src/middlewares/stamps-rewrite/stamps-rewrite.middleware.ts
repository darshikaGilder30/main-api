import { Injectable, NestMiddleware } from '@nestjs/common';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { ShopifyCustomer } from 'src/modules/shopify-admin-api/interfaces/shopify-customer.interface';
import { StampsService } from 'src/modules/stamps/stamps.service';

@Injectable()
export class StampsRewriteMiddleware implements NestMiddleware {
	constructor(private stampsService: StampsService) { }
	async use(req: any, res: any, next: () => void) {
		const store: StoreDto = req.store;
		const customer: ShopifyCustomer = req.customer;
		if (store.storeIntegrations.stamps?.active) {
			switch (req.baseUrl) {
				case '/shopify-proxy-discount/vouchers':
					return res.send(
						await this.stampsService.vouchers(store, customer)
					)
				case '/shopify-proxy-account/vouchers':
					return res.send(
						await this.stampsService.accountVouchersRender(store, customer)
					)
				case '/shopify-proxy-account/rewards':
					return res.send(
						await this.stampsService.accountRewardsRender(store, customer)
					)
				case '/shopify-proxy-account/transaction-histories':
					return res.send(
						await this.stampsService.accountTransactionHistoriesRender(store, customer)
					)
				case '/shopify-proxy-account/purchase-histories':
					return res.send(
						await this.stampsService.accountPurchaseHistoriesRender(store, customer)
					)
				case '/shopify-proxy-discount/apply-voucher':
					return res.send(
						await this.stampsService.applyVoucher(store, customer, req.body.code)
					)
				case '/shopify-proxy-discount/loyalty-points':
					return res.send(
						await this.stampsService.loyaltyPoints(store, customer, req.body)
					)
				case '/shopify-proxy-discount/remove-voucher':
					return res.send(
						await this.stampsService.removeVoucher(store, customer, req.body.code)
					)
			}
		}

		next();
	}
}
