import { StampsService } from 'src/modules/stamps/stamps.service';
import { StampsRewriteMiddleware } from './stamps-rewrite.middleware';

describe('StampsRewriteMiddleware', () => {
  let middleware: StampsRewriteMiddleware;
  let stampsService: StampsService;
  let req: any;
  let res: any;
  let next: jest.Mock;

  beforeEach(() => {
    // stampsService = new StampsService(); // You may mock StampsService if needed
    stampsService = {
      vouchers: jest.fn(),
      accountVouchersRender: jest.fn(),
      accountTransactionHistoriesRender: jest.fn(),
      applyVoucher: jest.fn(),
      removeVoucher: jest.fn(),
    } as any as StampsService; // Mock StampsService methods
    middleware = new StampsRewriteMiddleware(stampsService);
    req = { store: { storeIntegrations: { stamps: { active: true } } } };
    res = {};
    next = jest.fn();
  });

  it('should call next() if stamps integration is not active', async () => {
    req.store.storeIntegrations.stamps.active = false;
    await middleware.use(req, res, next);
    expect(next).toHaveBeenCalled();
  });

  it('should not call next() if stamps integration is active and different url', async () => {
    req.store.storeIntegrations.stamps.active = true;
    req.baseUrl = '/shopify-proxy-discount/new-vouchers';
    const sendMock = jest.fn();
    res.send = sendMock;
    await middleware.use(req, res, next);
    expect(sendMock).not.toHaveBeenCalled();
    expect(next).toHaveBeenCalled();
  });

  it('should call the correct StampsService method for /shopify-proxy-discount/vouchers', async () => {
    req.baseUrl = '/shopify-proxy-discount/vouchers';
    const sendMock = jest.fn();
    res.send = sendMock;
    await middleware.use(req, res, next);
    expect(sendMock).toHaveBeenCalledWith(await stampsService.vouchers(req.store, req.customer));
  });

  it('should call the correct StampsService method for /shopify-proxy-account/vouchers', async () => {
    // Test similar to the previous one for '/shopify-proxy-account/vouchers'
    req.baseUrl = '/shopify-proxy-account/vouchers';
    const sendMock = jest.fn();
    res.send = sendMock;
    await middleware.use(req, res, next);
    expect(sendMock).toHaveBeenCalledWith(await stampsService.accountVouchersRender(req.store, req.customer));
  });

  it('should call the correct StampsService method for /shopify-proxy-account/transaction-histories', async () => {
    // Test similar to the previous one for '/shopify-proxy-account/transaction-histories'
    req.baseUrl = '/shopify-proxy-account/transaction-histories';
    const sendMock = jest.fn();
    res.send = sendMock;
    await middleware.use(req, res, next);
    expect(sendMock).toHaveBeenCalledWith(await stampsService.accountTransactionHistoriesRender(req.store, req.customer));
  })

  it('should call the correct StampsService method for /shopify-proxy-discount/apply-voucher', async () => {
    // Test similar to the previous one for '/shopify-proxy-discount/apply-voucher'
    req.baseUrl = '/shopify-proxy-discount/apply-voucher';
    const sendMock = jest.fn();
    res.send = sendMock;
    req.body = { code: 'some-code' };
    await middleware.use(req, res, next);
    expect(sendMock).toHaveBeenCalledWith(await stampsService.applyVoucher(req.store, req.customer, req.body.code));
  });

  it('should call the correct StampsService method for /shopify-proxy-discount/remove-voucher', async () => {
    // Test similar to the previous one for '/shopify-proxy-discount/remove-voucher'
    req.baseUrl = '/shopify-proxy-discount/remove-voucher';
    const sendMock = jest.fn();
    res.send = sendMock;
    req.body = { code: 'some-code' };
    await middleware.use(req, res, next);
    expect(sendMock).toHaveBeenCalledWith(await stampsService.removeVoucher(req.store, req.customer, req.body.code));
  });

  it('should call next() if the route is not matched', async () => {
    req.baseUrl = '/some-other-route';
    await middleware.use(req, res, next);
    expect(next).toHaveBeenCalled();
  });
});
