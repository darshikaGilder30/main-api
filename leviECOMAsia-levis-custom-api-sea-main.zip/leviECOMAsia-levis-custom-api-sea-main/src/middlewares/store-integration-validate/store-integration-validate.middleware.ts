import { HttpException, Injectable, NestMiddleware } from '@nestjs/common';
import { Store } from 'src/entities/stores/stores.entity';
import { StoreIntegrationTypeEnum } from 'src/enums/store-integrations-type.enum';
import { CacheHelper } from 'src/modules/utils/cache/cache-helper.service';

@Injectable()
export class StoreIntegrationValidateMiddleware implements NestMiddleware {
    constructor(private cacheHelper: CacheHelper) {}
    use(req: any, res: any, next: () => void) {
        const store: Store = req.store;
        const shopifyIntegration = store.storeIntegrations.find(
            (storeIntegration) => {
                return (
                    storeIntegration.type ===
                        StoreIntegrationTypeEnum.Shopify &&
                    storeIntegration.active
                );
            }
        );
        const storeIntegrations = {};

        if (!shopifyIntegration) {
            this.cacheHelper.del(`store_${store.shop}`).then(() => {
            });
            throw new HttpException('Store integration not found.', 404);
        }

        for (const storeIntegration of store.storeIntegrations) {
            storeIntegrations[storeIntegration.type] = storeIntegration;
        }

        req.store.storeIntegrations = storeIntegrations;

        next();
    }
}
