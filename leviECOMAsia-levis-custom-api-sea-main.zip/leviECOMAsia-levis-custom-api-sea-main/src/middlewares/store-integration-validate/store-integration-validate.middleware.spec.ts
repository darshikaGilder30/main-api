import { HttpException } from '@nestjs/common';
import { Store } from 'src/entities/stores/stores.entity';
import { StoreIntegrationTypeEnum } from 'src/enums/store-integrations-type.enum';
import { StoreIntegrationValidateMiddleware } from './store-integration-validate.middleware';
import e from 'express';

describe('StoreIntegrationValidateMiddleware', () => {
    let middleware: StoreIntegrationValidateMiddleware;
    let mockRequest: any;
    let mockResponse: any;
    let mockNext: jest.Mock;
    let mockCacheHelper: { del: jest.Mock };

    beforeEach(() => {
        mockCacheHelper = { del: jest.fn().mockResolvedValue(undefined) };
        middleware = new StoreIntegrationValidateMiddleware(mockCacheHelper as any);
        mockRequest = { store: { storeIntegrations: [] as any } as Store };
        mockResponse = {};
        mockNext = jest.fn();
    });

    afterEach(() => {
        jest.clearAllMocks();
    });

    it('should pass if Shopify integration is found and active', () => {
        const shopifyIntegration = {
            type: StoreIntegrationTypeEnum.Shopify,
            active: true,
        };
        mockRequest.store.storeIntegrations.push(shopifyIntegration);

        middleware.use(mockRequest, mockResponse, mockNext);

        expect(mockNext).toHaveBeenCalled();
        expect(mockRequest.store.storeIntegrations).toHaveProperty(StoreIntegrationTypeEnum.Shopify, shopifyIntegration);
    });

    it('should throw HttpException if Shopify integration is not found', async () => {
        expect(() => middleware.use(mockRequest, mockResponse, mockNext)).toThrowError(HttpException);
        expect(mockNext).not.toHaveBeenCalled();
        expect(mockCacheHelper.del).toHaveBeenCalledWith(`store_${mockRequest.store.shop}`);
    });

    it('should throw HttpException if Shopify integration is found but not active', async () => {
        const shopifyIntegration = {
            type: StoreIntegrationTypeEnum.Shopify,
            active: false,
        };
        mockRequest.store.storeIntegrations.push(shopifyIntegration);

        expect(() => middleware.use(mockRequest, mockResponse, mockNext)).toThrowError(HttpException);
        expect(mockNext).not.toHaveBeenCalled();
        expect(mockCacheHelper.del).toHaveBeenCalledWith(`store_${mockRequest.store.shop}`);
    });
});
