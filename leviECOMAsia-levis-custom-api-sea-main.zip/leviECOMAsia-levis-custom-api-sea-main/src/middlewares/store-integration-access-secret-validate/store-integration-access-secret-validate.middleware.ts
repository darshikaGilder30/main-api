import {
    Injectable,
    NestMiddleware,
    UnauthorizedException
} from '@nestjs/common';

@Injectable()
export class StoreIntegrationAccessSecretValidateMiddleware
    implements NestMiddleware
{
    use(req: any, res: any, next: () => void) {
        const clientSecret = req.headers['x-client-secret'];
        if (clientSecret) {
            if (req.storeIntegrationAccess.clientSecret === clientSecret) {
                return next();
            }
        }
        throw new UnauthorizedException('Invalid client secret');
    }
}
