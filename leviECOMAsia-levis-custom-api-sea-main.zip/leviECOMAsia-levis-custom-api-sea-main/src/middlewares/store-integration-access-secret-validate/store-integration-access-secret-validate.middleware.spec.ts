import { UnauthorizedException } from '@nestjs/common';
import { StoreIntegrationAccessSecretValidateMiddleware } from './store-integration-access-secret-validate.middleware';

describe('StoreIntegrationAccessSecretValidateMiddleware', () => {
    let middleware: StoreIntegrationAccessSecretValidateMiddleware;
    let mockRequest: any;
    let mockResponse: any;
    let mockNext: jest.Mock;

    beforeEach(() => {
        middleware = new StoreIntegrationAccessSecretValidateMiddleware();
        mockRequest = { headers: {} };
        mockResponse = {};
        mockNext = jest.fn();
    });

    afterEach(() => {
        jest.clearAllMocks();
    });

    it('should pass if client secret is valid', () => {
        mockRequest.headers['x-client-secret'] = 'validSecret';
        mockRequest.storeIntegrationAccess = { clientSecret: 'validSecret' };

        middleware.use(mockRequest, mockResponse, mockNext);

        expect(mockNext).toHaveBeenCalled();
    });

    it('should throw UnauthorizedException if client secret is missing', () => {
        expect(() => middleware.use(mockRequest, mockResponse, mockNext)).toThrow(UnauthorizedException);
        expect(mockNext).not.toHaveBeenCalled();
    });

    it('should throw UnauthorizedException if client secret is invalid', () => {
        mockRequest.headers['x-client-secret'] = 'invalidSecret';
        mockRequest.storeIntegrationAccess = { clientSecret: 'validSecret' };

        expect(() => middleware.use(mockRequest, mockResponse, mockNext)).toThrow(UnauthorizedException);
        expect(mockNext).not.toHaveBeenCalled();
    });
});
