import { StoreIntegrationAccessTokenValidateMiddleware } from './store-integration-access-token-validate.middleware';

describe('StoreIntegrationAccessTokenValidateMiddleware', () => {
  it('should be defined', () => {
    expect(new StoreIntegrationAccessTokenValidateMiddleware()).toBeDefined();
  });
});
