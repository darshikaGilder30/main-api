import {
    Injectable,
    NestMiddleware,
    UnauthorizedException
} from '@nestjs/common';
import { CacheHelper } from 'src/modules/utils/cache/cache-helper.service';

@Injectable()
export class StoreIntegrationAccessTokenValidateMiddleware
    implements NestMiddleware
{
    constructor(private cacheHelper: CacheHelper) {}

    async use(req: any, res: any, next: () => void) {
        const accessToken = req.headers['x-access-token'];
        if (accessToken) {
            const cacheKey = `${req.store.id}:line-app-access-token-${req.storeIntegrationAccess.clientId}-${accessToken}`;
            const cacheValue = await this.cacheHelper.get(cacheKey);
            if (cacheValue) {
                return next();
            }
        }

        throw new UnauthorizedException('Invalid access token');
    }
}
