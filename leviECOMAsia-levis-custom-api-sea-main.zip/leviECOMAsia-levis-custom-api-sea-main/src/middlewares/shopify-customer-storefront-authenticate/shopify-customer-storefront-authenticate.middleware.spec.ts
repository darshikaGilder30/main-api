import { ShopifyStorefrontApiService } from 'src/modules/shopify-storefront-api/shopify-storefront-api.service';
import { ShopifyCustomerStorefrontAuthenticateMiddleware } from './shopify-customer-storefront-authenticate.middleware';
import { HttpException } from '@nestjs/common';
import { Test, TestingModule } from '@nestjs/testing';

describe('ShopifyCustomerStorefrontAuthenticateMiddleware', () => {
  let middleware: ShopifyCustomerStorefrontAuthenticateMiddleware;
  let shopifyStorefrontApiServiceMock: jest.Mocked<ShopifyStorefrontApiService>;

  beforeEach(async () => {
    shopifyStorefrontApiServiceMock = {
      verifyCustomerToken: jest.fn(),
    } as any;

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        ShopifyCustomerStorefrontAuthenticateMiddleware,
        {
          provide: ShopifyStorefrontApiService,
          useValue: shopifyStorefrontApiServiceMock,
        },
      ],
    }).compile();

    middleware = module.get<ShopifyCustomerStorefrontAuthenticateMiddleware>(ShopifyCustomerStorefrontAuthenticateMiddleware);
  });

  it('should be defined', () => {
    expect(middleware).toBeDefined();
  });

  it('should move next if logged_in_customer_id is exist', async () => {
    const req = { query: { logged_in_customer_id: 20  } };
    const res = {};
    const next = jest.fn();

    await middleware.use(req, res, next);

    expect(next).toHaveBeenCalled();
  });

  it('should throw HttpException if the authorization is not found', async () => {
    const req = { query: {}, headers: {} };
    const res = {};
    const next = jest.fn();

    await expect(() => middleware.use(req, res, next)).rejects.toThrowError(
      HttpException,
    );

    expect(next).not.toHaveBeenCalled();
  });

  it('should throw HttpException if the token is not found', async () => {
    const req = { query: {}, headers: { authorization: 'example' } };
    const res = {};
    const next = jest.fn();

    await expect(() => middleware.use(req, res, next)).rejects.toThrowError(
      HttpException,
    );

    expect(next).not.toHaveBeenCalled();
  });

  it('should throw HttpException if the token payload has no data', async () => {
    const mockresult = {};
    const req = { query: {}, headers: { authorization: 'example token' } };
    const res = {};
    const next = jest.fn();

    shopifyStorefrontApiServiceMock.verifyCustomerToken.mockResolvedValueOnce(mockresult);

    await expect(() => middleware.use(req, res, next)).rejects.toThrowError(
      HttpException,
    );

    expect(next).not.toHaveBeenCalled();
  });

  it('should set logged_in_customer_id if the token payload data is exist', async () => {
    const mockresult = { sub: 20 };
    const req = { query: { logged_in_customer_id: null}, headers: { authorization: 'example token' } };
    const res = {};
    const next = jest.fn();

    middleware.use(req, res, next);
    shopifyStorefrontApiServiceMock.verifyCustomerToken.mockResolvedValueOnce(mockresult);

    expect(req.query.logged_in_customer_id).toEqual(mockresult?.sub);
    expect(next).not.toHaveBeenCalled();
  });
});