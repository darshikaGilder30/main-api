import { HttpException, Injectable, NestMiddleware } from '@nestjs/common';
import { ShopifyStorefrontApiService } from 'src/modules/shopify-storefront-api/shopify-storefront-api.service';

@Injectable()
export class ShopifyCustomerStorefrontAuthenticateMiddleware
    implements NestMiddleware
{
	constructor(private shopifyStorefrontApiService: ShopifyStorefrontApiService) {}

    use(req: any, res: any, next: () => void) {
		if (!req.query.logged_in_customer_id) {
			const { authorization } = req.headers;
			if (!authorization) {
				throw new HttpException('Unauthorized', 401);
			}

			const token = authorization.split(' ')[1];
			if (!token) {
				throw new HttpException('Unauthorized', 401);
			}

			const tokenPayload = this.shopifyStorefrontApiService.verifyCustomerToken(req.store, token);

			if (!tokenPayload?.sub) {
				throw new HttpException('Unauthorized', 401);
			}

			req.query.logged_in_customer_id = tokenPayload.sub;
		}

        next();
    }
}
