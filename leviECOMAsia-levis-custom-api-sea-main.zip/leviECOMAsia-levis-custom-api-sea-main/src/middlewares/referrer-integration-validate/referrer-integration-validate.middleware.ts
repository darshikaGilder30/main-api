import { HttpException, Injectable, NestMiddleware } from '@nestjs/common';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';

@Injectable()
export class ReferrerIntegrationValidateMiddleware implements NestMiddleware {
    use(req: any, res: any, next: () => void) {
        const store: StoreDto = req.store;
        
        if (!store.storeIntegrations.referrer?.active) {
            throw new HttpException('Referrer integration not found.', 404);
        }

        next();
    }
}
