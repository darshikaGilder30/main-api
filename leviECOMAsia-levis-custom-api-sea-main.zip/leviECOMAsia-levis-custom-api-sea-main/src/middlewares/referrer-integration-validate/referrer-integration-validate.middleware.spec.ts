import { Test, TestingModule } from '@nestjs/testing';
import { HttpException } from '@nestjs/common';
import { ReferrerIntegrationValidateMiddleware } from './referrer-integration-validate.middleware';

describe('ReferrerIntegrationValidateMiddleware', () => {
    let middleware: ReferrerIntegrationValidateMiddleware;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ReferrerIntegrationValidateMiddleware],
    }).compile();

    middleware = module.get<ReferrerIntegrationValidateMiddleware>(
        ReferrerIntegrationValidateMiddleware,
    );
  });

  it('should be defined', () => {
    expect(middleware).toBeDefined();
  });
  
    it('should throw HttpException if Store integration is not active', () => {
      const req = { store: { storeIntegrations: { referrer: { active: false } } } };
      const res = {};
      const next = jest.fn();
  
      expect(() => middleware.use(req, res, next)).toThrowError(HttpException);
      expect(next).not.toHaveBeenCalled();
    });

    it('should move next if Store integration is active', () => {
        const req = { store: { storeIntegrations: { referrer: { active: true } } } };
        const res = {};
        const next = jest.fn();
    
        middleware.use(req, res, next);
        expect(next).toHaveBeenCalled();
      });
});
