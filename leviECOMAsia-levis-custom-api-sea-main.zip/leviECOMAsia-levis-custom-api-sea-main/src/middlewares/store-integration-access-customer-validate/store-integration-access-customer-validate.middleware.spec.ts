import { StoreIntegrationAccessCustomerValidateMiddleware } from './store-integration-access-customer-validate.middleware';
import { JwtService } from '@nestjs/jwt';
import { HttpException } from '@nestjs/common';

describe('StoreIntegrationAccessCustomerValidateMiddleware', () => {
  let middleware: StoreIntegrationAccessCustomerValidateMiddleware;
  let jwtService: JwtService;
  let req: any;
  let res: any;
  let next: jest.Mock;

  beforeEach(() => {
    jwtService = new JwtService({
      secret: 'your_secret_key', // Provide your secret key here
    });
    middleware = new StoreIntegrationAccessCustomerValidateMiddleware(jwtService);
    req = { headers: {} };
    res = {};
    next = jest.fn();
  });

  it('should throw 401 if no authorization header is found', () => {
    expect(() => middleware.use(req, res, next)).toThrow(HttpException);
    expect(next).not.toHaveBeenCalled();
  });

  it('should throw 401 if token is invalid', () => {
    req.headers.authorization = 'Bearer invalid_token';
    expect(() => middleware.use(req, res, next)).toThrow(HttpException);
    expect(next).not.toHaveBeenCalled();
  });

  it('should throw 401 if token is invalid', () => {
    const token = jwtService.sign({});
    req.headers.authorization = `Bearer ${token}`;
    expect(() => middleware.use(req, res, next)).toThrow(HttpException);
    expect(next).not.toHaveBeenCalled();
  });

  it('should set logged_in_customer_id in request query if token is valid', () => {
    const token = jwtService.sign({ data: { id: 'user_id' } });
    req.headers.authorization = `Bearer ${token}`;
    expect(() => middleware.use(req, res, next)).toThrow(HttpException);
  });
});
