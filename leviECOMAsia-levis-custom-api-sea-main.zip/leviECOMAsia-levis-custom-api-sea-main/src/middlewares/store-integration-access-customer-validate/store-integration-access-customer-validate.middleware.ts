import { HttpException, Injectable, NestMiddleware } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';

@Injectable()
export class StoreIntegrationAccessCustomerValidateMiddleware
    implements NestMiddleware
{
    constructor(private jwtService: JwtService) {}

    use(req: any, res: any, next: () => void) {
        const { authorization } = req.headers;

        if (!authorization) {
            throw new HttpException('No authorization header found.', 401);
        }
        try {
            const token = authorization.split(' ')[1];
            const decoded = this.jwtService.decode(token);
            if (!decoded) {
                throw new HttpException('Invalid token.', 401);
            }
			req.query.logged_in_customer_id = decoded['data'].id;

            next();
        } catch (error) {
            throw new HttpException('Invalid token.', 401);
        }
    }
}
