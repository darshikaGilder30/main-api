import { ShopifyCustomerAuthenticateMiddleware } from './shopify-customer-authenticate.middleware';
import { HttpException } from '@nestjs/common';
import { Test, TestingModule } from '@nestjs/testing';
import { ShopifyAdminApiService } from 'src/modules/shopify-admin-api/shopify-admin-api.service';

describe('ShopifyCustomerAuthenticateMiddleware', () => {
  let middleware: ShopifyCustomerAuthenticateMiddleware;
  let shopifyAdminApiServiceMock: jest.Mocked<ShopifyAdminApiService>;

  beforeEach(async () => {
    shopifyAdminApiServiceMock = {
      getCustomer: jest.fn(),
    } as any;

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        ShopifyCustomerAuthenticateMiddleware,
        {
          provide: ShopifyAdminApiService,
          useValue: shopifyAdminApiServiceMock,
        },
      ],
    }).compile();

    middleware = module.get<ShopifyCustomerAuthenticateMiddleware>(ShopifyCustomerAuthenticateMiddleware);
  });

  it('should be defined', () => {
    expect(middleware).toBeDefined();
  });

  it('should set req.customer if the shopifyCustomer is found', async () => {
    const mockresult = { success: true, data: {}, message: '', };
    const req = { query: { logged_in_customer_id: 20  }, store: 'store 1', customer: '' };
    const res = {};
    const next = jest.fn();

    
    shopifyAdminApiServiceMock.getCustomer.mockResolvedValueOnce(mockresult);

    await middleware.use(req, res, next);

    expect(next).toHaveBeenCalled();
    expect(req.customer).toEqual({});
  });

  it('should throw HttpException if the shopifyCustomer is not found', async () => {
    const req = { query: { logged_in_customer_id: 20 } };
    const res = {};
    const next = jest.fn();

    shopifyAdminApiServiceMock.getCustomer.mockResolvedValueOnce(null);

    await expect(() => middleware.use(req, res, next)).rejects.toThrowError(
      HttpException,
    );

    expect(next).not.toHaveBeenCalled();
  });

  it('should throw HttpException if the shopifyCustomer has no data', async () => {
    const mockresult = { success: true, data: null, message: '', };
    const req = { query: { logged_in_customer_id: 200  }, store: 'store 1', customer: '' };
    const res = {};
    const next = jest.fn();

    shopifyAdminApiServiceMock.getCustomer.mockResolvedValueOnce(mockresult);

    await expect(() => middleware.use(req, res, next)).rejects.toThrowError(
      HttpException,
    );

    expect(next).not.toHaveBeenCalled();
  });

  it('should throw HttpException if logged_in_customer_id parameter is missing', async () => {
    const req = { query: {} };
    const res = {};
    const next = jest.fn();

    await expect(() => middleware.use(req, res, next)).rejects.toThrowError(
      HttpException,
    );

    expect(next).not.toHaveBeenCalled();
  });
});
