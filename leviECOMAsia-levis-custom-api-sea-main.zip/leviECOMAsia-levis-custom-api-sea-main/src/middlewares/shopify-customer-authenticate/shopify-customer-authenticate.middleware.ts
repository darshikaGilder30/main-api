import { HttpException, Injectable, NestMiddleware } from '@nestjs/common';
import { ShopifyAdminApiService } from 'src/modules/shopify-admin-api/shopify-admin-api.service';

@Injectable()
export class ShopifyCustomerAuthenticateMiddleware implements NestMiddleware {
    constructor(private shopifyAdminApiService: ShopifyAdminApiService) {}

    async use(req: any, res: any, next: () => void) {
        if (req.query.logged_in_customer_id) {
            const shopifyCustomer = await this.shopifyAdminApiService
                .getCustomer(req.store, req.query.logged_in_customer_id)

			if (shopifyCustomer.success && shopifyCustomer.data) {
				req.customer = shopifyCustomer.data;
				
				return next();
			}

			throw new HttpException('Unauthorized', 401);
        }

        throw new HttpException('Customer Unauthorized', 401);
    }
}
