import { HttpException } from '@nestjs/common';
import { Test, TestingModule } from '@nestjs/testing';
import { StoreMiddleware } from './store.middleware';
import { StoresService } from 'src/entities/stores/stores.service';
import { CacheHelper } from 'src/modules/utils/cache/cache-helper.service';

describe('StoreMiddleware', () => {
  let middleware: StoreMiddleware;
  let storesService: StoresService;
  // Mock dependencies
  const storesServiceMock = {
    findByShop: jest.fn(),
  };
  const cacheHelperMock = {
    remember: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        StoreMiddleware,
        { provide: StoresService, useValue: storesServiceMock },
        { provide: CacheHelper, useValue: cacheHelperMock },
      ],
    }).compile();

    middleware = module.get<StoreMiddleware>(StoreMiddleware);
  });

  it('should set req.store and call next() when store is found and active', async () => {
    // Mock data
    const req = { query: { shop: 'example_shop' }, store: null};
    const storeData = { id: 1, active: true };

    // Mock behavior of dependencies
    storesServiceMock.findByShop.mockResolvedValueOnce(storeData);
    // cacheHelperMock.remember.mockResolvedValueOnce(storeData);
    cacheHelperMock.remember.mockImplementation((key, seconds, callback) => {
      // Check the parameters
      expect(key).toBe(`store_${req.query.shop}`);
      expect(seconds).toBe(3600);
      expect(callback).toBeInstanceOf(Function);

      // Call the callback function to simulate a cache miss
      return callback();
    });

    // Mock next function
    const next = jest.fn();

    // Invoke the middleware
    await middleware.use(req, {}, next);

    // Assert that req.store is set and next is called
    expect(req.store).toEqual(storeData);
    expect(next).toHaveBeenCalled();
  });

  it('should throw 404 HttpException when store is not found', async () => {
    // Mock data
    const req = { query: { shop: 'example_shop' } };

    // Mock behavior of dependencies
    storesServiceMock.findByShop.mockResolvedValueOnce(null);

    // Invoke the middleware
    await expect(middleware.use(req, {}, jest.fn())).rejects.toThrowError(HttpException);
  });

  it('should throw 401 HttpException when shop parameter is missing', async () => {
    // Mock data
    const req = { query: {} };

    // Invoke the middleware
    await expect(middleware.use(req, {}, jest.fn())).rejects.toThrowError(HttpException);
  });

  it('should call cacheHelper.remember with correct arguments', async () => {
    const shop = 'example_shop';
    const storeData = { id: 1, active: true };
    const rememberArgs = [`store_${shop}`, 3600, expect.any(Function)];

    storesServiceMock.findByShop.mockResolvedValueOnce(storeData)
    cacheHelperMock.remember.mockImplementation((key, seconds, callback) => {
      // Check the parameters
      expect(key).toBe(`store_${shop}`);
      expect(seconds).toBe(3600);
      expect(callback).toBeInstanceOf(Function);

      // Call the callback function to simulate a cache miss
      return callback();
    });

    // Invoke the middleware
    await middleware.use({ query: { shop } }, {}, jest.fn());

    // Assert that cacheHelper.remember is called with correct arguments
    expect(cacheHelperMock.remember).toHaveBeenCalledWith(...rememberArgs);
  });
  
});
