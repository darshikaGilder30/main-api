import { HttpException, Injectable, NestMiddleware } from '@nestjs/common';
import { StoresService } from 'src/entities/stores/stores.service';
import { CacheHelper } from 'src/modules/utils/cache/cache-helper.service';

@Injectable()
export class StoreMiddleware implements NestMiddleware {
    constructor(
        private storesService: StoresService,
        private cacheHelper: CacheHelper
    ) {}

    async use(req: any, res: any, next: () => void) {

        const shop = req.query.shop;
        if (shop) {
            const store = await this.cacheHelper.remember(
                `store_${shop}`,
                3600,
                async () => {
                    return await this.storesService.findByShop(shop);
                }
            );

            if (store && store.active) {
                req.store = store;

                return next();
            }

            throw new HttpException('Store not found.', 404);
        }

        throw new HttpException(
            'Missing shop parameter. Please add ?shop=your-development-shop.myshopify.com to your request',
            401
        );
    }
}
