import {
	HttpException,
    Injectable,
    NestMiddleware
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { HmacService } from 'src/modules/utils/hmac.service';

@Injectable()
export class ShopifyProxySignatureValidateMiddleware implements NestMiddleware {
    constructor(private configService: ConfigService) {}

	// hmac singature validation middleware
    use(req: any, res: any, next: () => void) {
        if (!HmacService.isValidHmac(req.query, this.configService.get('shopify.appProxy.clientSecret'), (req.query['signature'] ? 'signature' : 'hmac')))
            throw new HttpException('Invalid signature', 401);

        next();
    }
}
