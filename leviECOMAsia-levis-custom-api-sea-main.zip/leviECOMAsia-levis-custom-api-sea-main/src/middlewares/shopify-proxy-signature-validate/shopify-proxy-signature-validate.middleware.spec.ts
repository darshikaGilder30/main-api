import { Test, TestingModule } from '@nestjs/testing';
import { ConfigService } from '@nestjs/config';
import { HttpException, UnauthorizedException } from '@nestjs/common';
import * as crypto from 'crypto';

import { ShopifyProxySignatureValidateMiddleware } from './shopify-proxy-signature-validate.middleware';

describe('ShopifyProxySignatureValidateMiddleware', () => {
    let middleware: ShopifyProxySignatureValidateMiddleware;
    let configService: ConfigService;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [
                ShopifyProxySignatureValidateMiddleware,
                {
                    provide: ConfigService,
                    useValue: {
                        get: jest.fn((key) => {
                            if (key === 'shopify.appProxy.clientSecret') {
                                return 'your-client-secret';
                            }
                        })
                    }
                }
            ]
        }).compile();

        middleware = module.get<ShopifyProxySignatureValidateMiddleware>(
            ShopifyProxySignatureValidateMiddleware
        );
        configService = module.get<ConfigService>(ConfigService);
    });

    it('should be defined', () => {
        expect(middleware).toBeDefined();
    });

    it('should call next() if the signature is valid', () => {
        const req = {
            query: {
                shop: 'example.myshopify.com',
                timestamp: '1234567890',
                signature: 'a valid signature' // Replace with a valid signature for your test
            }
        };
        const res = {};
        const next = jest.fn();

        const createHmacSpy = jest
            .spyOn(crypto, 'createHmac')
            .mockReturnValueOnce({
                update: jest.fn().mockReturnThis(),
                digest: jest.fn(() => 'a valid signature') // Replace with a valid signature for your test
            } as any);

        middleware.use(req, res, next);

        expect(next).toHaveBeenCalled();
        expect(createHmacSpy).toHaveBeenCalledWith(
            'sha256',
            'your-client-secret'
        ); // Replace 'your-client-secret' with the actual client secret

        createHmacSpy.mockRestore();
    });

    it('should throw UnauthorizedException if the signature is invalid', () => {
        const req = {
            query: {
                shop: 'example.myshopify.com',
                timestamp: '1234567890',
                signature: 'invalid signature'
            }
        };
        const res = {};
        const next = jest.fn();

        const createHmacSpy = jest
            .spyOn(crypto, 'createHmac')
            .mockReturnValueOnce({
                update: jest.fn().mockReturnThis(),
                digest: jest.fn(() => 'a different signature')
            } as any);

        expect(() => middleware.use(req, res, next)).toThrowError(
            new UnauthorizedException('Invalid signature')
        );

        expect(next).not.toHaveBeenCalled();

        createHmacSpy.mockRestore();
    });

	it('should throw HttpException if the signature is missing', () => {
		const req = {
			query: {
				shop: 'example.myshopify.com',
				timestamp: '1234567890'
			}
		};
		const res = {};
		const next = jest.fn();

		expect(() => middleware.use(req, res, next)).toThrowError(
			new HttpException('Invalid signature', 401)
		);

		expect(next).not.toHaveBeenCalled();
	});
});
