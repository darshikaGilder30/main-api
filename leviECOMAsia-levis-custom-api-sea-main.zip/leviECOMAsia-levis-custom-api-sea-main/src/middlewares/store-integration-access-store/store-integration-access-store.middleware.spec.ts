import { StoreIntegrationAccessStoreMiddleware } from './store-integration-access-store.middleware';
import { StoreIntegrationAcessessService } from 'src/entities/store-integration-accesses/store-integration-accesses.service';
import { CacheHelper } from 'src/modules/utils/cache/cache-helper.service';
import { UnauthorizedException } from '@nestjs/common';

describe('StoreIntegrationAccessStoreMiddleware', () => {
  let middleware: StoreIntegrationAccessStoreMiddleware;
  let storeIntegrationAcessessService: StoreIntegrationAcessessService;
  let cacheHelper: CacheHelper;
  let req: any;
  let res: any;
  let next: jest.Mock;

  beforeEach(() => {
    storeIntegrationAcessessService = {} as any as StoreIntegrationAcessessService;
    cacheHelper = {} as any as CacheHelper;
    middleware = new StoreIntegrationAccessStoreMiddleware(storeIntegrationAcessessService, cacheHelper);
    req = { headers: {} };
    res = {};
    next = jest.fn();
  });

  it('should throw UnauthorizedException if x-client-id header is missing', async () => {
    await expect(middleware.use(req, res, next)).rejects.toThrow(UnauthorizedException);
    expect(next).not.toHaveBeenCalled();
  });

  it('should throw UnauthorizedException if store integration access is not found', async () => {
    req.headers['x-client-id'] = 'invalid_client_id';
    jest.spyOn(cacheHelper, 'remember').mockResolvedValueOnce(undefined);
    await expect(middleware.use(req, res, next)).rejects.toThrow(UnauthorizedException);
    expect(next).not.toHaveBeenCalled();
  });

  it('should set req.storeIntegrationAccess and req.store if store integration access is found', async () => {
    const clientId = 'valid_client_id';
    req.headers['x-client-id'] = clientId;
    const storeIntegrationAccess = { store: { /* store data */ } };
    jest.spyOn(cacheHelper, 'remember').mockResolvedValueOnce(storeIntegrationAccess);
    await middleware.use(req, res, next);
    expect(req.storeIntegrationAccess).toEqual(storeIntegrationAccess);
    expect(req.store).toEqual(storeIntegrationAccess.store);
    expect(next).toHaveBeenCalled();
  });
});
