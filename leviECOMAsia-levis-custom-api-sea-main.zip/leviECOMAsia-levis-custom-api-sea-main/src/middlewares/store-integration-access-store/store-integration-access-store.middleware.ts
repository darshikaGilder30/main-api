import {
    Injectable,
    NestMiddleware,
    UnauthorizedException
} from '@nestjs/common';
import { StoreIntegrationAcessessService } from 'src/entities/store-integration-accesses/store-integration-accesses.service';
import { CacheHelper } from 'src/modules/utils/cache/cache-helper.service';

@Injectable()
export class StoreIntegrationAccessStoreMiddleware implements NestMiddleware {
    constructor(
        private readonly storeIntegrationAcessessService: StoreIntegrationAcessessService,
        private cacheHelper: CacheHelper
    ) {}
    async use(req: any, res: any, next: () => void) {
		
        const clientId = req.headers['x-client-id'];
        
        if (clientId) {
            const storeIntegrationAccess = await this.cacheHelper.remember(
                `store-integration-access-${clientId}`,
				3600,
                async () => {
                    return await this.storeIntegrationAcessessService.findClient(
                        clientId
                    );
                }
            );

            if (storeIntegrationAccess) {
                
                req.storeIntegrationAccess = storeIntegrationAccess;
                req.store = storeIntegrationAccess.store;
                return next();
            }
        }

        throw new UnauthorizedException('Invalid client id');
    }
}
