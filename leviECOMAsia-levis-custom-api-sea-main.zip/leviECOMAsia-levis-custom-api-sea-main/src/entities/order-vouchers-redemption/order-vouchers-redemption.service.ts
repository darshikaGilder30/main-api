import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import {
    EntityType,
    OrderVoucherRedemption,
    Status,
} from './order-voucher-redemption.entity'
import { Repository } from 'typeorm'
import { CreateOrderVoucherRedemptionDto } from './dto/order-voucher-redemption-create.dto'
import { UpdateOrderVoucherRedemptionDto } from './dto/order-voucher-redemption-update.dto'
import { StoreDto } from '../stores/dto/stores.dto'

@Injectable()
export class OrderVouchersRedemptionService {
    constructor(
        @InjectRepository(OrderVoucherRedemption)
        private orderLoyaltyRedemptionRepository: Repository<OrderVoucherRedemption>
    ) {}

    async create(
        createOrderVoucherRedemptionDto: CreateOrderVoucherRedemptionDto
    ): Promise<OrderVoucherRedemption> {
        createOrderVoucherRedemptionDto =
            this.orderLoyaltyRedemptionRepository.create(
                createOrderVoucherRedemptionDto
            )
        return await this.orderLoyaltyRedemptionRepository.save(
            createOrderVoucherRedemptionDto
        )
    }

    async update(updateOrderLoyaltyRedemption: OrderVoucherRedemption): Promise<OrderVoucherRedemption> {
        return await this.orderLoyaltyRedemptionRepository.save(
            updateOrderLoyaltyRedemption
        )
    }

    async findOne(store: StoreDto, query): Promise<OrderVoucherRedemption> {
        return await this.orderLoyaltyRedemptionRepository.findOne({
            where: {
                storeId: store.id,
                ...query,
            },
            order: {
                createdAt: 'DESC',
            }
        })
    }
}
