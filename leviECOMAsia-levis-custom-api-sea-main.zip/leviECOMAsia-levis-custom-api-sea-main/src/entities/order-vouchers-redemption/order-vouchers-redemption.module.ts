import { Module } from '@nestjs/common'
import { OrderVouchersRedemptionService } from './order-vouchers-redemption.service'
import { TypeOrmModule } from '@nestjs/typeorm'
import { OrderVoucherRedemption } from './order-voucher-redemption.entity'

@Module({
    imports: [TypeOrmModule.forFeature([OrderVoucherRedemption])],
    controllers: [],
    providers: [OrderVouchersRedemptionService],
    exports: [OrderVouchersRedemptionService],
})
export class OrderVouchersRedemptionModule {}
