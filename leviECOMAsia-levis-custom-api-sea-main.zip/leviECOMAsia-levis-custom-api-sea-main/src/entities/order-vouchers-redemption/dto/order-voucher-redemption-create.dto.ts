import { IsEnum, IsNumber, IsOptional, IsString } from 'class-validator'
import { EntityType, Status } from '../order-voucher-redemption.entity'

export interface voucherNo {
    VoucherNo: string
}

export class CreateOrderVoucherRedemptionDto {
    @IsString()
    orderId: string
    
    @IsNumber()
    storeId: number

    @IsString()
    vouchersRedeemed?: string

    @IsEnum(EntityType)
    entity: EntityType

    @IsEnum(Status)
    status: Status

    @IsNumber()
    attempt?: number

    @IsOptional()
    @IsString()
    returnMessage?: string

    @IsString()
    entityId: string

    transactionId: string
}
