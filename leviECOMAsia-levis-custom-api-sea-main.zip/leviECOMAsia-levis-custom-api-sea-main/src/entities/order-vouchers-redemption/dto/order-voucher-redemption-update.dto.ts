import { PartialType } from '@nestjs/mapped-types'
import { CreateOrderVoucherRedemptionDto } from './order-voucher-redemption-create.dto'

export class UpdateOrderVoucherRedemptionDto extends PartialType(
    CreateOrderVoucherRedemptionDto
) {}
