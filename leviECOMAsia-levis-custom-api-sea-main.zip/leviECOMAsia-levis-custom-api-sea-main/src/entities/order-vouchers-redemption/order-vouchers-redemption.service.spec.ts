import { Test, TestingModule } from '@nestjs/testing';
import { OrderVouchersRedemptionService } from './order-vouchers-redemption.service';

describe('OrderVouchersRedemptionService', () => {
  let service: OrderVouchersRedemptionService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [OrderVouchersRedemptionService],
    }).compile();

    service = module.get<OrderVouchersRedemptionService>(OrderVouchersRedemptionService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
