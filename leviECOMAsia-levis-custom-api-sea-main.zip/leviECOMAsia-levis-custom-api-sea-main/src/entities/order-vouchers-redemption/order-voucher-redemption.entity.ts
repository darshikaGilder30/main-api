import {
    Entity,
    Column,
    PrimaryGeneratedColumn,
    CreateDateColumn,
    UpdateDateColumn,
    ManyToOne,
    JoinColumn,
    Index,
} from 'typeorm'
import { Store } from '../stores/stores.entity';

export enum Status {
    SUCCESS = 'success',
    PENDING = 'pending',
    FAILED = 'failed',
    RETRY = 'retry',
    Cancelled = 'cancelled'
}

export enum EntityType {
    ORDER = 'order',
    REFUND = 'refund',
    VOID = 'void',
}

@Entity({ name: 'orderVoucherRedemptions', synchronize: false })
export class OrderVoucherRedemption {
    @PrimaryGeneratedColumn()
    id: number

    @Column({ nullable: false, type: 'varchar', length: 255 })
    orderId: string

    @Column({ nullable: false, type: 'varchar', length: 255 })
    entityId: string

    @Index()
    @Column({ nullable: false })
    storeId: number

    @ManyToOne(() => Store, (store) => store.orderVoucherRedemptions)
    @JoinColumn({ name: 'storeId' })
    store: Store;

    @Column({ type: 'text', nullable: true, default: null })
    vouchersRedeemed: string

    @Column({ type: 'enum', enum: EntityType, nullable: false })
    entity: EntityType

    @Column({ type: 'varchar', nullable: true, length: 255 })
    transactionId: string

    @Column({
        type: 'enum',
        enum: Status,
        default: 'pending',
    })
    status: Status

    @Column({ type: 'varchar', length: 255, default: null })
    returnMessage: string

    @Column({ type: 'int', default: 0})
    attempt: number

    @UpdateDateColumn()
    updatedAt: Date

    @CreateDateColumn()
    createdAt: Date
}
