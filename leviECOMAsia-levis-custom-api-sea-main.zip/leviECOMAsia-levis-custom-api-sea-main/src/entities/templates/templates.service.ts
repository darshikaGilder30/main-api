import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { Template } from './templates.entity';
import { TemplateDto } from './dto/templates.dto';

@Injectable()
export class TemplatesService {
    constructor(
        @InjectRepository(Template)
        private templateRepository: Repository<Template>
    ) {}

    async findTemplate(type: string, templateCode, language = 'en'): Promise<Template> {
        return await this.templateRepository.findOne({
            where: {
                type,
                language,
                templateCode,
                status: true
            }
        });
    }

    async createTemplate(template: TemplateDto): Promise<Template> {
        return this.templateRepository.save(template);
    }
}
