import { Type } from 'class-transformer';
import { IsBoolean, IsEnum, IsOptional, IsString } from 'class-validator';

export class MetaDto {
    @IsString()
    subject: string;

    @IsString()
    from: string;
}

export class TemplateDto {
    @IsEnum(['email', 'sms'])
    type: string;

    @IsString()
    template: string;

    @Type(() => MetaDto)
    @IsOptional()
    meta: MetaDto;

    @IsOptional()
    @IsBoolean()
    status: boolean;

    @IsString()
    @IsOptional()
    language: string;
}
