import {
    Column,
    Entity,
    PrimaryGeneratedColumn,
    CreateDateColumn,
    UpdateDateColumn
} from 'typeorm';

@Entity({ name: 'templates', synchronize: true })
export class Template {
    @PrimaryGeneratedColumn({ type: 'int' })
    id: number;

    @Column({ type: 'enum', enum: ['sms', 'email'] })
    type: string;

    @Column({ type: 'text', default: null })
    template: string;

    @Column({ type: 'varchar', length: 128 })
    templateCode: string;

    @Column({ type: 'json', nullable: true })
    meta: object;

    @Column({ type: 'boolean', default: true })
    status: boolean;

    @Column({ type: 'varchar', length: 255 })
    language: string;

    @CreateDateColumn()
    createdAt: Date;

    @UpdateDateColumn({ nullable: true })
    updatedAt: Date;
}
