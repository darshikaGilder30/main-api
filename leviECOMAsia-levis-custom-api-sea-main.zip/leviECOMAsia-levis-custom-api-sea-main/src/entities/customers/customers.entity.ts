import {
    Entity,
    Column,
    Index,
    ManyToOne,
    JoinColumn,
    PrimaryGeneratedColumn,
    CreateDateColumn,
    UpdateDateColumn
} from 'typeorm'
import { Store } from '../stores/stores.entity'

@Entity({ name: 'customers', synchronize: false })
@Index('cutomerId_storeId_integration', ['cutomerId', 'storeId', 'integration'], { unique: true })
export class Customer {
    @PrimaryGeneratedColumn()
    id: number

    @Column({ nullable: false, type: 'bigint' })
    cutomerId: number

    @Index()
    @Column({ nullable: false })
    storeId: number

    @ManyToOne(() => Store, (store) => store.customers)
    @JoinColumn({ name: 'storeId' })
    store: Store

    @Column({ type: 'jsonb', nullable: true })
    rawData: object

    @Column({ type: 'enum', nullable: false, enum: ['ascentis', 'xStore'] })
    integration: string

    @Column({
        type: 'enum',
        enum: ['success', 'failed', 'error', 'pending', 'retry'],
        default: 'pending',
    })
    lastProcessedStatus: string

    @Column({ type: 'varchar', nullable: true })
    lastProcessedMessage: string

    @CreateDateColumn()
    createdAt: Date

    @UpdateDateColumn({ nullable: true })
    updatedAt: Date
}
