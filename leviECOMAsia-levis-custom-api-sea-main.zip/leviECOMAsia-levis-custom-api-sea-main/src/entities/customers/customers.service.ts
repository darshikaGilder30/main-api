import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Customer } from './customers.entity';
import { Repository } from 'typeorm';
import { StoreDto } from '../stores/dto/stores.dto';
import { AuthUserInfoTransformer } from 'src/modules/shopify-proxy/transformers/auth-user-info.transformer';

@Injectable()
export class CustomersService {
    logger = new Logger(CustomersService.name)
    constructor(
        @InjectRepository(Customer)
        private customerRepository: Repository<Customer>,
    ) { }

    async create(customer): Promise<Customer> {
        customer = this.customerRepository.create(customer)
        return await this.customerRepository.save(customer)
    }

    async update(customer): Promise<Customer> {
        return await this.customerRepository.save(customer)
    }

    async updateOrCreate(store: StoreDto, customer, integration): Promise<Customer> {
        let existingCustomer = await this.customerRepository.findOne({
            where: {
                cutomerId: customer.id,
                storeId: store.id,
                integration: integration,
            },
        })

        const tranformedCustomer = {
            cutomerId: customer.id,
            storeId: store.id,
            integration: integration,
        }

        if (!existingCustomer) {
            try {
                existingCustomer = await this.create(tranformedCustomer)
            } catch (error) {
                this.logger.warn(`concurrent event processing for ${customer.email}. Skipping failed one`)
                existingCustomer = null 
            }
        }

        return existingCustomer
    }

    isDataModfied(customer: Customer, newCustomer: AuthUserInfoTransformer, dataToValidate: string[]): boolean {
        const rawData = customer.rawData || {}
        let modified = false
        dataToValidate.forEach((data) => {
            if (rawData[data] !== newCustomer[data]) {
                modified = true
            }
        })

        return modified
    }
}
