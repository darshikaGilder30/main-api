import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { AudtiLogActionEnum } from './dto/audit-log-action-enum.dto';

@Entity({ name: 'auditLogs', synchronize: true })
export class AuditLog {
  @PrimaryGeneratedColumn({ type: 'int' })
  id: number;

  @Column({ name: 'model', nullable: false })
  model: string;

  @Column({ name: 'modelPrimaryKey', nullable: false })
  modelPrimaryKey: number;

  @Column({ name: 'beforeChange', nullable: true, type: 'json' })
  beforeChange: object;

  @Column({ name: 'afterChange', nullable: true, type: 'json' })
  afterChange: object;

  @Column({
    type: 'enum',
    enum: AudtiLogActionEnum,
    default: AudtiLogActionEnum.CREATE,
    nullable: false,
  })
  action: string;

  @CreateDateColumn()
  createdAt: Date;

  @Column({ name: 'createdBy', nullable: true, type: 'varchar' })
  createdBy: string;
}
