export enum AudtiLogActionEnum {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
}
