import {
    Column,
    Entity,
    PrimaryGeneratedColumn,
    CreateDateColumn,
    UpdateDateColumn,
    Index,
    JoinColumn,
    ManyToOne
} from 'typeorm';
import { Store } from '../stores/stores.entity';

@Entity({ name: 'stocks', synchronize: false })
@Index(['pc13', 'locationCode', 'storeId'], { unique: true })
export class Stocks {
    @PrimaryGeneratedColumn({ type: 'int' })
    id: number;

    @Column({ nullable: false })
    storeId: number

    @ManyToOne(() => Store, (store) => store.stocks)
    @JoinColumn({ name: 'storeId' })
    store: Store

    @Column({ type: 'varchar', length: 255 })
    pc13: string;

    @Column({ type: 'varchar', length: 255 })
    pc9: string;

    @Column({ type: 'varchar', length: 255 })
    locationCode: string;

    @Column({ type: 'numeric'})
    qty : number;

    @CreateDateColumn()
    createdAt: Date;

    @UpdateDateColumn({ nullable: true })
    updatedAt: Date;
}
