import { Test, TestingModule } from '@nestjs/testing';
import { StocksService } from './stocks.service';
import { getRepositoryToken } from '@nestjs/typeorm';
import { Stocks } from './stocks.entity';
import { Repository } from 'typeorm';

describe('StocksService', () => {
    let service: StocksService;
    let repository: Repository<Stocks>;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [
                StocksService,
                {
                    provide: getRepositoryToken(Stocks),
                    useClass: Repository
                }
            ]
        }).compile();

        service = module.get<StocksService>(StocksService);
        repository = module.get<Repository<Stocks>>(getRepositoryToken(Stocks));
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    describe('find', () => {
        it('should return an array of stocks', async () => {
            const result = [new Stocks()];
            jest.spyOn(repository, 'find').mockImplementation(() => Promise.resolve(result));
            expect(await service.find({})).toBe(result);
        })

        it('should return an array of stocks with a query', async () => {
            const result = [new Stocks()];
            jest.spyOn(repository, 'find').mockImplementation(() => Promise.resolve(result));
            expect(await service.find({ name: 'test' })).toBe(result);
        })
    });
});
