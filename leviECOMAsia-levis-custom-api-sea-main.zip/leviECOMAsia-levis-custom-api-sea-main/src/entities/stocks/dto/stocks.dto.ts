
export class StocksDto {
    id: number;
    storeId: number;
    pc13: string;
    pc9: string;
    locationCode: string;
    qty: number;
    createdAt?: Date;
    updatedAt?: Date;
}
