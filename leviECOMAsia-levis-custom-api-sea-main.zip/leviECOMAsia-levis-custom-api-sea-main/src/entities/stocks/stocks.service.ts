import { Injectable } from '@nestjs/common'
import { Stocks } from './stocks.entity'
import { Repository } from 'typeorm'
import { InjectRepository } from '@nestjs/typeorm'

@Injectable()
export class StocksService {
    constructor(
        @InjectRepository(Stocks)
        private stockRepository: Repository<Stocks>
    ) {}

    async find(query): Promise<Stocks[]> {
        return await this.stockRepository.find({
            where: query,
            order: {
                updatedAt: 'DESC',
                qty: 'DESC'
            },
            take: 150
        })
    }
}
