import { Module } from '@nestjs/common';
import { StocksService } from './stocks.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Stocks } from './stocks.entity';

@Module({
    imports: [TypeOrmModule.forFeature([Stocks])],
    providers: [StocksService],
    exports: [StocksService]
})
export class StocksModule {}
