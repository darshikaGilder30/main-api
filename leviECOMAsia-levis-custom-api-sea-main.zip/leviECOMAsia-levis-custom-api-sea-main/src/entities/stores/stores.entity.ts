import {
    Column,
    Entity,
    PrimaryGeneratedColumn,
    CreateDateColumn,
    UpdateDateColumn,
    OneToMany,
    OneToOne
} from 'typeorm';
import { StoreIntegration } from '../store-integrations/store-integrations.entity';
import { StoreIntegrationAccess } from '../store-integration-accesses/store-integration-accesses.entity';
import { OrderVoucherRedemption } from '../order-vouchers-redemption/order-voucher-redemption.entity';
import { Customer } from '../customers/customers.entity';
import { Stocks } from '../stocks/stocks.entity';

@Entity({ name: 'stores', synchronize: true })
export class Store {
    @PrimaryGeneratedColumn({ type: 'int' })
    id: number;

    @Column({ type: 'varchar', length: 255 })
    name: string;

    @Column({ type: 'boolean', default: false })
    active: boolean;

    @Column({ type: 'varchar', length: 255 })
    shop: string;

    @OneToMany(
        () => StoreIntegration,
        (storeIntegration) => storeIntegration.store
    )
    storeIntegrations: StoreIntegration[];

    @OneToMany(
        () => StoreIntegrationAccess,
        (storeIntegrationAccess) => storeIntegrationAccess.store
    )
    storeIntegrationAccesses: StoreIntegrationAccess[];

    @OneToMany(
        () => OrderVoucherRedemption,
        (orderVoucherRedemption) => orderVoucherRedemption.store
    )
    orderVoucherRedemptions: OrderVoucherRedemption[];

    @OneToMany(
        () => Customer,
        (customer) => customer.store
    )
    customers: Customer[];

    @OneToMany(
        () => Stocks,
        (store) => store.store
    )
    stocks: Stocks[];

    @CreateDateColumn()
    createdAt: Date;

    @UpdateDateColumn({ nullable: true })
    updatedAt: Date;
}
