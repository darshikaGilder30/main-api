import { Injectable } from '@nestjs/common';
import { Store } from './stores.entity';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';

@Injectable()
export class StoresService {
    constructor(
        @InjectRepository(Store)
        private storeRepository: Repository<Store>
    ) {}

    async findByShop(shop: string): Promise<Store> {
        return this.storeRepository.findOne({
            where: {
                shop
            },
            relations: ['storeIntegrations']
        });
    }
}
