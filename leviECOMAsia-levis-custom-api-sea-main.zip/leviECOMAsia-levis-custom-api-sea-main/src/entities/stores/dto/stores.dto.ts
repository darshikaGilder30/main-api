import { StoreIntegrationDto } from 'src/entities/store-integrations/dto/store-integrations.dto';

export class StoreDto {
    id: number;
    name: string;
    shop: string;
    storeIntegrations: {
        shopify: StoreIntegrationDto;
        ascentis?: StoreIntegrationDto;
        sms: StoreIntegrationDto;
        email: StoreIntegrationDto;
        referrer?: StoreIntegrationDto;
        line?: StoreIntegrationDto;
        xstore?: StoreIntegrationDto;
        stamps?: StoreIntegrationDto;
        salesData?: StoreIntegrationDto;
    };
    active?: boolean;
}
