import { Module } from '@nestjs/common';
import { StoresService } from './stores.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Store } from './stores.entity';

@Module({
    imports: [TypeOrmModule.forFeature([Store])],
    providers: [StoresService],
    exports: [StoresService]
})
export class StoresModule {}
