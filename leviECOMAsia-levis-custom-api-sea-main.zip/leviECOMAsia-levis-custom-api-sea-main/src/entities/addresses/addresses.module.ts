import { Module } from '@nestjs/common';
import { AddressesService } from './addresses.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Address } from './addresses.entity';
import { CustomLoggerService } from 'src/modules/utils/custom-logger.service';
import { StoresModule } from '../stores/stores.module';

@Module({
    imports: [TypeOrmModule.forFeature([Address]), StoresModule],
    providers: [AddressesService, CustomLoggerService],
    exports: [AddressesService]
})
export class AddressesModule {}
