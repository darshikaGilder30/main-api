import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Address } from './addresses.entity';
import { ILike, Repository } from 'typeorm';
import { promises } from 'fs';
import { CustomLoggerService } from 'src/modules/utils/custom-logger.service';
import { StoresService } from '../stores/stores.service';
import { ShopifyProxyAddressQueryDto } from 'src/modules/shopify-proxy/dto/shopify-proxy-address-query.dto';
import { StoreDto } from '../stores/dto/stores.dto';
import { Lang } from 'src/enums/lang.enum';

@Injectable()
export class AddressesService {
    private logger: CustomLoggerService;
    constructor(
        @InjectRepository(Address)
        private addressRepository: Repository<Address>,
        private customLoggerService: CustomLoggerService,
        private storeService: StoresService
    ) {
        this.customLoggerService.setContext(AddressesService.name);
        this.logger = customLoggerService;
    }

    async create(address): Promise<Address> {
        address = this.addressRepository.create(address);
        return await this.addressRepository.save(address);
    }

    async update(address): Promise<Address> {
        return await this.addressRepository.save(address);
    }

    async migrateFiles() {
        this.logger.debug('Migrating files');
        promises.readdir('data/').then(async (files) => {
            this.logger.debug(`Files found: ${files}`);
            if (files.length > 0) {
                for await (const file of files) {
                    this.logger.debug(`Migrating file: ${file}`);
                    const data = await promises.readFile(
                        `data/${file}`,
                        'utf8'
                    );
                    const {
                        store,
                        addresses,
                        lang = Lang.EN
                    } = JSON.parse(data);
                    for await (const storeName of store) {
                        const storeModel = await this.storeService.findByShop(
                            storeName
                        );
                        if (storeModel) {
                            this.logger.debug(
                                `Migrating addresses for store: ${storeName} with total addresses: ${addresses.length}`
                            );
                            // split the addresses into chunks of 1000
                            const chunkSize = 1000;
                            const chunkData = [];
                            addresses.forEach((address, index) => {
                                const chunkIndex = Math.floor(
                                    index / chunkSize
                                );
                                if (!chunkData[chunkIndex]) {
                                    chunkData[chunkIndex] = [];
                                }
                                chunkData[chunkIndex].push(address);
                            });

                            for await (const chunk of chunkData) {
                                await this.addressRepository
                                    .createQueryBuilder()
                                    .insert()
                                    .into(Address)
                                    .values(
                                        chunk.map((address) => ({
                                            storeId: storeModel.id,
                                            lang,
                                            province: address.province,
                                            provinceShortName:
                                                address.provinceShortName,
                                            city: address.city,
                                            cityShortName:
                                                address.cityShortName,
                                            district: address.district,
                                            districtShortName:
                                                address.districtShortName,
                                            rawData: address
                                        }))
                                    )
                                    .execute();
                                this.logger.debug(
                                    `Migrated addresses for store: ${storeName} with total addresses: ${chunk.length}`
                                );
                            }
                        }
                    }
                }
            }
        });
    }

    async find(
        store: StoreDto,
        query: ShopifyProxyAddressQueryDto & Address
    ): Promise<Address[]> {
        const queryBuilder = this.addressRepository
            .createQueryBuilder('addresses')
            .where({
                storeId: store.id,
                ...this.filter(query)
            })
            .take(query.limit || 10);

        if (
            query.province ||
            (query.city && query.province) ||
            (query.provinceShortName && query.city) ||
            query.provinceShortName
        ) {
            queryBuilder
                .select(['addresses.city as city'])
                .groupBy('addresses.city')
                .orderBy('addresses.city', 'ASC');
        } else if (query.city) {
            queryBuilder
                .select(['addresses.district as district'])
                .groupBy('addresses.district')
                .orderBy('addresses.district', 'ASC');
        }

        return await queryBuilder.getRawMany();
    }

    filter(query: ShopifyProxyAddressQueryDto & Address) {
        const filter = {};

        if (query.city) {
            filter['city'] = ILike(`%${query.city}%`);
        }

        if (query.district) {
            filter['district'] = ILike(`%${query.district}%`);
        }

        if (query.province) {
            filter['province'] = ILike(`%${query.province}%`);
        }

        if (query.provinceShortName) {
            filter['provinceShortName'] = ILike(`%${query.provinceShortName}%`);
        }

        if (query.locale) {
            filter['lang'] = query.locale;
        }

        return filter;
    }
}
