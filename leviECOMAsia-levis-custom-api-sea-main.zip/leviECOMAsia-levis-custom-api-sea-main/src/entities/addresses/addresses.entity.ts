import {
    Entity,
    Column,
    Index,
    ManyToOne,
    JoinColumn,
    PrimaryGeneratedColumn,
    CreateDateColumn,
    UpdateDateColumn
} from 'typeorm';
import { Store } from '../stores/stores.entity';
import { Lang } from 'src/enums/lang.enum';

@Entity({ name: 'addresses', synchronize: true })
export class Address {
    @PrimaryGeneratedColumn()
    id: number;

    @Index()
    @Column({ nullable: false })
    storeId: number;

    @ManyToOne(() => Store, (store) => store.customers)
    @JoinColumn({ name: 'storeId' })
    store: Store;

    @Column({ type: 'enum', enum: Lang, default: Lang.EN })
    lang: string;

    @Index()
    @Column({ nullable: true })
    province: string;

    @Index()
    @Column({ nullable: true })
    provinceShortName: string;

    @Index()
    @Column({ nullable: true })
    city: string;

    @Column({ nullable: true })
    cityShortName: string;

    @Column({ nullable: true })
    district: string;

    @Column({ nullable: true })
    districtShortName: string;

    @Column({ type: 'jsonb', nullable: true })
    rawData: object;

    @CreateDateColumn()
    createdAt: Date;

    @UpdateDateColumn({ nullable: true })
    updatedAt: Date;
}
