import {
    Column,
    Entity,
    PrimaryGeneratedColumn,
    CreateDateColumn,
    UpdateDateColumn,
    ManyToOne,
    JoinColumn,
    AfterLoad,
    BeforeUpdate,
    BeforeInsert,
    OneToMany
} from 'typeorm';
import { Store } from '../stores/stores.entity';
import { EncryptionService } from 'src/modules/utils/encryption.service';
import { StoreIntegrationAccess } from '../store-integration-accesses/store-integration-accesses.entity';

@Entity({ name: 'storeIntegrations', synchronize: true })
export class StoreIntegration {
    @PrimaryGeneratedColumn({ type: 'int' })
    id: number;

    @ManyToOne(() => Store, (store) => store.storeIntegrations)
    @JoinColumn({ name: 'storeId' })
    store: Store;

    @Column({ type: 'int' })
    storeId: number;

    @OneToMany(
        () => StoreIntegrationAccess,
        (storeIntegrationAccess) => storeIntegrationAccess.storeIntegration
    )
    storeIntegrationAccesses: StoreIntegrationAccess[];

    @Column({
        type: 'enum',
        enum: ['shopify', 'ascentis', 'sms', 'email', 'referrer', 'line', 'xstore', 'stamps', 'customerData', 'salesData']
    })
    type: string;

    @Column({ type: 'text', nullable: true })
    credentials: any;

    @Column({ type: 'json', nullable: true })
    settings: object;

    @Column({ type: 'boolean', default: false })
    active: boolean;

    @Column({ type: 'boolean', default: false })
    default: boolean;

    @CreateDateColumn()
    createdAt: Date;

    @UpdateDateColumn({ nullable: true })
    updatedAt: Date;    

    @BeforeUpdate()
    updateCredentials() {
        if (this.credentials) {
            this.credentials = EncryptionService.encrypt(
                JSON.stringify(this.credentials)
            );
        }
    }

    @BeforeInsert()
    insertCredentials() {
        if (this.credentials) {
            this.credentials = EncryptionService.encrypt(
                JSON.stringify(this.credentials)
            );
        }
    }

    @AfterLoad()
    decryptCredentials() {
        if (this.credentials) {
            this.credentials = JSON.parse(
                EncryptionService.decrypt(this.credentials)
            );
        }
    }
}
