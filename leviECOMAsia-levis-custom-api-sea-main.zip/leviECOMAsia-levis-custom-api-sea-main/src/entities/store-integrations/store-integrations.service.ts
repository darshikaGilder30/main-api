import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { StoreIntegration } from './store-integrations.entity';
import { Repository } from 'typeorm';
import { StoreIntegrationCreateDto } from './dto/store-integrations-create.dto';

@Injectable()
export class StoreIntegrationsService {
    constructor(
        @InjectRepository(StoreIntegration)
        private storeIntegrationRepository: Repository<StoreIntegration>
    ) {}

    async create(storeIntegration: StoreIntegrationCreateDto): Promise<StoreIntegration> {
        storeIntegration = this.storeIntegrationRepository.create(storeIntegration);
        return await this.storeIntegrationRepository.save(storeIntegration);
    }

    async update(storeIntegration: StoreIntegration): Promise<StoreIntegration> {
        return await this.storeIntegrationRepository.save(storeIntegration);
    }
}
