import { Module } from '@nestjs/common';
import { StoreIntegrationsService } from './store-integrations.service';
import { StoreIntegration } from './store-integrations.entity';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
    imports: [TypeOrmModule.forFeature([StoreIntegration])],
    providers: [StoreIntegrationsService],
    exports: [StoreIntegrationsService]
})
export class StoreIntegrationsModule {}
