import { Optional } from '@nestjs/common';
import { IsBoolean, IsNotEmpty, IsString } from 'class-validator';

export class StoreIntegrationCreateDto {
    @IsNotEmpty()
    @IsString()
    storeId: number;

    @IsNotEmpty()
    @IsString()
    type: string;

    @IsNotEmpty()
    @IsString()
    credentials: any;

    @Optional()
    @IsString()
    settings?: any;

    @Optional()
    @IsBoolean()
    active?: boolean;

    @Optional()
    @IsBoolean()
    default?: boolean;
}   