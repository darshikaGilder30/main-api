import { CountryCode } from '../types/countryCode.type';

export class StoreIntegrationDto {
    storeId: number;
    type: string;
    credentials: any;
    settings?: StoreIntegrationShopifySettingsDto;
    active?: boolean;
    default?: boolean;
}

export class StoreIntegrationShopifySettingsDto {
    shopDomain: string;
    countryCode: CountryCode;
    countryName: string;
    callingCode: string;
    dobFormat: string;
    enquiryCode: string;
    outletCode: string;
    timezone: string;
    posId: string;
    cashierId: string;
    ignoreCcnChecking: string;
    ecomCountryCode: string;
    mailingList: string;
    retailStore: string;
    typeCode: string;
    securityUserId: string;
    merchantId: string;
    storeId: string;
    apiUrl: string;
    invoiceAvailable?: string;
    returnWindow?: number;
    cronTime?: string;
    spinWinUrl?: string;
}
