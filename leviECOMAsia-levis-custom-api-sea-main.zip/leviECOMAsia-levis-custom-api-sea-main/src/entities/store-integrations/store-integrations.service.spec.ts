import { Test, TestingModule } from '@nestjs/testing';
import { StoreIntegrationsService } from './store-integrations.service';

describe('StoreIntegrationsService', () => {
  let service: StoreIntegrationsService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [StoreIntegrationsService],
    }).compile();

    service = module.get<StoreIntegrationsService>(StoreIntegrationsService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
