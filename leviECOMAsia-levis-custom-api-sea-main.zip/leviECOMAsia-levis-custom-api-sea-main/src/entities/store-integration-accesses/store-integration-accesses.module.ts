import { Module } from '@nestjs/common';
import { StoreIntegrationAccess } from './store-integration-accesses.entity';
import { TypeOrmModule } from '@nestjs/typeorm';
import { StoreIntegrationAcessessService } from './store-integration-accesses.service';

@Module({
    imports: [TypeOrmModule.forFeature([StoreIntegrationAccess])],
    providers: [StoreIntegrationAcessessService],
    exports: [StoreIntegrationAcessessService]
})
export class StoreIntegrationAccessesModule {}
