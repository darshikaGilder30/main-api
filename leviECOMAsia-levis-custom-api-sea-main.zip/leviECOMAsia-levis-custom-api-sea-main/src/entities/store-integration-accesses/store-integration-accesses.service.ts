import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { StoreIntegrationAccess } from './store-integration-accesses.entity';
import { randomUUID } from 'crypto';
import * as bcrypt from 'bcrypt';
import * as crypto from 'crypto';
import { StoreIntegration } from '../store-integrations/store-integrations.entity';

@Injectable()
export class StoreIntegrationAcessessService {
    constructor(
        @InjectRepository(StoreIntegrationAccess)
        private storeIntegrationAccessRepository: Repository<StoreIntegrationAccess>
    ) {}

    async findClient(clientId: string): Promise<StoreIntegrationAccess> {
        return await this.storeIntegrationAccessRepository.findOne({
            where: {
                clientId,
                active: true
            },
            relations: ['store', 'store.storeIntegrations']
        });
    }

    async create(storeIntegrationAccess): Promise<StoreIntegrationAccess> {
        storeIntegrationAccess = this.storeIntegrationAccessRepository.create(
            storeIntegrationAccess
        );
        return await this.storeIntegrationAccessRepository.save(
            storeIntegrationAccess
        );
    }

    async update(
        storeIntegrationAccess: StoreIntegrationAccess
    ): Promise<StoreIntegrationAccess> {
        return await this.storeIntegrationAccessRepository.save(
            storeIntegrationAccess
        );
    }

    async generateAccess(storeIntegration: StoreIntegration) {
        const salt = await bcrypt.genSalt(10);
        const clientId = randomUUID();
        const clientSecret = crypto
            .createHmac(
                'sha256',
                `${storeIntegration.id}${clientId}${randomUUID()}`
            )
            .update('json')
            .digest('base64');
        const hashedSecret = await bcrypt.hash(clientSecret, salt);

        return await this.create({
            storeId: storeIntegration.storeId,
            storeIntegrationId: storeIntegration.id,
            clientId,
            clientSecret: hashedSecret,
            active: true
        })
    }

    async generateAccessToken(storeIntegrationAccess: StoreIntegrationAccess) {
        const salt = await bcrypt.genSalt(10);
        const accessToken = storeIntegrationAccess.clientId;
        const hashedAccessToken = await bcrypt.hash(accessToken, salt);

        return hashedAccessToken;
    }
}
