import {
    Column,
    Entity,
    PrimaryGeneratedColumn,
    CreateDateColumn,
    UpdateDateColumn,
    ManyToOne,
    JoinColumn,
    AfterLoad,
    BeforeUpdate,
    BeforeInsert
} from 'typeorm';
import { Store } from '../stores/stores.entity';
import { EncryptionService } from 'src/modules/utils/encryption.service';
import { StoreIntegration } from '../store-integrations/store-integrations.entity';

@Entity({ name: 'storeIntegrationAccesses', synchronize: true })
export class StoreIntegrationAccess {
    @PrimaryGeneratedColumn({ type: 'int' })
    id: number;

    @ManyToOne(() => Store, (store) => store.storeIntegrations)
    @JoinColumn({ name: 'storeId' })
    store: Store;

    @Column({ type: 'int' })
    storeId: number;

    @ManyToOne(() => StoreIntegration, (storeIntegration) => storeIntegration.storeIntegrationAccesses)
    @JoinColumn({ name: 'storeIntegrationId' })
    storeIntegration: StoreIntegration;

    @Column({ type: 'int' })
    storeIntegrationId: number;

    @Column({ type: 'varchar', length: 255, unique: true })
    clientId: string;

    @Column({ type: 'varchar', length: 255 })
    clientSecret: string;

    @Column({ type: 'boolean', default: false })
    active: boolean;

    @CreateDateColumn()
    createdAt: Date;

    @BeforeUpdate()
    updateCredentials() {
        if (this.clientSecret) {
            this.clientSecret = EncryptionService.encrypt(this.clientSecret);
        }
    }

    @BeforeInsert()
    insertCredentials() {
        if (this.clientSecret) {
            this.clientSecret = EncryptionService.encrypt(this.clientSecret);
        }
    }

    @AfterLoad()
    decryptCredentials() {
        if (this.clientSecret) {
            this.clientSecret = EncryptionService.decrypt(this.clientSecret);
        }
    }
}
