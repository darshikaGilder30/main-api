import {
    CallHandler,
    ExecutionContext,
    Injectable,
    NestInterceptor
} from '@nestjs/common';
import { NextFunction } from 'express';
import { Observable } from 'rxjs';

export const REQUEST_CONTEXT = '_requestContext';

@Injectable()
export class InjectStoreInterceptor implements NestInterceptor {
    constructor(private type?: NonNullable<'query' | 'body' | 'params'>) {}

    intercept(
        context: ExecutionContext,
        next: CallHandler
    ): Observable<NextFunction> {
        const request = context.switchToHttp().getRequest();

        if (this.type && request[this.type]) {
            request[this.type][REQUEST_CONTEXT] = {
                store: request['store']
            };
        }

        return next.handle();
    }
}
