import {
    Injectable,
    NestInterceptor,
    ExecutionContext,
    CallHandler,
    Logger
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { CustomLoggerService } from 'src/modules/utils/custom-logger.service';

@Injectable()
export class LoggingInterceptor implements NestInterceptor {
    private logger: Logger = new Logger(LoggingInterceptor.name);
   
    intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
        const request = context.switchToHttp().getRequest();
        const payload = {
            body: request.body,
            params: request.params,
            query: request.query
        };
        delete payload.query['path_prefix'];

        this.logger.debug(
            `Request Payload: ${JSON.stringify(payload)}, Customer: ${
                request.customer?.email || 'Guest'
            }`
        );

        return next.handle();
    }
}
