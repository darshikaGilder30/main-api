import {
    Injectable,
    NestInterceptor,
    ExecutionContext,
    CallHandler,
    Logger
} from '@nestjs/common';
import { Observable } from 'rxjs';
import * as phoneLib from 'google-libphonenumber'

@Injectable()
export class UsernameSanitizeInterceptor implements NestInterceptor {
    private logger: Logger = new Logger(UsernameSanitizeInterceptor.name);
   
    intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
        const request = context.switchToHttp().getRequest();
        if (request.body.username) {
            let username = request.body.username;
            const type = username?.includes('@') ? 'email' : 'phone';
            const store = request.store;
            if (type === 'phone') {
                if (store?.storeIntegrations?.shopify?.settings?.countryCode) {
                    try {
                        const phoneValidator = phoneLib.PhoneNumberUtil.getInstance()
                        const sanitizedUsername = phoneValidator.parse(
                            username,
                            store?.storeIntegrations?.shopify?.settings?.countryCode
                        )

                        const numberType = phoneValidator.getNumberType(sanitizedUsername)
                        username = sanitizedUsername.getNationalNumber().toString();

                        if (numberType === phoneLib.PhoneNumberType.FIXED_LINE) {
                            username = `+${username}`.replace(store?.storeIntegrations?.shopify?.settings?.countryCode, '');
                            username = username.replace('+', '');
                        }
                    } catch (error) {
                        username = username.replace(/\D/g, '');
                    }

                    request.body.username = username;
                }
            }
        }

        return next.handle();
    }
}
