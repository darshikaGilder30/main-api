export default () => ({
    port: parseInt(process.env.PORT, 10) || 3000,
    environment: process.env.NODE_ENV || 'development',
    apiUrl: process.env.API_URL || 'http://localhost:3000',
    corsAllowedUrls: '*',
    database: {
        type: 'postgres',
        host: process.env.DATABASE_HOST || 'localhost',
        port: process.env.DATABASE_PORT || 5432,
        username: process.env.DATABASE_USERNAME,
        password: process.env.DATABASE_PASSWORD,
        name: process.env.DATABASE_NAME,
        ssl: process.env.DATABASE_SSL || false
    },
    redis: {
        url: process.env.REDIS_URL || 'redis://localhost:6379',
        host: process.env.REDIS_URL?.replace('redis://', '')?.replace(':6379', ''),
        cluster: process.env.REDIS_CLUSTER == '0' ? false : true
    },
    shopify: {
        appProxy: {
            clientId: process.env.SHOPIFY_APP_PROXY_KEY,
            clientSecret: process.env.SHOPIFY_APP_PROXY_SECRET,
            scopes: [
                'read_customers',
                'write_customers',
                'unauthenticated_write_customers',
                'read_legal_policies',
                'write_checkout_branding_settings',
                'read_locations',
                'write_inventory',
                'read_inventory',
                'write_metaobjects',
                'read_metaobjects',
                'read_orders',
                'read_all_orders',
                'write_orders',
                'write_discounts',
                'write_files',
                'write_themes',
                'read_returns',
                'read_fulfillments',
                'write_products',
                'read_products',
                'write_returns',
                'write_payment_customizations',
                'read_translations',
                'write_translations'
            ],
            webhookUrl: process.env.SHOPIFY_APP_PROXY_WEBHOOK_URL || 'arn:aws:events:ap-southeast-1::event-source/aws.partner/shopify.com/69652676609/levis-non-prod'
        }
    },
    line: {
        jwt: {
            secret: process.env.LINE_JWT_SECRET,
            expiry: process.env.LINE_JWT_EXPIRY || '1d'
        }
    },
    google: {
        recaptcha: {
            secret: process.env.GOOGLE_RECAPTCHA_SECRET,
            url: process.env.GOOGLE_RECAPTCHA_URL || 'https://www.google.com/recaptcha/api'
        }
    }
});
