import { ValidationArguments } from 'class-validator';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { REQUEST_CONTEXT } from 'src/interceptors/store.interceptors';

export interface ExtendedValidationArguments extends ValidationArguments {
    object: {
        [REQUEST_CONTEXT]: {
            store: StoreDto;
        };
    };
}
