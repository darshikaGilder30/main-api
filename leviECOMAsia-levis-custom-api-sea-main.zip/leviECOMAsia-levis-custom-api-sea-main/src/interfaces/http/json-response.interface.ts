export interface JsonResponse {
    message: string;
    data: any;
}

export interface HttpServiceResponse<T = any> {
    data: T | null;
    message: string;
    success: boolean;
}
