import { HttpAdapterHost, NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { ValidationPipe } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { AllExceptionsFilter } from './exceptions/all.exception';
import { I18nValidationExceptionFilter, I18nValidationPipe } from 'nestjs-i18n';
import { LoggingInterceptor } from './interceptors/logging.interceptors';
import { useContainer } from 'class-validator';
import { LineModule } from './modules/line/line.module';
import { ShopifyProxyModule } from './modules/shopify-proxy/shopify-proxy.module';
import { ShopifyOauthModule } from './modules/shopify-oauth/shopify-oauth.module';

async function bootstrap() {
    const app = await NestFactory.create(AppModule);
    const configService = app.get(ConfigService);
    app.enableCors({
        origin: configService.get('corsAllowedUrls'),
        methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
        allowedHeaders: 'Content-Type, Accept, Authorization, X-Requested-With, Application, ip'
    });
    const httpAdapter = app.get(HttpAdapterHost);
    app.useGlobalPipes(new I18nValidationPipe());
    app.useGlobalFilters(new I18nValidationExceptionFilter());
    app.useGlobalPipes(new ValidationPipe({ transform: true }));
    app.useGlobalFilters(new AllExceptionsFilter(httpAdapter));
    app.useGlobalInterceptors(new LoggingInterceptor());
    
    const config = new DocumentBuilder()
        .setTitle('Levis Shopify Custom API')
        .setDescription('The Levis Shopify Custom API description')
        .setVersion('1.0')
        .build();
    const document = SwaggerModule.createDocument(app, config, {
        include: [ShopifyProxyModule, ShopifyOauthModule]
    });
    SwaggerModule.setup('apidocs', app, document);

    const lineAppConfig = new DocumentBuilder()
        .setTitle('Levis Shopify Line App Custom API')
        .setDescription('Levis Shopify Line App Custom API')
        .setVersion('1.0')
        .addSecurity('X-Access-Token', {
            type: 'apiKey',
            name: 'X-Access-Token',
            in: 'header'
        })
        .addBearerAuth(
            { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' },
            'Authorization',
        )
        .build();
    const lineAppDocument = SwaggerModule.createDocument(app, lineAppConfig, {
        include: [LineModule]
    });
    SwaggerModule.setup('lineApiDocs', app, lineAppDocument);

    useContainer(app.select(AppModule), { fallbackOnErrors: true });
    await app.listen(configService.get('port'));
}
bootstrap();
