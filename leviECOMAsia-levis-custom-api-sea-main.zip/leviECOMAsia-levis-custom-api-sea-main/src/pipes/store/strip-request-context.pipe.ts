import { Injectable, PipeTransform } from '@nestjs/common';
import { REQUEST_CONTEXT } from 'src/interceptors/store.interceptors';
import { omit } from 'lodash';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';

@Injectable()
export class StripRequestContextPipe implements PipeTransform {
    transform(value: StoreDto) {
        return omit(value, REQUEST_CONTEXT);
    }
}
