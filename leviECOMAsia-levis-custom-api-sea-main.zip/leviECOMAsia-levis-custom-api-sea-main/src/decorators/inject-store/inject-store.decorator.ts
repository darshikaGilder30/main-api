import { UseInterceptors, UsePipes, applyDecorators } from '@nestjs/common';
import { InjectStoreInterceptor } from 'src/interceptors/store.interceptors';
import { StripRequestContextPipe } from 'src/pipes/store/strip-request-context.pipe';

export function InjectStoreToQuery() {
    return applyDecorators(InjectStoreTo('query'));
}

export function InjectStoreToBody() {
    return applyDecorators(InjectStoreTo('body'));
}

export function InjectStoreToParam() {
    return applyDecorators(InjectStoreTo('params'));
}

export function InjectStoreTo(context: 'query' | 'body' | 'params') {
    return applyDecorators(
        UseInterceptors(new InjectStoreInterceptor(context)),
        UsePipes(StripRequestContextPipe)
    );
}
