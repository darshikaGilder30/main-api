import { createParamDecorator, ExecutionContext } from '@nestjs/common';
import { ShopifyCustomer } from 'src/modules/shopify-admin-api/interfaces/shopify-customer.interface';

export const GetCustomer = createParamDecorator(
    (data, ctx: ExecutionContext): ShopifyCustomer => {
        const req = ctx.switchToHttp().getRequest();

        return req.customer as ShopifyCustomer;
    }
);