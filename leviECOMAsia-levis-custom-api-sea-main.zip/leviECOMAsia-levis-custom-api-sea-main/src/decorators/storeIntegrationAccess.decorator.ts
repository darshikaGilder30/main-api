import { createParamDecorator, ExecutionContext } from '@nestjs/common';
import { StoreIntegrationAccess } from 'src/entities/store-integration-accesses/store-integration-accesses.entity';

export const GetStoreIntegrationAccess = createParamDecorator(
    (data, ctx: ExecutionContext): StoreIntegrationAccess => {
        const req = ctx.switchToHttp().getRequest();

        return req.storeIntegrationAccess;
    }
);