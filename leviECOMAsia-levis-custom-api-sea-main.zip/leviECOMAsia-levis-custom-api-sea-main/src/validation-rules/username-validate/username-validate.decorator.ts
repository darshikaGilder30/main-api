import {
    registerDecorator,
    ValidationOptions,
    ValidatorConstraint,
    ValidatorConstraintInterface
} from 'class-validator';
import * as deepEmailValidator from 'deep-email-validator';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { REQUEST_CONTEXT } from 'src/interceptors/store.interceptors';
import { ExtendedValidationArguments } from 'src/interfaces/store/store-extended.interface';
import * as phoneLib from 'google-libphonenumber'

@ValidatorConstraint({ async: true })
export class IsUsernameValid implements ValidatorConstraintInterface {
    async validate(username: string, args?: ExtendedValidationArguments) {
        let type = username?.includes('@') ? 'email' : 'phone';
        if (args.constraints?.find((constraint) => constraint.type === 'email')) {
            type = 'email';
        } else if (args.constraints?.find((constraint) => constraint.type === 'phone')) {
            type = 'phone';
        }

        if (type === 'email') {
            return (
                await deepEmailValidator.validate({
                    email: username,
                    sender: username,
                    validateSMTP: false,
                    validateMx: true,
                    validateTypo: false,
                    validateDisposable: true,
                    validateRegex: true
                })
            ).valid;
        } else {
            const store: StoreDto = args?.object[REQUEST_CONTEXT].store;
            if (store?.storeIntegrations?.shopify?.settings?.countryCode) {
                try {
                    const phoneValidator = phoneLib.PhoneNumberUtil.getInstance()
                    return phoneValidator.isValidNumberForRegion(
                        phoneValidator.parse(
                            username,
                            store?.storeIntegrations?.shopify?.settings?.countryCode
                        ),
                        store?.storeIntegrations?.shopify?.settings?.countryCode
                    );
                } catch (error) {
                    return false;
                }
            }

            return false;
        }
    }

    defaultMessage(args?: ExtendedValidationArguments): string {
        const type = args?.value?.includes('@') ? 'email' : 'phone';

        if (type === 'email') {
            return 'validation.invalid_email';
        } else {
            return 'validation.invalid_phone';
        }
    }
}

export function UsernameValidate(validationOptions?: ValidationOptions) {
    return function (object: object, propertyName: string) {
        registerDecorator({
            target: object.constructor,
            propertyName: propertyName,
            options: validationOptions,
            constraints: [
                {
                    type: validationOptions?.context?.type
                }
            ],
            validator: IsUsernameValid
        });
    };
}
