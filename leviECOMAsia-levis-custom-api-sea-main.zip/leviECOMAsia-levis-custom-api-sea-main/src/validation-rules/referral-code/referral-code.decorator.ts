import { Inject, Injectable, Logger } from '@nestjs/common';
import {
    registerDecorator,
    ValidationOptions,
    ValidatorConstraint,
    ValidatorConstraintInterface
} from 'class-validator';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { REQUEST_CONTEXT } from 'src/interceptors/store.interceptors';
import { ExtendedValidationArguments } from 'src/interfaces/store/store-extended.interface';
import { MuleReferrerValidateService } from 'src/modules/mule/mule-referrer-validate.service';
import { MuleService } from 'src/modules/mule/mule.service';
import { HttpService } from '@nestjs/axios';
import { lastValueFrom } from 'rxjs';

@ValidatorConstraint({ name: 'referralCodeValidate', async: true })
@Injectable()
export class IsReferralCodeValid implements ValidatorConstraintInterface {
    private readonly logger = new Logger('ReferralCodeValidator');

    constructor(
        private readonly muleReferrerValidateService: MuleReferrerValidateService,
        private readonly httpService: HttpService
    ) {}

    async validate(referralCode: string, args?: ExtendedValidationArguments): Promise<boolean> {
        if (!referralCode) {
            this.logger.debug(`ReferralCode: Skipping validation, no referral code provided`);
            return true;
        }

        const store: StoreDto = args?.object?.[REQUEST_CONTEXT]?.store;
        const isStamps = store?.storeIntegrations?.stamps?.active;

        const mobile_number = (args?.object as any)?.mobile_number?.toString()?.trim();

        this.logger.debug(
            `ReferralCode: Store: ${store?.name}, ReferralCode: ${referralCode}, CRM Type: ${isStamps ? 'Stamps' : 'Mule'}`
        );        

        if (isStamps) {
            this.logger.debug(`Stamps: referralCodeCheck: ${referralCode} starting validation`);
            const validation = await this.validateStampsReferralCode(
                store,
                referralCode,
                mobile_number
            );

            this.logger.debug(
                `Stamps: referralCodeValidation result: ${validation.success}, message: ${validation.message || ''}`
            );
            return validation.success;
        } else {
            this.logger.debug(`Mule: referralCodeCheck: ${referralCode} starting validation`);
            const validReferralCode =
            await this.muleReferrerValidateService.validateReferralCode(store, referralCode);
            if (!validReferralCode.success || !validReferralCode.data?.IsValid) {
                return false;
            }
            return true;
        }
    }

    // Stamps Referral Code Validation
    // Author: Darshika Gilder
    // Purpose: Validate referral code during new user registration via Stamps API
    // Date: 21/04/2025
    private async validateStampsReferralCode(
        store: StoreDto,
        referralCode: string,
        mobile_number: string
    ): Promise<{ success: boolean; data: boolean; message?: string }> {
        const requestDetails = this.getRequestDetails(store);

        const payload = {
            ...requestDetails.basicParams,
            is_active: false,
            mobile_number,
            referral_code: referralCode
        };

        const result = {
            success: false,
            data: false,
            message: ''
        };

        this.logger.debug(
            `Stamps: referralCodeCheck: Sending request to ${requestDetails.url}/v2/memberships/register with payload: ${JSON.stringify(payload)}`
        );

        try {
            await lastValueFrom(
                this.httpService.post(
                    `${requestDetails.url}/v2/memberships/register`,
                    payload,
                    {
                        headers: {
                            ...requestDetails.headers,
                            'Content-Type': 'application/json'
                        }
                    }
                )
            );

            result.success = true;
            result.data = true;
        } catch (error) {
            const errorData = error.response?.data ?? {};
            const isInvalid = errorData?.error_code === 'invalid_referral_code';

            result.message = errorData?.error_message || error.message || 'Unknown error';
            result.success = !isInvalid;

            this.logger.error(
                `Stamps: membershipCheck: ${mobile_number} failed with message: ${result.message}`
            );
        }
        return result;
    }

    private getRequestDetails(store: StoreDto) {
        return {
            basicParams: {
                merchant: store.storeIntegrations?.stamps?.settings?.merchantId,
                store: store.storeIntegrations?.stamps?.settings?.storeId,
                token: store.storeIntegrations?.stamps?.credentials?.token
            },
            headers: {
                'Content-Type': 'application/json'
            },
            url: store.storeIntegrations?.stamps?.settings?.apiUrl
        };
    }
}

export function ReferralCodeValidate(validationOptions?: ValidationOptions) {
    return function (object: object, propertyName: string) {
        registerDecorator({
            target: object.constructor,
            propertyName: propertyName,
            options: validationOptions,
            constraints: [],
            validator: IsReferralCodeValid
        });
    };
}