import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform } from 'class-transformer';
import { HelperService } from 'src/modules/utils/helper.service';
export class LineAscentiesVoucherTransformer {

    @ApiProperty({
        description: 'Voucher Code',
        example: '1234567890'
    })
    @Expose({ name: 'VoucherNo' })
    'vouchercode': string;

    @ApiProperty({
        description: 'Voucher Type Code',
        example: '1234567890'
    })
    @Expose({ name: 'VoucherTypeCode' })
    'code': string;

    @ApiProperty({
        description: 'Voucher Type Name',
        example: '1234567890'
    })
    @Expose({ name: 'VoucherTypeName' })
    'voucherTypeName': string;

    @ApiProperty({
        description: 'Voucher Type Value',
        example: '1234567890'
    })
    @Expose({ name: 'TypeValue' })
    'VoucherAmount': string;

    @ApiProperty({
        description: 'Voucher Type Description',
        example: '1234567890'
    })
    @Expose({ name: 'VoucherTypeDescription' })
    'Description': string;

    @ApiProperty({
        description: 'Voucher ValidFrom Date in UTC',
        example: '12-12-2023 16:00:00'
    })
    @Expose({ name: 'ValidFrom' })
    @Transform((value) => {
        return HelperService.parseAcentiesData(value.obj.ValidFrom, 'DD-MM-YYYY HH:mm:ss');
    })
    'ValidFrom': string;

    @ApiProperty({
        description: 'Voucher ValidTill Date in UTC',
        example: '12-12-2023 16:00:00'
    })
    @Expose({ name: 'ValidTo' })
    @Transform((value) => {
        return HelperService.parseAcentiesData(value.obj.ValidTo, 'DD-MM-YYYY HH:mm:ss');
    })
    'ValidTill': string;
}
