import { Expose, Transform } from 'class-transformer';
import * as _ from 'lodash';
import * as moment from 'moment-timezone';
import { ShopifyCustomMeta } from 'src/enums/shopify-custom-meta.enum';
import { HelperService } from 'src/modules/utils/helper.service';

export class LineAuthUserInfoTransformer {
    @Transform(({ value }) => {
        return value.replace('gid://shopify/Customer/', '');
    })
    @Expose({ name: 'id' })
    'UserInfoId': string;

    @Transform((value) => {
        return value.obj.id.replace('gid://shopify/Customer/', '');
    })
    @Expose()
    'UserId': string;

    @Expose({ name: 'email' })
    'UserName': string;

    @Expose({ name: 'firstName' })
    'FirstName': string;

    @Expose({ name: 'lastName' })
    'LastName': string;

    @Expose({ name: 'phone' })
    'MobileNo': string;

    @Transform((value) => {
        const gender =
            value.obj.metafields?.find(
                (edge) => edge.key === ShopifyCustomMeta.Gender
            )?.value || null;

        if (gender) {
            return _.lowerCase(gender);
        }

        return null;
    })
    @Expose({ name: 'metafields.edges' })
    'Gender': string;

    @Transform((value) => {
        const date =
            value.obj.metafields?.find(
                (edge) => edge.key === ShopifyCustomMeta.DateOfBirth
            )?.value || null;
        if (date) {
            return moment(date, 'YYYY-MM-DD').format('DD/MM/YYYY');
        }

        return null;
    })
    @Expose()
    'BirthDate': string;

    @Transform((value) => {
        let marketingNotificationType = '';
        if (value.obj.emailMarketingConsent?.marketingState === 'SUBSCRIBED') {
            marketingNotificationType += 'email';
        }
        if (value.obj.smsMarketingConsent?.marketingState === 'SUBSCRIBED') {
            marketingNotificationType += marketingNotificationType
                ? '|sms'
                : 'sms';
        }

        return marketingNotificationType;
    })
    @Expose()
    'MarketingNotificationType': string;

    @Transform((value) => {
        const profileInfo = [];

        const membershipId =
            value.obj.metafields?.find(
                (edge) => edge.key === ShopifyCustomMeta.MembershipId
            )?.value || null;
        if (membershipId) {
            profileInfo.push({
                ProfileAttributeName: 'membershipid',
                ProfileAttributeValue: membershipId
            });
        }

        return profileInfo;
    })
    @Expose({ name: 'UserProfiles' })
    'UserProfiles': {
        ProfileAttributeName: string;
        ProfileAttributeValue: string;
    }[];

    @Transform((value) => {
        const cardInfo = value.obj.cardEnquiry.CardInfo;
        const membershipInfo = value.obj.cardEnquiry.MembershipInfo;
        return {
            CRMPoints: cardInfo.TotalPointsBAL,
            LifetimePoints: membershipInfo.TotalPoints,
            CurrentSlab: cardInfo.TierCode,
            PointsConversionFactor: cardInfo.DollarToPointsRatio,

            PointsToValue: HelperService.rebateValueFromPoints(
                cardInfo.TotalPointsBAL,
                cardInfo.DollarToPointsRatio
            ),
            RedeemPointBAL: cardInfo.TotalPointsBAL,
            RedeemPointVAL: HelperService.rebateValueFromPoints(
                cardInfo.TotalPointsBAL,
                cardInfo.DollarToPointsRatio
            ),
            RewardCycleLists: cardInfo.RewardCycleLists.map((rewardCycle) => {
                return {
                    cycEndDate: rewardCycle.CycEndDate
                        ? `/Date(${
                              moment(rewardCycle.CycEndDate).unix() * 1000
                          })/`
                        : null,
                    pointsBALValue: rewardCycle.PointsBALValue || 0,
                    pointsExpiringDate: rewardCycle.PointsExpiringDate
                        ? `/Date(${
                              moment(rewardCycle.PointsExpiringDate).unix() *
                              1000
                          })/`
                        : null,
                    pointsType: rewardCycle.PointsType
                };
            }),
            ExpiryScheduleLists: []
        };
    })
    @Expose({ name: 'CRMLoyaltyDetail' })
    CRMLoyaltyDetail: {
        CRMPoints: number;
        LifetimePoints: number;
        CurrentSlab: string;
        PointsConversionFactor: string;
        PointsToValue: string;
        RedeemPointBAL: number;
        RedeemPointVAL: number;
        RewardCycleLists: {
            cycEndDate: string;
            pointsBALValue: number;
            pointsExpiringDate: string;
            pointsType: string;
        }[];
        ExpiryScheduleLists: any[];
    };
}
