import { Expose, Transform } from 'class-transformer';
import { HelperService } from 'src/modules/utils/helper.service';

export class LineAscentisTransactionHistoryTransformer {

    @Expose({ name: 'TransactionRefID' })
    OrderID: string;

    @Transform(({value}) => {
        return value.toString();
    })
    @Expose({ name: 'NettSpent' })
    Amount: string;

    @Expose({ name: 'Points'})
    @Transform(({value}) => {
        return value.toString();
    })
    EarnedPoint: string;

    @Expose()
    @Transform((value) => {
        return "0";
    })
    RedeemPoint: string;

    @Transform((value) => {
        return "Delivered";
    })
    @Expose()
    Status: string;

    @Expose({ name: 'TransactDate' })
    @Transform((value) => {
        return `${HelperService.parseAcentiesData(value.obj.TransactDate, 'DD-MM-YYYY HH:mm:ss')}`;
    })
    LoggedDate: string;
}
