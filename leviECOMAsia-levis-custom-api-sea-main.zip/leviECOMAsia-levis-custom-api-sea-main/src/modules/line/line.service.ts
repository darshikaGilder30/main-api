import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { ShopifyCustomer } from '../shopify-admin-api/interfaces/shopify-customer.interface';
import { plainToInstance } from 'class-transformer';
import { LineAuthUserInfoTransformer } from './transformers/auth-user-info.transformer';

@Injectable()
export class LineService {
    constructor(private jwtService: JwtService) {}

    createToken(data): any {
        return this.jwtService.sign({ data });
    }

    getUserInfo(
        store: StoreDto,
        shopifyCustomer: ShopifyCustomer
    ): LineAuthUserInfoTransformer {
        const shopifyCustomerInfo = plainToInstance(
            LineAuthUserInfoTransformer,
            shopifyCustomer,
            {
                exposeUnsetFields: true,
                strategy: 'excludeAll'
            }
        );

        if (shopifyCustomerInfo?.MobileNo) {
            shopifyCustomerInfo.MobileNo = `${store.storeIntegrations.shopify.settings.callingCode}${shopifyCustomerInfo.MobileNo.replaceAll(
                store.storeIntegrations.shopify.settings.callingCode,
                ''
            )}`;
        }

        return shopifyCustomerInfo;
    }

}
