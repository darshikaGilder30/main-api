import {
    Body,
    Controller,
    Header,
    HttpCode,
    Logger,
    Post
} from '@nestjs/common';
import {
    ApiHeaders,
    ApiOkResponse,
    ApiSecurity,
    ApiTags
} from '@nestjs/swagger';
import { LineAuthValidateDto } from '../dto/line-auth-validate.dto';
import { ShopifyAdminApiService } from 'src/modules/shopify-admin-api/shopify-admin-api.service';
import { ShopifyStorefrontApiService } from 'src/modules/shopify-storefront-api/shopify-storefront-api.service';
import { OtpServiceService } from 'src/modules/otp-service/otp-service.service';
import { OtpService } from 'src/modules/otp/otp.service';
import { GetStore } from 'src/decorators/store.decorator';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { I18nContext } from 'nestjs-i18n';
import { InjectStoreToBody } from 'src/decorators/inject-store/inject-store.decorator';
import { CacheHelper } from 'src/modules/utils/cache/cache-helper.service';
import { LineResponseMessageCode } from 'src/enums/line-response-message-code.enum';
import { LineJsonResponse } from '../dto/line-response.dto';
import { LineVerifyOtpDto, LineVerifyOtpResponseDto } from '../dto/line-auth-verify-otp.dto';
import { LineService } from '../line.service';
import { LineAuthLoginDto } from '../dto/line-auth-login.dto';
import { HelperService } from 'src/modules/utils/helper.service';
import { CustomLoggerService } from 'src/modules/utils/custom-logger.service';

@Controller('external/line-app/auth')
@ApiTags('Line App - Authentication')
@ApiSecurity('X-Access-Token')
@ApiHeaders([
    {
        name: 'X-Client-Id',
        description: 'Client ID',
        required: true
    }
])
export class LineAppAuthController {
    private logger : CustomLoggerService
    constructor(
        private shopifyAdminApiService: ShopifyAdminApiService,
        private shopifyStorefrontApiService: ShopifyStorefrontApiService,
        private otpServiceService: OtpServiceService,
        private otpService: OtpService,
        private cacheHelper: CacheHelper,
        private lineService: LineService,
        private customLoggerService: CustomLoggerService
    ) {
        this.customLoggerService.setContext(LineAppAuthController.name);
        this.logger = customLoggerService;
    }

    @ApiOkResponse({ description: 'User Validated', type: LineJsonResponse })
    @Post('validate')
    @Header('Content-Type', 'application/json')
    @InjectStoreToBody()
    @HttpCode(200)
    async validate(
        @GetStore() store: StoreDto,
        @Body() lineAuthValidateDto: LineAuthValidateDto
    ): Promise<LineJsonResponse> {
        const response: LineJsonResponse = {
            messageCode: LineResponseMessageCode.SomethigWentWrong,
            Message: '',
            ErrorCode: 0
        };
        const shopifyCustomer =
            await this.shopifyAdminApiService.searchCustomerByUsername(
                store,
                lineAuthValidateDto.username
            );
        
        if (shopifyCustomer.success) {
            this.logger.debug(
                `validate: shopifyCustomer Success: ${lineAuthValidateDto.username}`
            );
            if (!shopifyCustomer.data) {
                response.messageCode = LineResponseMessageCode.UserNotExists;
                response.Message = I18nContext.current().translate('line.user_not_found')
            } else {
                if (HelperService.arrayMatch(shopifyCustomer.data?.tags, 'no_password') || shopifyCustomer.data?.state !== 'ENABLED') {
                    response.messageCode = LineResponseMessageCode.UserIsNotActive;
                    response.Message = I18nContext.current().translate(
                        'line.user_not_activated'
                    );

                    return response;
                }
                response.messageCode = LineResponseMessageCode.Success;
                response.Message = I18nContext.current().translate('line.success');
            }

            return response;
        }

        return response;
    }

    @ApiOkResponse({ description: 'Send Otp', type: LineJsonResponse })
    @Post('send-otp')
    @Header('Content-Type', 'application/json')
    @HttpCode(200)
    @InjectStoreToBody()
    async sendOtp(
        @GetStore() store: StoreDto,
        @Body() lineAuthValidateDto: LineAuthValidateDto
    ): Promise<LineJsonResponse> {
        const response: LineJsonResponse = {
            messageCode: LineResponseMessageCode.SomethigWentWrong,
            Message: '',
            ErrorCode: 0
        };
        if (
            !(
                (lineAuthValidateDto.username.includes('@') &&
                    store.storeIntegrations.email?.active) ||
                store.storeIntegrations.sms?.active
            )
        ) {
            this.logger.error(
                `sendOtp: Mode of communication not available: ${lineAuthValidateDto.username}`
            );

            response.messageCode = LineResponseMessageCode.ServiceNotAuthorized;
            response.Message = I18nContext.current().translate(
                'line.service_not_authorized'
            );

            return response;
        }

        const shopifyCustomer =
            await this.shopifyAdminApiService.searchCustomerByUsername(
                store,
                lineAuthValidateDto.username
            );
        if (shopifyCustomer.success && shopifyCustomer.data) {
            const tries: any = await this.cacheHelper.get(
                `${lineAuthValidateDto.username}-otp-tries`
            );

            if (tries && parseInt(tries) >= 3) {
                response.messageCode = LineResponseMessageCode.OtpSendLimitExceeded;
                response.Message = I18nContext.current().translate(
                    'line.otp_send_limit_exceeded'
                );

                return response;
            }

            this.logger.debug(
                `resendOtp: shopifyCustomer Success: ${lineAuthValidateDto.username}`
            );
            const otp = await this.otpService.generateOtp(
                lineAuthValidateDto.username,
                true
            );
            await this.otpServiceService.send(
                store,
                lineAuthValidateDto.username,
                { otp, templateCode: 'otp' }
            );
            // const token = await this.shopifyProxyService.generateToken(
            //     store,
            //     lineAuthValidateDto.username,
            //     'line-otp'
            // );

            // response.OTPToken = token;

            response.messageCode = LineResponseMessageCode.Success;
            response.Message = I18nContext.current().translate('line.otp_sent');

            return response;
        }

        return response;
    }

    @ApiOkResponse({ description: 'Otp Verified Successfully', type: LineVerifyOtpResponseDto })
    @Post('verify-otp')
    @Header('Content-Type', 'application/json')
    @HttpCode(200)
    @InjectStoreToBody()
    async verifyOtp(
        @GetStore() store: StoreDto,
        @Body() lineVerifyOtpDto: LineVerifyOtpDto
    ): Promise<LineVerifyOtpResponseDto> {
        const response: LineVerifyOtpResponseDto = {
            messageCode: LineResponseMessageCode.SomethigWentWrong,
            Message: '',
            ErrorCode: 0,
            Token: {
                AccessToken: ''
            }
        };
        if (
            !(
                (lineVerifyOtpDto.username.includes('@') &&
                    store.storeIntegrations.email?.active) ||
                (!lineVerifyOtpDto.username.includes('@') &&
                    store.storeIntegrations.sms?.active)
            )
        ) {
            this.logger.error(
                `sendOtp: Mode of communication not available: ${lineVerifyOtpDto.username}`
            );

            response.messageCode = LineResponseMessageCode.ServiceNotAuthorized;
            response.Message = I18nContext.current().translate(
                'line.service_not_authorized'
            );

            return response;
        }

        const shopifyCustomer =
            await this.shopifyAdminApiService.searchCustomerByUsername(
                store,
                lineVerifyOtpDto.username
            );

        if (shopifyCustomer.success && shopifyCustomer.data) {
            const tries: any = await this.cacheHelper.get(`${lineVerifyOtpDto.username}-otp-tries`);

            if (tries && parseInt(tries) >= 3) {
                response.messageCode = LineResponseMessageCode.OtpSendLimitExceeded;
                response.Message = I18nContext.current().translate(
                    'line.otp_send_limit_exceeded'
                );

                return response;
            }
            
            const otpVerified = await this.otpService.verifyOtp(
                lineVerifyOtpDto.username,
                lineVerifyOtpDto.otp,
                (tries ? parseInt(tries) : 0)
            );

            if (!otpVerified) {
                await this.cacheHelper.set(`${lineVerifyOtpDto.username}-otp-tries`, (tries ? parseInt(tries) + 1 : 1), 120);
                response.messageCode = LineResponseMessageCode.InvalidData;
                response.Message = I18nContext.current().translate(
                    'line.invalid_otp'
                );

                return response;
            }

            this.logger.debug(
                `verifyOtp: Otp Verified : ${lineVerifyOtpDto.username}`
            );

            await this.cacheHelper.del(`${lineVerifyOtpDto.username}-otp-tries`)

            response.messageCode = LineResponseMessageCode.Success;
            response.Message = I18nContext.current().translate('line.logged_in');

            // Generate JWT token
            const token = this.lineService.createToken({
                id: shopifyCustomer.data.id,
                username: lineVerifyOtpDto.username,
                storeId: store.id
            });

            response.Token.AccessToken = token;
            
            return response;
        }

        return response;
    }

    @ApiOkResponse({ description: 'User Login', type: LineVerifyOtpResponseDto })
    @Post('login')
    @Header('Content-Type', 'application/json')
    @InjectStoreToBody()
    @HttpCode(200)
    async login(
        @GetStore() store: StoreDto,
        @Body() lineAuthLoginDto: LineAuthLoginDto
    ): Promise<LineVerifyOtpResponseDto> {
        const response: LineVerifyOtpResponseDto = {
            messageCode: LineResponseMessageCode.SomethigWentWrong,
            Message: '',
            ErrorCode: 0,
            Token: {
                AccessToken: ''
            }
        };
        const shopifyCustomer =
            await this.shopifyAdminApiService.searchCustomerByUsername(
                store,
                lineAuthLoginDto.username
            );

        if (shopifyCustomer.success && shopifyCustomer.data) {
            this.logger.debug(
                `login: shopifyCustomer Success: ${lineAuthLoginDto.username}`
            );
            const shopifyCustomerToken =
                await this.shopifyStorefrontApiService.login(
                    store,
                    shopifyCustomer.data.email,
                    lineAuthLoginDto.password
                );
            
            if (shopifyCustomerToken.success) {
                if (!shopifyCustomerToken.data) {
                    this.logger.debug(
                        `login: shopifyCustomerToken Not Found: ${lineAuthLoginDto.username}`
                    );
                    response.messageCode = LineResponseMessageCode.AuthenticationFailed;
                    response.Message = I18nContext.current().translate(
                        'line.auth_failed'
                    );

                    return response;
                }

                // Generate JWT token
                const token = this.lineService.createToken({
                    id: shopifyCustomer.data.id,
                    username: lineAuthLoginDto.username,
                    storeId: store.id
                });

                response.Token.AccessToken = token;
                response.messageCode = LineResponseMessageCode.Success;
                response.Message = I18nContext.current().translate('line.logged_in');

                return response;
            }
        }

        return response;
    }
}
