import {
    Controller,
    Get,
    Header,
    Headers,
    HttpCode,
    Logger,
} from '@nestjs/common';
import { ApiOkResponse, ApiTags } from '@nestjs/swagger';
import { GetStore } from 'src/decorators/store.decorator';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { InjectStoreToBody } from 'src/decorators/inject-store/inject-store.decorator';
import { CacheHelper } from 'src/modules/utils/cache/cache-helper.service';
import { LineAuthTokenGenerateDto, LineJsonResponseWithAccessToken } from '../dto/line-auth-token-generate.dto';
import { StoreIntegrationAccess } from 'src/entities/store-integration-accesses/store-integration-accesses.entity';
import { GetStoreIntegrationAccess } from 'src/decorators/storeIntegrationAccess.decorator';
import { StoreIntegrationAcessessService } from 'src/entities/store-integration-accesses/store-integration-accesses.service';
import { LineResponseMessageCode } from 'src/enums/line-response-message-code.enum';
import { CustomLoggerService } from 'src/modules/utils/custom-logger.service';

@Controller('external/line-app/auth')
@ApiTags('Line App - Authentication')
export class LineAppAuthTokenController {
    private logger : CustomLoggerService
    constructor(
        private cacheHelper: CacheHelper,
        private storeIntegrationAcessessService: StoreIntegrationAcessessService,
        private customLoggerService: CustomLoggerService
    ) {
        this.customLoggerService.setContext(LineAppAuthTokenController.name);
        this.logger = customLoggerService;
    }

    @ApiOkResponse({ description: '', type: LineJsonResponseWithAccessToken})
    @Get('token')
    @Header('Content-Type', 'application/json')
    @InjectStoreToBody()
    @HttpCode(200)
    async token(
        @GetStore() store: StoreDto,
        @GetStoreIntegrationAccess() storeIntegrationAccess: StoreIntegrationAccess,
        @Headers() lineAuthTokenGenerateDto: LineAuthTokenGenerateDto
    ): Promise<LineJsonResponseWithAccessToken> {
        const response: LineJsonResponseWithAccessToken = {
            messageCode: LineResponseMessageCode.SomethigWentWrong,
            Message: '',
            ErrorCode: 0,
            AccessToken: ''
        };
        const accessToken = await this.storeIntegrationAcessessService.generateAccessToken(storeIntegrationAccess);
        await this.cacheHelper.set(`${store.id}:line-app-access-token-${storeIntegrationAccess.clientId}-${accessToken}`, accessToken, 3600);
        response.messageCode = LineResponseMessageCode.Success;
        response.Message = 'Success';
        response.AccessToken = accessToken;
        
        return response;
    }
}
