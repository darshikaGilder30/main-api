import {
    Controller,
    Get,
    Header,
    HttpCode,
    HttpException,
    Logger
} from '@nestjs/common';
import {
    ApiBearerAuth,
    ApiHeaders,
    ApiOkResponse,
    ApiSecurity,
    ApiTags
} from '@nestjs/swagger';
import { MuleService } from 'src/modules/mule/mule.service';
import { GetStore } from 'src/decorators/store.decorator';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { I18nContext } from 'nestjs-i18n';
import { GetCustomer } from 'src/decorators/customer.decorator';
import { ShopifyCustomer } from 'src/modules/shopify-admin-api/interfaces/shopify-customer.interface';
import * as moment from 'moment-timezone';
import { LineService } from '../line.service';
import { LineUserInfoJsonResponse } from '../dto/line-customer-info.dto';
import { LineResponseMessageCode } from 'src/enums/line-response-message-code.enum';
import { ShopifyCustomMeta } from 'src/enums/shopify-custom-meta.enum';
import { LineAscentiesVoucherTransformer } from '../transformers/line-ascentis-voucher.transformer';
import { plainToClass } from 'class-transformer';
import { LineCustomerVoucherJsonResponse } from '../dto/line-customer-vouchers.dto';
import { LineCustomerTransactionHistoryJsonResponse } from '../dto/line-customer-loyalty-transactions.dto';
import { LineAscentisTransactionHistoryTransformer } from '../transformers/line-ascentis-transaction-history.transformer';
import { CustomLoggerService } from 'src/modules/utils/custom-logger.service';

@Controller('external/line-app/customer')
@ApiTags('Line App - Customer')
@ApiSecurity('X-Access-Token')
@ApiBearerAuth('Authorization')
@ApiHeaders([
    {
        name: 'X-Client-Id',
        description: 'Client ID',
        required: true
    }
])
export class LineAppCustomerController {
    private logger : CustomLoggerService
    constructor(
        private muleService: MuleService,
        private lineService: LineService,
        private customLoggerService: CustomLoggerService
    ) {
        this.customLoggerService.setContext(LineAppCustomerController.name);
        this.logger = customLoggerService;
        moment.tz.setDefault('Etc/GMT+0');
    }

    @ApiOkResponse({ description: 'Info', type: LineUserInfoJsonResponse })
    @Get('info')
    @Header('Content-Type', 'application/json')
    @HttpCode(200)
    async info(
        @GetStore() store: StoreDto,
        @GetCustomer() shopifyCustomer: ShopifyCustomer
    ): Promise<LineUserInfoJsonResponse> {
        const cardNo = shopifyCustomer.metafields.find(
            (metafield) => metafield.key === ShopifyCustomMeta.LoyaltyCardNo
        )?.value;

        if (!cardNo) {
            throw new HttpException(
                I18nContext.current().translate('exception.ascentis_error'),
                400
            );
        }

        const muleResponse = await this.muleService.cardEnquiry(store, cardNo);

        if (!muleResponse.success || !muleResponse.data) {
            this.logger.error(`Failed to get card info for cardNo: ${cardNo}`);

            throw new HttpException(
                I18nContext.current().translate('exception.ascentis_error'),
                400
            );
        }

        shopifyCustomer.cardEnquiry = muleResponse.data;

        const response: LineUserInfoJsonResponse = {
            messageCode: LineResponseMessageCode.Success,
            Message: I18nContext.current().translate('line.success'),
            ErrorCode: 0,
            Customer: this.lineService.getUserInfo(store, shopifyCustomer)
        };

        return response;
    }

    @ApiOkResponse({
        description: 'Vouchers',
        type: LineCustomerVoucherJsonResponse
    })
    @Get('vouchers')
    @Header('Content-Type', 'application/json')
    @HttpCode(200)
    async vouchers(
        @GetStore() store: StoreDto,
        @GetCustomer() shopifyCustomer: ShopifyCustomer
    ): Promise<LineCustomerVoucherJsonResponse> {
        const response: LineCustomerVoucherJsonResponse = {
            messageCode: LineResponseMessageCode.Success,
            Message: I18nContext.current().translate('line.success'),
            ErrorCode: 0,
            Vouchers: []
        };
        const cardNo = shopifyCustomer.metafields.find(
            (metafield) => metafield.key === ShopifyCustomMeta.LoyaltyCardNo
        ).value;

        if (!cardNo) {
            throw new HttpException(
                I18nContext.current().translate('exception.ascentis_error'),
                400
            );
        }

        const muleResponse = await this.muleService.vouchers(store, cardNo);

        if (muleResponse.success && muleResponse.data) {
            const activeVouchers = muleResponse.data.ActiveVoucherLists;
            for (const voucher of activeVouchers) {
                response.Vouchers.push(
                    plainToClass(LineAscentiesVoucherTransformer, voucher, {
                        exposeUnsetFields: true,
                        strategy: 'excludeAll'
                    })
                );
            }

            return response;
        } else if (!muleResponse.success) {
            this.logger.error(`Failed to get vouchers for cardNo: ${cardNo}`);

            response.messageCode = LineResponseMessageCode.SomethigWentWrong;
            response.Message = I18nContext.current().translate(
                'exception.ascentis_error'
            );
        }

        return response;
    }

    @ApiOkResponse({ description: 'Transaction History' })
    @Get('transaction-histories')
    @Header('Content-Type', 'application/json')
    @HttpCode(200)
    async transactionHistories(
        @GetStore() store: StoreDto,
        @GetCustomer() shopifyCustomer: ShopifyCustomer
    ): Promise<LineCustomerTransactionHistoryJsonResponse> {
        const response: LineCustomerTransactionHistoryJsonResponse = {
            messageCode: LineResponseMessageCode.SomethigWentWrong,
            Message: '',
            ErrorCode: 0,
            Transactions: []
        };
        const cardNo = shopifyCustomer.metafields.find(
            (metafield) => metafield.key === ShopifyCustomMeta.LoyaltyCardNo
        ).value;

        if (!cardNo) {
            throw new HttpException(
                I18nContext.current().translate('exception.ascentis_error'),
                400
            );
        }

        const transactionMuleResponse =
            await this.muleService.transactionHistory(store, cardNo, true);

        if (transactionMuleResponse.success) {
            for (const transactionHistory of transactionMuleResponse.data
                ?.TransactionLists) {
                const transformedTransactionHistory = plainToClass(
                    LineAscentisTransactionHistoryTransformer,
                    transactionHistory,
                    {
                        exposeUnsetFields: true,
                        strategy: 'excludeAll'
                    }
                );
                
                transformedTransactionHistory.LoggedDate = transformedTransactionHistory.LoggedDate
                    ? moment(transformedTransactionHistory.LoggedDate, 'DD-MM-YYYY HH:mm:ss')
                        .tz(store.storeIntegrations.shopify.settings.timezone)
                        .format('DD/MM/YYYY')
                    : null;
                response.Transactions.push(transformedTransactionHistory);
            }

            response.messageCode = LineResponseMessageCode.Success;
            response.Message = I18nContext.current().translate('line.success');
        } else {
            this.logger.error(
                `Failed to get transaction history for cardNo: ${cardNo}`
            );

            response.messageCode = LineResponseMessageCode.SomethigWentWrong;
            response.Message = I18nContext.current().translate(
                'exception.ascentis_error'
            );
        }

        return response;
    }
}
