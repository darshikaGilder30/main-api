import { ApiProperty } from "@nestjs/swagger";
import { LineJsonResponse } from "./line-response.dto";
import { LineAscentisTransactionHistoryTransformer } from "../transformers/line-ascentis-transaction-history.transformer";

export class LineCustomerTransactionHistoryJsonResponse extends LineJsonResponse {
    
    @ApiProperty({
        description: 'Transactions',
        type: LineAscentisTransactionHistoryTransformer
    })
    Transactions: LineAscentisTransactionHistoryTransformer[];
}