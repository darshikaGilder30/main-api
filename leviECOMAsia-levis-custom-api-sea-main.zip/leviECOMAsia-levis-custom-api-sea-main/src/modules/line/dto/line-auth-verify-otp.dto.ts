import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, Length } from 'class-validator';
import { LineAuthValidateDto } from './line-auth-validate.dto';
import { i18nValidationMessage } from 'nestjs-i18n';
import { I18nTranslations } from 'src/generated/i18n.generated';
import { LineJsonResponse } from './line-response.dto';

export class LineVerifyOtpDto extends LineAuthValidateDto {
    
    @ApiProperty({
        description: 'The otp of the user to authenticate.'
    })
    @IsNotEmpty({
        message: i18nValidationMessage<I18nTranslations>("validation.otp_not_empty")
    })
    @Length(6, 6, {
        message: i18nValidationMessage<I18nTranslations>("validation.otp_length")
    })
    otp: string;
}


export class LineVerifyOtpResponseDto extends LineJsonResponse {
    @ApiProperty({
        description: 'The token to be used for further authentication.'
    })
    Token: {
        AccessToken: string;
    };
}