import { ApiProperty } from "@nestjs/swagger";
import { LineJsonResponse } from "./line-response.dto";
import { LineAscentiesVoucherTransformer } from "../transformers/line-ascentis-voucher.transformer";

export class LineCustomerVoucherJsonResponse extends LineJsonResponse {
    
    @ApiProperty({
        description: 'Vouchers',
        type: [LineAscentiesVoucherTransformer]
    })
    Vouchers: LineAscentiesVoucherTransformer[];
}