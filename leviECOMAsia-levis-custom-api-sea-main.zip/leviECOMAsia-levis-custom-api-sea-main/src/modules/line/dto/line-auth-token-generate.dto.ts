import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';
import { i18nValidationMessage } from 'nestjs-i18n';
import { I18nTranslations } from 'src/generated/i18n.generated';
import { LineJsonResponse } from './line-response.dto';

export class LineAuthTokenGenerateDto {
    @ApiProperty({
        description: 'X-Client-Id',
        example: 'khvjdhfefgfgfegeddfdfdf'
    })
    @IsNotEmpty({
        message: i18nValidationMessage<I18nTranslations>(
            'validation.required'
        )
    })
    "X-Client-Id": string;

    @ApiProperty({
        description: 'X-Client-Secret',
        example: 'khvjdhfefgfgfegeddfdfdf'
    })
    @IsNotEmpty({
        message: i18nValidationMessage<I18nTranslations>(
            'validation.required'
        )
    })
    "X-Client-Secret": string;
}

export class LineJsonResponseWithAccessToken extends LineJsonResponse {
    @ApiProperty({
        description: 'Access token',
        example: 'khvjdhfefgfgfegeddfdfdf'
    })
    AccessToken: string;
}
