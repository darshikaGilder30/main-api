import { ApiProperty } from "@nestjs/swagger";
import { LineResponseMessageCode } from "src/enums/line-response-message-code.enum";

export class LineJsonResponse {
    @ApiProperty({
        description: 'Message code',
        example: LineResponseMessageCode.Success
    })
    messageCode: LineResponseMessageCode;

    @ApiProperty({
        description: 'Message',
        example: 'Success'
    })
    Message: string;

    @ApiProperty({
        description: 'Error code',
        example: 0
    })
    ErrorCode: number;
}