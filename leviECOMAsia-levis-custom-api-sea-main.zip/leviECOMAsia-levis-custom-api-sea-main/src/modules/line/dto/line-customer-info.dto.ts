import { ApiProperty } from "@nestjs/swagger";
import { LineAuthUserInfoTransformer } from "../transformers/auth-user-info.transformer";
import { LineJsonResponse } from "./line-response.dto";

export class LineUserInfoJsonResponse extends LineJsonResponse {
    
    @ApiProperty({
        description: 'Customer',
        type: LineAuthUserInfoTransformer
    })
    Customer: LineAuthUserInfoTransformer;
}