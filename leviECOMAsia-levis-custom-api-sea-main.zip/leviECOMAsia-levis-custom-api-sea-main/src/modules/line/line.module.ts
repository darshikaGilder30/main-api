import { MiddlewareConsumer, Module } from '@nestjs/common';
import { LineService } from './line.service';
import { LineAppAuthController } from './controllers/line-app-auth.controller';
import { ShopifyProxyModule } from '../shopify-proxy/shopify-proxy.module';
import { ShopifyAdminApiModule } from '../shopify-admin-api/shopify-admin-api.module';
import { ShopifyStorefrontApiModule } from '../shopify-storefront-api/shopify-storefront-api.module';
import { MuleModule } from '../mule/mule.module';
import { OtpServiceModule } from '../otp-service/otp-service.module';
import { CacheHelperModule } from '../utils/cache/cache-helper.module';
import { OtpModule } from '../otp/otp.module';
import { StoreIntegrationAccessesModule } from 'src/entities/store-integration-accesses/store-integration-accesses.module';
import { StoreIntegrationAccessStoreMiddleware } from 'src/middlewares/store-integration-access-store/store-integration-access-store.middleware';
import { LineAppAuthTokenController } from './controllers/line-app-auth-token.controller';
import { StoreIntegrationAccessSecretValidateMiddleware } from 'src/middlewares/store-integration-access-secret-validate/store-integration-access-secret-validate.middleware';
import { StoreIntegrationAccessTokenValidateMiddleware } from 'src/middlewares/store-integration-access-token-validate/store-integration-access-token-validate.middleware';
import { StoreIntegrationValidateMiddleware } from 'src/middlewares/store-integration-validate/store-integration-validate.middleware';
import { JwtModule } from '@nestjs/jwt';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { LineAppCustomerController } from './controllers/line-app-customer.controller';
import { StoreIntegrationAccessCustomerValidateMiddleware } from 'src/middlewares/store-integration-access-customer-validate/store-integration-access-customer-validate.middleware';
import { ShopifyCustomerAuthenticateMiddleware } from 'src/middlewares/shopify-customer-authenticate/shopify-customer-authenticate.middleware';
import { CustomLoggerService } from '../utils/custom-logger.service';

@Module({
    imports: [
        ShopifyAdminApiModule,
        ShopifyStorefrontApiModule,
        MuleModule,
        ShopifyProxyModule,
        OtpServiceModule,
        CacheHelperModule,
        OtpModule,
        StoreIntegrationAccessesModule,
        JwtModule.registerAsync({
            imports: [ConfigModule],
            inject: [ConfigService],
            useFactory: async (configService: ConfigService) => ({
                secret: configService.get('line.jwt.secret'),
                signOptions: {
                    expiresIn: configService.get('line.jwt.expiry')
                }
            })
        })
    ],
    providers: [LineService, CustomLoggerService],
    controllers: [LineAppAuthController, LineAppAuthTokenController, LineAppCustomerController]
})
export class LineModule {
    configure(consumer: MiddlewareConsumer) {
        consumer
            .apply(StoreIntegrationAccessStoreMiddleware)
            .forRoutes(LineAppAuthController)
            .apply(StoreIntegrationValidateMiddleware)
            .forRoutes(LineAppAuthController)
            .apply(StoreIntegrationAccessTokenValidateMiddleware)
            .forRoutes(LineAppAuthController);

        consumer
            .apply(StoreIntegrationAccessStoreMiddleware)
            .forRoutes(LineAppAuthTokenController)
            .apply(StoreIntegrationValidateMiddleware)
            .forRoutes(LineAppAuthTokenController)
            .apply(StoreIntegrationAccessSecretValidateMiddleware)
            .forRoutes(LineAppAuthTokenController);

        consumer
            .apply(StoreIntegrationAccessStoreMiddleware)
            .forRoutes(LineAppCustomerController)
            .apply(StoreIntegrationValidateMiddleware)
            .forRoutes(LineAppCustomerController)
            .apply(StoreIntegrationAccessTokenValidateMiddleware)
            .forRoutes(LineAppCustomerController)
            .apply(StoreIntegrationAccessCustomerValidateMiddleware)
            .forRoutes(LineAppCustomerController)
            .apply(ShopifyCustomerAuthenticateMiddleware)
            .forRoutes(LineAppCustomerController);
    }
}
