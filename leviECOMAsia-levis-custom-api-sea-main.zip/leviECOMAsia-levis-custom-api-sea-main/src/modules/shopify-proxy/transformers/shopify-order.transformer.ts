import { Expose, Transform, Type, plainToClass } from 'class-transformer';
import * as moment from 'moment-timezone';
import { OrderAddressTransformer } from './shopify-order-address.transformer';
import { OrderLineItemTransformer } from './shopify-order-lineitems.transformer';

export class OrderTransformer {

    @Transform(({value}) => {
        return value.replace('gid://shopify/Order/', '');
    })
    @Expose({ name: 'id' })
    id: string;

    @Transform(({value}) => {
        return value.replace('#', '');
    })
    @Expose({ name: 'name' })
    orderId: string;

    @Transform((value) => {
        if (value.obj.cancelledAt) {
            return 'Cancelled';
        }
        if (value.obj.displayFinancialStatus === 'REFUNDED') {
            return 'Refunded';
        }

        const customAttributes = value.obj.customAttributes;
        const orderDeliveryStatus = customAttributes?.find((attribute) => attribute.key === 'orderDeliveryStatus')?.value;
        let status = 'Pending';
        switch (value.obj.displayFulfillmentStatus) {
            case 'FULFILLED':
                status = orderDeliveryStatus || 'In Progress';
                break;
            case 'OPEN':
            case 'UNFULFILLED':
                status = 'New Order';
                break;
            case 'PARTIALLY_FULFILLED':
                status = orderDeliveryStatus || 'In Progress';
                break;
            case 'PENDING_FULFILLMENT':
                status = 'In Progress';
                break;
            default:
                status = 'Pending';
                break;
        }

        if (value.obj.displayFinancialStatus === 'PARTIALLY_REFUNDED') {
            status += ' / Partially Refunded';
        } else if (value.obj.displayFinancialStatus === 'PENDING') {
            status += ' / Payment Pending';
        }

        return status;
    })
    @Expose()
    status: string;

    @Transform((value) => {
        return moment(value.obj.createdAt).toISOString();
    })
    @Expose()
    orderDate: string;

    @Type(() => OrderAddressTransformer)
    @Expose({ name: 'shippingAddress'})
    shippingAddress: OrderAddressTransformer;

    @Type(() => OrderLineItemTransformer)
    @Expose({ name: 'lineItems'})
    lineItems: OrderLineItemTransformer[];

    transformedFulfillments: {};

    fulfillments: {};
}
