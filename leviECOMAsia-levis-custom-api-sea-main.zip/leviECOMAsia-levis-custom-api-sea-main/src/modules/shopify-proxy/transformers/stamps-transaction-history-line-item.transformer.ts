import { Expose, Transform } from 'class-transformer';

export class StampsTransactionHistoryLineItemTransformer {
    @Transform(({ obj }) => {
        return obj.name;
    })
    @Expose({ name: 'ItemCode' })
    code: string;

    @Transform(({ obj }) => {
        return obj.display_name;
    })
    @Expose({ name: 'Description' })
    description: string;

    @Transform(({ obj }) => {
        return obj.quantity;
    })
    @Expose({ name: 'Quantity' })
    quantity: number;

    @Transform(({ obj }) => {
        return obj.price_per_unit;
    })
    @Expose({ name: 'Price' })
    price: number;

    @Transform(({ obj }) => {
        const discount = obj.stamps_bonus || 0;
        return discount;
    })
    @Expose({ name: 'Discount' })
    discount: number;

    @Transform(({ obj }) => {
        const totalAmount = obj.quantity * obj.price_per_unit;
        return totalAmount;
    })
    @Expose({ name: 'totalAmount' })
    totalAmount: number;

    @Transform(({ obj }) => {
        const netAmount = (obj.price_per_unit * obj.quantity) - (obj.stamps_bonus || 0);
        return netAmount;
    })
    @Expose({ name: 'Net' })
    netAmount: number;
}
