import { Expose, Transform } from 'class-transformer';
import { ShopifyCustomMeta } from 'src/enums/shopify-custom-meta.enum';

export class AuthUserInfoTransformer {

    @Transform(( {value} ) => {
        return value.replace('gid://shopify/Customer/', '')
    })
    @Expose({ name: 'id' })
    'id': string;

    @Expose({ name: 'email' })
    'email': string;

    @Expose({ name: 'firstName' })
    'firstName': string;

    @Expose({ name: 'lastName' })
    'lastName': string;

    @Expose({ name: 'phone' })
    'phone': string;

    @Transform(( value ) => {
        return value.obj.metafields?.find((edge) => edge.key === ShopifyCustomMeta.MembershipId)?.value || null;
    })
    @Expose()
    'membershipId': string;

    @Transform(( value ) => {
        return value.obj.metafields?.find((edge) => edge.key === ShopifyCustomMeta.Gender)?.value || null;
    })
    @Expose({name: 'metafields.edges'})
    'gender': string;

    @Transform(( value ) => {
        return value.obj.metafields?.find((edge) => edge.key === ShopifyCustomMeta.DateOfBirth)?.value || null;
    })
    @Expose()
    'dob': string;

    @Transform(( value ) => {
        return value.obj.metafields?.find((edge) => edge.key === ShopifyCustomMeta.Source)?.value || null;
    })
    @Expose()
    'source': string;

    @Transform(( value ) => {
        return (value.obj.metafields?.find((edge) => edge.key === ShopifyCustomMeta.Loyalty)?.value === 'true' ? true : false) || false;
    })
    @Expose()
    'loyalty': boolean;

    @Transform(( value ) => {
        return value.obj.metafields?.find((edge) => edge.key === ShopifyCustomMeta.PostalCode)?.value || null;
    })
    @Expose()
    'postalCode': string;

    @Transform((value) => {
        return value.obj.emailMarketingConsent?.marketingState === 'SUBSCRIBED' ? true : false;
    })
    @Expose({ name: 'emailMarketingConsent'})
    emailOptIn: boolean;

    @Transform(( value ) => {
        return value.obj.smsMarketingConsent?.marketingState === 'SUBSCRIBED' ? true : false;
    })
    @Expose({ name: 'smsMarketingConsent'})
    smsOptIn: boolean;

    @Transform(( value ) => {
        const tags = value.obj.tags || [];
        if (value.obj.state !== 'ENABLED') {
            tags.push('no_password')
        }
        return tags?.join(',') || null;
    })
    @Expose({ name: 'tags'})
    tags?: string;
}
