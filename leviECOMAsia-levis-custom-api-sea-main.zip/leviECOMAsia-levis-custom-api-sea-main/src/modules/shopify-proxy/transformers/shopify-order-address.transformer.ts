import { Expose, Transform, Type, plainToClass } from 'class-transformer';

export class OrderAddressTransformer {
    @Transform((value) => {
        return value.obj.name || '';
    })
    @Expose({ name: 'name' })
    name: string;

    @Transform((value) => {
        return value.obj.address1 || '';
    })
    @Expose()
    address1: string;

    @Transform((value) => {
        return value.obj.address2 || '';
    })
    @Expose()
    address2: string;

    @Transform((value) => {
        return value.obj.city || '';
    })
    @Expose()
    city: string;

    @Transform((value) => {
        return value.obj.formatted?.join(', ') || '';
    })
    @Expose()
    formatted: string;

    @Transform((value) => {
        return value.obj.country || '';
    })
    @Expose()
    country: string;

    @Transform((value) => {
        return value.obj.phone || '';
    })
    @Expose()
    phone: string;
}
