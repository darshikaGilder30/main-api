import { Expose, Transform } from 'class-transformer';

export class AscentiesVoucherTypeTransformer {

    @Expose({ name: 'Code' })
    'code': string;

    @Expose({ name: 'Description' })
    'description': string;

    @Transform(({ value }) => {
        return value == '<html>\r\n<head>\r\n\t<title></title>\r\n</head>\r\n<body></body>\r\n</html>\r\n' ? '' : value;
    })
    @Expose({ name: 'TnC' })
    'tnc': string;
}
