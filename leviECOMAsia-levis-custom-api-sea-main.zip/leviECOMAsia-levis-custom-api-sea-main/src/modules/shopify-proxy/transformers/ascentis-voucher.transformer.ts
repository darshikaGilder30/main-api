import { Expose, Transform } from 'class-transformer';
import { HelperService } from 'src/modules/utils/helper.service';

export class AscentiesVoucherTransformer {

    @Expose({ name: 'VoucherNo' })
    'id': string;

    @Expose({ name: 'VoucherTypeCode' })
    'code': string;

    @Expose({ name: 'VoucherTypeName' })
    'name': string;

    @Expose({ name: 'VoucherTypeDescription' })
    'description': string;

    @Expose({ name: 'Type' })
    'type': string;

    @Expose({ name: 'TypeValue' })
    'value': number;

    @Expose({ name: 'ValidFrom' })
    @Transform((value) => {
        return HelperService.parseAcentiesData(value.obj.ValidFrom, 'DD-MM-YYYY HH:mm:ss');
    })
    'validFrom': string;

    @Expose({ name: 'ValidTo' })
    @Transform((value) => {
        return HelperService.parseAcentiesData(value.obj.ValidTo, 'DD-MM-YYYY HH:mm:ss');
    })
    'validTo': string;

    @Expose({ name: 'IsRedeemable' })
    'isRedeemable': boolean;

    @Expose({ name: 'Status' })
    @Transform((value) => {
        return 'active';
    })
    'status': string;
}
