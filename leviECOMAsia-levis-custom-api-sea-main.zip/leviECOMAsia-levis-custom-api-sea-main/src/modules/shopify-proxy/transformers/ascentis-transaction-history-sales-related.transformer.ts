import { Expose, Transform } from 'class-transformer';
import { HelperService } from 'src/modules/utils/helper.service';

export class AscentiesTransactionHistorySalesRelatedTransformer {

    @Expose({ name: 'TransactDate' })
    @Transform((value) => {
        return `${HelperService.parseAcentiesData(value.obj.TransactDate, 'DD-MM-YYYY HH:mm:ss')}`;
    })
    transactionDate: string; 
    
    @Expose({ name: 'TransactType' })
    transactionType: string;

    @Expose({ name: 'Points' })
    points: number;

    @Expose({ name: 'SpendingAmt' })
    spendingAmount: number;

    @Expose()
    @Transform((value) => {
        return (value.obj.SpendingAmt - value.obj.NettSpent);
    })
    discount: number;

    @Expose({ name: 'NettSpent' })
    netSpent: number;

    @Expose({ name: 'TransactionRefID' })
    transactionRefId: string;

    @Expose({ name: 'ReceiptNo' })
    receiptNo: string;

    @Expose({ name: 'TransactOutletName' })
    storeName: string;

    @Expose({ name: 'VoucherTypeCode' })
    voucherCode: string;
}
