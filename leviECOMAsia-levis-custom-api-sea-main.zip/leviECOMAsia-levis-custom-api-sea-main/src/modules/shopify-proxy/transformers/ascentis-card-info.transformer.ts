import { Expose, Transform, Type, plainToClass } from 'class-transformer';
import * as moment from 'moment-timezone';
import { HelperService } from 'src/modules/utils/helper.service';

export class AscentiesCardRewardCycleListTransformer {
    @Expose({ name: 'PointsType' })
    type: string;

    @Expose({ name: 'PointsBALValue' })
    pointsBalance: number;

    @Transform(({value}) => {
        return moment(value).format('ll');
    })
    @Expose({ name: 'PointsExpiringDate' })
    pointsExpiringDate: string;
}

export class AscentiesCardInfoTransformer {

    @Transform((value) => {
        return value.obj.CardInfo.CardNo;
    })
    @Expose()
    'cardNo': string;

    @Transform((value) => {
        return value.obj.CardInfo.TierCode;
    })
    @Expose()
    'tierCode': string;

    @Transform((value) => {
        return value.obj.CardInfo.DollarToPointsRatio;
    })
    @Expose()
    'dollarToPointsRatio': string;

    @Transform((value) => {
        return value.obj.CardInfo.TotalPointsBAL;
    })
    @Expose()
    'totalPointsBalance': number;

    @Transform((value) => {
        return HelperService.rebateValueFromPoints(
            value.obj.CardInfo.TotalPointsBAL,
            value.obj.CardInfo.DollarToPointsRatio
        );
    })
    @Expose()
    'totalCash': number;

    @Transform((value) => {
        return value.obj.MembershipInfo?.TotalPoints;
    })
    @Expose()
    'totalPointsEarned': number;

    @Expose()
    @Transform((value) => {
        const graceRewardCycle = value.obj.CardInfo.RewardCycleLists?.filter(
            (rewardCycle) => rewardCycle.PointsType === 'Grace'
        )?.sort((a, b) =>
            moment(b.PointsExpiringDate).diff(moment(a.PointsExpiringDate))
        )[0];

        return plainToClass(
            AscentiesCardRewardCycleListTransformer,
            graceRewardCycle,
            {
                exposeUnsetFields: true,
                strategy: 'excludeAll'
            }
        );
    })
    recentexpiryReward: AscentiesCardRewardCycleListTransformer;
}
