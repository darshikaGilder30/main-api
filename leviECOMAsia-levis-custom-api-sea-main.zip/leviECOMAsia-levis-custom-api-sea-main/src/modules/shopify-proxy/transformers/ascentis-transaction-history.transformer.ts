import { Expose, Transform, Type } from 'class-transformer';
import { HelperService } from 'src/modules/utils/helper.service';
import { AscentiesTransactionHistoryLineItemTransformer } from './ascentis-transaction-history-line-item.transformer';
import { AscentiesTransactionHistorySalesRelatedTransformer } from './ascentis-transaction-history-sales-related.transformer';

export class AscentiesTransactionHistoryTransformer {

    @Expose({ name: 'TransactDate' })
    @Transform((value) => {
        return `${HelperService.parseAcentiesData(value.obj.TransactDate, 'DD-MM-YYYY HH:mm:ss')}`;
    })
    transactionDate: string; 
    
    @Transform((value) => {
        return value.obj.Remark.includes('POINTREFUND') ? 'POINTS REDEMPTION REFUND' : value.obj.TransactType;
    })
    @Expose({ name: 'TransactType' })
    transactionType: string;

    @Expose({ name: 'Points' })
    points: number;

    @Expose({ name: 'SpendingAmt' })
    spendingAmount: number;

    @Expose()
    @Transform((value) => {
        return (value.obj.SpendingAmt - value.obj.NettSpent);
    })
    discount: number;

    @Expose({ name: 'NettSpent' })
    netSpent: number;

    @Expose({ name: 'TransactionRefID' })
    transactionRefId: string;

    @Expose({ name: 'ReceiptNo' })
    receiptNo: string;

    @Expose({ name: 'TransactOutletName' })
    storeName: string;

    @Expose({ name: 'VoucherTypeCode' })
    voucherCode: string;

    @Expose({ name: 'ItemCode' })
    @Transform(({value}) => {
        return value.trim().replace(/,$/, '');
    })
    voucherNo: string;

    @Transform((value) => {
        if (value.obj.TransactionRefID?.includes('_C')) {
            return 'Refund-Cancelled';
        } else if (value.obj.TransactionRefID?.includes('_R')) {
            return 'Refund-Return';
        } else {
            return 'Purchased';
        }
    })
    @Expose()
    status: string;

    @Expose({ name: 'SalesRelatedTransactionList' })
    @Type(() => AscentiesTransactionHistorySalesRelatedTransformer)
    salesRelatedTransactionList: AscentiesTransactionHistorySalesRelatedTransformer[];

    @Expose({ name: 'TransactionDetailsList' })
    @Type(() => AscentiesTransactionHistoryLineItemTransformer)
    lineItems: AscentiesTransactionHistoryLineItemTransformer[];
}
