import { Expose, Transform, Type, plainToClass } from 'class-transformer';
import * as moment from 'moment-timezone';

export class OrderLineItemTransformer {

    @Transform(({value}) => {
        return value.replace('gid://shopify/LineItem/', '');
    })
    @Expose({ name: 'id' })
    lineItemId: string;

    @Transform((value) => {
        return value.obj.title || '';
    })
    @Expose({ name: 'title' })
    title: string;

    @Transform((value) => {
        return (
            value.obj.variant?.selectedOptions
                ?.map((option) => `${option.name}: ${option.value}`)
                .join(', ') || ''
        );
    })
    @Expose()
    description: string;

    @Transform((value) => {
        return value.obj.quantity || 0;
    })
    @Expose({ name: 'quantity' })
    quantity: number;

    @Transform((value) => {
        return value.obj.originalUnitPriceSet?.shopMoney?.amount || 0;
    })
    @Expose({ name: 'originalUnitPriceSet' })
    unitPrice: string;

    @Transform((value) => {
        return value.obj.originalTotalSet?.shopMoney?.amount || 0;
    })
    @Expose({ name: 'originalTotalSet' })
    subTotal: string;

    @Transform((value) => {
        return value.obj.image?.url || value.obj.variant?.image?.url;
    })
    @Expose()
    imageUrl: string;
}
