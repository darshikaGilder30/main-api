import { Expose, Transform, Type } from 'class-transformer';
import { ShopifyCustomMeta } from 'src/enums/shopify-custom-meta.enum';
import { OrderAddressTransformer } from './shopify-order-address.transformer';

export class LocationTransformer {
    @Expose({ name: 'name' })
    'name': string;

    @Type(() => OrderAddressTransformer)
    @Expose({ name: 'address' })
    'address': OrderAddressTransformer;

    @Transform(( value ) => {
        return value.obj.metafields?.find((edge) => edge.key.includes(ShopifyCustomMeta.OpeningTime))?.value || null;
    })
    @Expose()
    'openingTime': string;

    @Transform(( value ) => {
        return value.obj.metafields?.find((edge) => edge.key.includes(ShopifyCustomMeta.ClosingTime))?.value || null;
    })
    @Expose()
    'closingTime': string;

    @Transform(( value ) => {
        return value.obj.metafields?.find((edge) => edge.key.includes(ShopifyCustomMeta.StoreCode))?.value || null;
    })
    @Expose()
    'storeCode': string;

    @Expose({ name: 'distance' })
    'distance': number;

    @Expose({ name: 'shipsInventory' })
    'shipsInventory': boolean;

    @Expose({ name: 'quantity' })
    quantity: number;
}
