import { Expose, Transform } from 'class-transformer';

export class ShopifyBasicDiscountCreateTransformer {
    @Transform((value) => {
        return {
            orderDiscounts: value.obj.combinesWith?.orderDiscounts || false,
            productDiscounts: value.obj.combinesWith?.productDiscounts || false,
            shippingDiscounts:
                value.obj.combinesWith?.shippingDiscounts || false
        };
    })
    @Expose({ name: 'combinesWith' })
    combinesWith: {
        orderDiscounts: boolean;
        productDiscounts: boolean;
        shippingDiscounts: boolean;
    };

    @Transform((value) => {
        const customerGets = value.obj.customerGets.value;
        const customerGetItems = value.obj.customerGets.items;
        return {
            items: {
                all:
                    customerGetItems?.collections?.nodes?.length ||
                    customerGetItems?.productVariants?.nodes?.length ||
                    customerGetItems?.products?.nodes?.length
                        ? false
                        : true,
                collections: customerGetItems?.collections?.nodes?.length
                    ? {
                          add: customerGetItems.collections.nodes.map(
                              (collection) => collection.id
                          )
                      }
                    : {},
                products: {
                    productVariantsToAdd: customerGetItems?.productVariants
                        ?.nodes?.length
                        ? customerGetItems?.productVariants?.nodes.map(
                              (variant) => variant.id
                          )
                        : [],
                    productsToAdd: customerGetItems?.products?.nodes?.length
                        ? customerGetItems?.products?.nodes.map(
                              (product) => product.id
                          )
                        : []
                }
            },
            value:
                customerGets.__typename === 'DiscountPercentage'
                    ? {
                          percentage: customerGets.percentage
                      }
                    : {
                          discountAmount: {
                              amount: customerGets.amount.amount,
                              appliesOnEachItem: customerGets.appliesOnEachItem
                          }
                      }
        };
    })
    @Expose({ name: 'customerGets' })
    customerGets: {
        items: {
            all: boolean;
        };
        value: {
            percentage?: number;
            amount?: number;
        };
    };

    @Transform((value) => {
        return {
            subtotal: value.obj.minimumRequirement?.subtotal
                ?.greaterThanOrEqualToSubtotal
                ? {
                      greaterThanOrEqualToSubtotal:
                          value.obj.minimumRequirement?.subtotal
                              ?.greaterThanOrEqualToSubtotal
                  }
                : value.obj.minimumRequirement?.greaterThanOrEqualToSubtotal
                ? {
                      greaterThanOrEqualToSubtotal:
                          value.obj.minimumRequirement
                              ?.greaterThanOrEqualToSubtotal?.amount
                  }
                : null,
            quantity: value.obj.minimumRequirement?.quantity
                ?.greaterThanOrEqualTo
                ? {
                    greaterThanOrEqualToQuantity:
                          value.obj.minimumRequirement?.quantity
                              ?.greaterThanOrEqualTo
                  }
                : value.obj.minimumRequirement?.greaterThanOrEqualToQuantity
                ? {
                    greaterThanOrEqualToQuantity:
                          value.obj.minimumRequirement
                              ?.greaterThanOrEqualToQuantity
                  }
                : null
        };
    })
    @Expose({ name: 'minimumRequirement' })
    minimumRequirement: {
        subtotal?: {
            greaterThanOrEqualToSubtotal: number;
        };
        quantity?: {
            greaterThanOrEqualTo: number;
        };
    };

    @Expose({ name: 'startsAt' })
    startsAt: string;

    @Expose({ name: 'endsAt' })
    endsAt?: string;

    @Expose({ name: 'usageLimit' })
    usageLimit: number;

    @Transform((value) => {
        return {
            customers: {
                add: []
            }
        };
    })
    @Expose({ name: 'customerSelection' })
    customerSelection: {
        customers: {
            add: [string];
        };
    };

    @Expose({ name: 'code' })
    code: string;

    @Expose({ name: 'title' })
    title: string;

    @Expose({ name: 'appliesOncePerCustomer' })
    appliesOncePerCustomer: boolean;
}
