import { Expose } from 'class-transformer';

export class StampsRewardVoucherTransformer {

    @Expose({ name: 'id' })
    id: number;

    @Expose({ name: 'name' })
    name: string;

    @Expose({ name: 'title' })
    title: string;

    @Expose({ name: 'description' })
    description: string;

    @Expose({ name: 'stamps_to_redeem' })
    points: number;

    @Expose({ name: 'image_url' })
    imageUrl: string;
}
