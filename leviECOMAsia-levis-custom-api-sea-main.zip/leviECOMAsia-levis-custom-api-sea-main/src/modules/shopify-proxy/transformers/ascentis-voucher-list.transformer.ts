import { Expose, Type } from 'class-transformer';
import { AscentiesVoucherTransformer } from './ascentis-voucher.transformer';

export class AscentiesVoucherListTransformer {

    @Type(() => AscentiesVoucherTransformer)
    @Expose({ name: 'ActiveVoucherLists' })
    activeVouchers: AscentiesVoucherTransformer[];

    expiredVouchers?: AscentiesVoucherTransformer[];

    redeemedVouchers?: AscentiesVoucherTransformer[];
}
