import { Expose, Transform } from 'class-transformer';

export class AscentiesTransactionHistoryLineItemTransformer {

    @Expose({ name: 'ItemCode' })
    code: string;
    
    @Expose({ name: 'Description' })
    description: string;

    @Expose({ name: 'Quantity' })
    quantity: number;

    @Expose({ name: 'Price' })
    price: number;

    @Expose({ name: 'Discount' })
    discount: number;

    @Transform((value) => {
        return (value.obj.Quantity * value.obj.Price);
    })
    @Expose()
    totalAmount: number;

    @Expose({ name: 'Net' })
    netAmount: number;
}
