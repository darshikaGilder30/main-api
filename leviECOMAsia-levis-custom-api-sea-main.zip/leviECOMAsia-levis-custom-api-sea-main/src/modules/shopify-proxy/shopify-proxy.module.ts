import { MiddlewareConsumer, Module } from '@nestjs/common';
import { ShopifyProxyService } from './shopify-proxy.service';
import { ShopifyProxySignatureValidateMiddleware } from 'src/middlewares/shopify-proxy-signature-validate/shopify-proxy-signature-validate.middleware';
import { ShopifyProxyAuthController } from './controllers/shopify-proxy-auth.controller';
import { ShopifyAdminApiModule } from '../shopify-admin-api/shopify-admin-api.module';
import { MuleModule } from '../mule/mule.module';
import { ShopifyStorefrontApiModule } from '../shopify-storefront-api/shopify-storefront-api.module';
import { OtpServiceModule } from '../otp-service/otp-service.module';
import { OtpModule } from '../otp/otp.module';
import { StoreMiddleware } from 'src/middlewares/store/store.middleware';
import { StoresModule } from 'src/entities/stores/stores.module';
import { StoreIntegrationValidateMiddleware } from 'src/middlewares/store-integration-validate/store-integration-validate.middleware';
import { ShopifyCustomerAuthenticateMiddleware } from 'src/middlewares/shopify-customer-authenticate/shopify-customer-authenticate.middleware';
import { ShopifyProxyCustomerController } from './controllers/shopify-proxy-customer.controller';
import { ShopifyProxyAccountController } from './controllers/shopify-proxy-account.controller';
import { LiquidTemplateService } from '../utils/liquid.service';
import { ShopifyProxyCustomerAddressController } from './controllers/shopify-proxy-customer-address.controller';
import { ShopifyProxyReferrerController } from './controllers/shopify-proxy-referrer.controller';
import { ReferrerIntegrationValidateMiddleware } from 'src/middlewares/referrer-integration-validate/referrer-integration-validate.middleware';
import { ShopifyProxyDiscountController } from './controllers/shopify-proxy-discount.controller';
import { ShopifyProxyOrderController } from './controllers/shopify-proxy-order.controller';
import { ShopifyCustomerStorefrontAuthenticateMiddleware } from 'src/middlewares/shopify-customer-storefront-authenticate/shopify-customer-storefront-authenticate.middleware';
import { ShopifyProxyLocationController } from './controllers/shopify-proxy-location.controller';
import { CacheHelperModule } from '../utils/cache/cache-helper.module';
import { HttpModule } from '@nestjs/axios';
import { StampsModule } from '../stamps/stamps.module';
import { StampsRewriteMiddleware } from 'src/middlewares/stamps-rewrite/stamps-rewrite.middleware';
import { InvoiceService } from '../utils/invoice.service';
import { MuleXStoreModule } from '../mule-x-store/mule-x-store.module';
import { ShopifyProxyOtpController } from './controllers/shopify-proxy-otp.controller';
import { CustomLoggerService } from '../utils/custom-logger.service';
import { AddressesModule } from 'src/entities/addresses/addresses.module';
import { ShopifyProxyAddressController } from './controllers/shopify-proxy-address.controller';
import { StocksModule } from 'src/entities/stocks/stocks.module';
import { GoogleRecaptchaValidateMiddleware } from 'src/middlewares/google-recaptcha-validate/google-recaptcha-validate.middleware';
import { GoogleRecaptchaModule } from '../google-recaptcha/google-recaptcha.module';
import { CrmLoyaltyModule } from '../crm-loyalty/crm-loyalty.module';
import { ShopifyProxySpinAndWinController } from './controllers/shopify-proxy-spin-and-win.controller';

@Module({
    imports: [
        CacheHelperModule,
        StoresModule,
        ShopifyAdminApiModule,
        MuleModule,
        ShopifyStorefrontApiModule,
        OtpServiceModule,
        OtpModule,
        HttpModule,
        StampsModule,
        MuleXStoreModule,
        AddressesModule,
        StocksModule,
        GoogleRecaptchaModule,
        CrmLoyaltyModule
    ],
    providers: [
        ShopifyProxyService,
        LiquidTemplateService,
        InvoiceService,
        CustomLoggerService,
    ],
    exports: [ShopifyProxyService],
    controllers: [
        ShopifyProxyAuthController,
        ShopifyProxyAccountController,
        ShopifyProxyCustomerController,
        ShopifyProxyReferrerController,
        ShopifyProxyCustomerAddressController,
        ShopifyProxyDiscountController,
        ShopifyProxyOrderController,
        ShopifyProxyLocationController,
        ShopifyProxyOtpController,
        ShopifyProxyAddressController,
        ShopifyProxySpinAndWinController
    ]
})
export class ShopifyProxyModule {
    configure(consumer: MiddlewareConsumer) {
        consumer
            .apply(ShopifyProxySignatureValidateMiddleware)
            .forRoutes(ShopifyProxyAuthController)
            .apply(StoreMiddleware)
            .forRoutes(ShopifyProxyAuthController)
            .apply(StoreIntegrationValidateMiddleware)
            .forRoutes(ShopifyProxyAuthController);

        consumer
            .apply(ShopifyProxySignatureValidateMiddleware)
            .forRoutes(ShopifyProxyCustomerController)
            .apply(StoreMiddleware)
            .forRoutes(ShopifyProxyCustomerController)
            .apply(StoreIntegrationValidateMiddleware)
            .forRoutes(ShopifyProxyCustomerController)
            .apply(ShopifyCustomerAuthenticateMiddleware)
            .forRoutes(ShopifyProxyCustomerController);

        consumer
            .apply(ShopifyProxySignatureValidateMiddleware)
            .forRoutes(ShopifyProxyAccountController)
            .apply(StoreMiddleware)
            .forRoutes(ShopifyProxyAccountController)
            .apply(StoreIntegrationValidateMiddleware)
            .forRoutes(ShopifyProxyAccountController)
            .apply(ShopifyCustomerAuthenticateMiddleware)
            .forRoutes(ShopifyProxyAccountController);

        consumer
            .apply(ShopifyProxySignatureValidateMiddleware)
            .forRoutes(ShopifyProxySpinAndWinController)
            .apply(StoreMiddleware)
            .forRoutes(ShopifyProxySpinAndWinController)
            .apply(StoreIntegrationValidateMiddleware)
            .forRoutes(ShopifyProxySpinAndWinController)
            .apply(ShopifyCustomerAuthenticateMiddleware)
            .forRoutes(ShopifyProxySpinAndWinController);

        consumer
            .apply(ShopifyProxySignatureValidateMiddleware)
            .forRoutes(ShopifyProxyCustomerAddressController)
            .apply(StoreMiddleware)
            .forRoutes(ShopifyProxyCustomerAddressController)
            .apply(StoreIntegrationValidateMiddleware)
            .forRoutes(ShopifyProxyCustomerAddressController)
            .apply(ShopifyCustomerAuthenticateMiddleware)
            .forRoutes(ShopifyProxyCustomerAddressController);

        consumer
            .apply(ShopifyProxySignatureValidateMiddleware)
            .forRoutes(ShopifyProxyReferrerController)
            .apply(StoreMiddleware)
            .forRoutes(ShopifyProxyReferrerController)
            .apply(StoreIntegrationValidateMiddleware)
            .forRoutes(ShopifyProxyReferrerController)
            .apply(ReferrerIntegrationValidateMiddleware)
            .forRoutes(ShopifyProxyReferrerController)
            .apply(ShopifyCustomerAuthenticateMiddleware)
            .forRoutes(ShopifyProxyReferrerController);

        consumer
            .apply(ShopifyProxySignatureValidateMiddleware)
            .forRoutes(ShopifyProxyDiscountController)
            .apply(StoreMiddleware)
            .forRoutes(ShopifyProxyDiscountController)
            .apply(StoreIntegrationValidateMiddleware)
            .forRoutes(ShopifyProxyDiscountController)
            .apply(ShopifyCustomerStorefrontAuthenticateMiddleware)
            .forRoutes(ShopifyProxyDiscountController)
            .apply(ShopifyCustomerAuthenticateMiddleware)
            .forRoutes(ShopifyProxyDiscountController);

        consumer
            .apply(ShopifyProxySignatureValidateMiddleware)
            .forRoutes(ShopifyProxyOrderController)
            .apply(StoreMiddleware)
            .forRoutes(ShopifyProxyOrderController)
            .apply(StoreIntegrationValidateMiddleware)
            .forRoutes(ShopifyProxyOrderController);

        consumer
            .apply(ShopifyCustomerAuthenticateMiddleware)
            .forRoutes('shopify-proxy-order/order-status');
       
        consumer
            .apply(ShopifyProxySignatureValidateMiddleware)
            .forRoutes(ShopifyProxyLocationController)
            .apply(StoreMiddleware)
            .forRoutes(ShopifyProxyLocationController)
            .apply(StoreIntegrationValidateMiddleware)
            .forRoutes(ShopifyProxyLocationController);

        // Stamps Rewrite Middleware
		consumer.apply(StampsRewriteMiddleware)
            .forRoutes('shopify-proxy-discount/vouchers')
            .apply(StampsRewriteMiddleware)
            .forRoutes('shopify-proxy-account/vouchers')
            .apply(StampsRewriteMiddleware)
            .forRoutes('shopify-proxy-account/rewards')
            .apply(StampsRewriteMiddleware)
            .forRoutes('shopify-proxy-account/transaction-histories')
            .apply(StampsRewriteMiddleware)
            .forRoutes('shopify-proxy-account/purchase-histories')
            .apply(StampsRewriteMiddleware)
            .forRoutes('shopify-proxy-discount/apply-voucher')
            .apply(StampsRewriteMiddleware)
            .forRoutes('shopify-proxy-discount/remove-voucher')
            .apply(StampsRewriteMiddleware)
            .forRoutes('shopify-proxy-discount/loyalty-points');

        consumer
            .apply(ShopifyProxySignatureValidateMiddleware)
            .forRoutes(ShopifyProxyOtpController)
            .apply(StoreMiddleware)
            .forRoutes(ShopifyProxyOtpController)
            .apply(StoreIntegrationValidateMiddleware)
            .forRoutes(ShopifyProxyOtpController);

        consumer
            .apply(ShopifyProxySignatureValidateMiddleware)
            .forRoutes(ShopifyProxyAddressController)
            .apply(StoreMiddleware)
            .forRoutes(ShopifyProxyAddressController)
            .apply(StoreIntegrationValidateMiddleware)
            .forRoutes(ShopifyProxyAddressController);

        consumer
            .apply(GoogleRecaptchaValidateMiddleware)
            .forRoutes('shopify-proxy-auth/validate', 'shopify-proxy-auth/resend-otp')
        
    }
}
