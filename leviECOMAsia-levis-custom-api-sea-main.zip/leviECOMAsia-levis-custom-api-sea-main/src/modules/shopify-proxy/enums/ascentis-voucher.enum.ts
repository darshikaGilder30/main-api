export enum VoucherTypes {
    TOKEN = 'Token',
    CASH = 'Cash'
}
export enum VoucherCodes {
    SWT = 'SWT',
}
