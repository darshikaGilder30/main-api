import {
    Body,
    Controller,
    Get,
    Header,
    HttpCode,
    HttpException,
    Post,
    Query,
    Res
} from '@nestjs/common';
import { ApiOkResponse, ApiTags } from '@nestjs/swagger';
import { GetStore } from 'src/decorators/store.decorator';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { I18nContext } from 'nestjs-i18n';
import { LiquidTemplateService } from 'src/modules/utils/liquid.service';
import { JsonResponse } from 'src/interfaces/http/json-response.interface';
import { InjectStoreToBody } from 'src/decorators/inject-store/inject-store.decorator';
import { ShopifyProxyAccountTrackOrderDto } from '../dto/shopify-proxy-order-track-order.dto';
import { ShopifyAdminApiService } from 'src/modules/shopify-admin-api/shopify-admin-api.service';
import { plainToClass } from 'class-transformer';
import { OrderTransformer } from '../transformers/shopify-order.transformer';
import { HttpService } from '@nestjs/axios';
import { lastValueFrom } from 'rxjs';
import { ShopifyProxyOrderReturnStatusDto } from '../dto/shopify-proxy-order-return-status.dto';
import { GetCustomer } from 'src/decorators/customer.decorator';
import { ShopifyCustomer } from 'src/modules/shopify-admin-api/interfaces/shopify-customer.interface';
import { ShopifyProxyAccountInvoiceGenerateDto } from '../dto/shopify-proxy-order-invoice-generate.dto';
import { InvoiceService } from 'src/modules/utils/invoice.service';
import { Response } from 'express';
import { CustomLoggerService } from 'src/modules/utils/custom-logger.service';

@Controller('shopify-proxy-order')
@ApiTags('Shopify Proxy App - Order')
export class ShopifyProxyOrderController {
    private logger: CustomLoggerService;
    constructor(
        private liquidService: LiquidTemplateService,
        private shopifyAdminApiService: ShopifyAdminApiService,
        private httpService: HttpService,
        private invoiceService: InvoiceService,
        private customLoggerService: CustomLoggerService
    ) {
        this.customLoggerService.setContext(ShopifyProxyOrderController.name);
        this.logger = this.customLoggerService
    }

    @ApiOkResponse({ description: 'Track Order' })
    @Post('track-order')
    @Header('Content-Type', 'application/json')
    @InjectStoreToBody()
    @HttpCode(200)
    async trackOrder(
        @GetStore() store: StoreDto,
        @Body()
        shopifyProxyAccountTrackOrderDto: ShopifyProxyAccountTrackOrderDto
    ): Promise<JsonResponse> {
        const response: JsonResponse = {
            message: '',
            data: {
                content: '',
                order: null
            }
        };

        if (shopifyProxyAccountTrackOrderDto.token) {
            // base64 decode token
            const token = Buffer.from(
                shopifyProxyAccountTrackOrderDto.token,
                'base64'
            ).toString('ascii');

            const tokenParts = token.split(':');
            shopifyProxyAccountTrackOrderDto.username = tokenParts[0];
            shopifyProxyAccountTrackOrderDto.orderId = tokenParts[1];
        }

        const shopifyCustomer = await this.shopifyAdminApiService.searchCustomerByUsername(
            store,
            shopifyProxyAccountTrackOrderDto?.username
        )

        if (!shopifyCustomer.success || !shopifyCustomer.data) {
            response.message = shopifyCustomer.message;
            if (!shopifyCustomer.success) {
                this.logger.error(
                    `trackOrder: searchCustomerByUsername Failed: ${shopifyProxyAccountTrackOrderDto?.username} - ${response.message}`
                );
            }

            const template = await this.liquidService.render(
                store,
                'track-order',
                {
                    orderId: null
                }
            );

            response.data.content = template;

            return response;
        }

        const orderDetails = await this.shopifyAdminApiService.getOrder(
            store,
            shopifyCustomer.data,
            shopifyProxyAccountTrackOrderDto
        );

        if (orderDetails.success && orderDetails.data) {
            const order = plainToClass(OrderTransformer, orderDetails.data, {
                exposeUnsetFields: true,
                strategy: 'excludeAll'
            })
            if (orderDetails.data.tags?.includes('ACP Orders') || orderDetails.data.tags?.includes('No_Invoice') || store.storeIntegrations.shopify.settings?.invoiceAvailable === 'false') {
                order.fulfillments = [];
            } else {
                order.fulfillments = orderDetails.data.fulfillments
            }
            for (const fulfillment of orderDetails.data.fulfillments) {
                order.transformedFulfillments = {};
                if (fulfillment.fulfillmentLineItems?.edges?.length > 0) {
                    for (const fulfillmentLineItem of fulfillment.fulfillmentLineItems.edges) {
                        const lineItemId = fulfillmentLineItem.node.lineItem.id.replace('gid://shopify/LineItem/', '')
                        if (!order.transformedFulfillments[lineItemId]) {
                            order.transformedFulfillments[lineItemId] = [];
                        }
                        order.transformedFulfillments[lineItemId].push(fulfillment);
                    }
                }
            }

            const template = await this.liquidService.render(
                store,
                'track-order',
                {
                    ...order,
                    settings: store.storeIntegrations.shopify.settings
                }
            );

            response.data.content = template;
            response.data.order = order
        } else {
            const template = await this.liquidService.render(
                store,
                'track-order',
                {
                    orderId: null
                }
            );

            response.data.content = template;
        }

        return response;
    }

    @ApiOkResponse({ description: 'Return Status' })
    @Get('order-status')
    @Header('Content-Type', 'application/json')
    @InjectStoreToBody()
    @HttpCode(200)
    async orderReturnStatus(
        @GetStore() store: StoreDto,
        @Query() shopifyProxyOrderReturnStatusDto: ShopifyProxyOrderReturnStatusDto,
        @GetCustomer() shopifyCustomer: ShopifyCustomer
    ): Promise<JsonResponse> {
        const response: JsonResponse = {
            message: '',
            data: {
                return: [],
                order: {}
            }
        };

        const orderResponse = await this.shopifyAdminApiService.getOrder(
            store,
            shopifyCustomer,
            {
                orderId: shopifyProxyOrderReturnStatusDto.orderId,
                username: shopifyCustomer.email
            }
        );

        if (!orderResponse.success || !orderResponse.data) {
            this.logger.error(
                `orderReturnStatus: getOrder Failed: ${shopifyProxyOrderReturnStatusDto?.orderId} - ${response.message}`
            );
            throw new HttpException(
                I18nContext.current().translate('exception.failed'),
                404
            );
        }

        response.data.order = orderResponse.data

        if (orderResponse.data.tags?.includes('ACP Orders') || orderResponse.data.tags?.includes('No_Invoice') || store.storeIntegrations.shopify.settings?.invoiceAvailable === 'false') {
            response.data.order.fulfillments = [];
        }

        try {
            const orderReturn = await lastValueFrom(
                this.httpService.get('https://admin.returnprime.com/return-exchange/v2', {
                    params: {
                        order_name: shopifyProxyOrderReturnStatusDto.orderId
                    },
                    headers: {
                        'x-rp-token': store.storeIntegrations.shopify.credentials.returnPrimeApiToken
                    }
                }
            ))

            response.data.return = orderReturn.data.data?.list || [];
            
            return response;
        } catch (error) {
            this.logger.error(
                `orderReturnStatus: Failed: ${shopifyProxyOrderReturnStatusDto?.orderId} - ${error.message}`
            );
        }

        return response;
    }

    @ApiOkResponse({ description: 'Generate Invoice' })
    @Get('generate-invoice')
    @Header('Content-Type', 'application/pdf')
    @HttpCode(200)
    async generateInvoice(
        @GetStore() store: StoreDto,
        @Query() shopifyProxyAccountInvoiceGenerateDto: ShopifyProxyAccountInvoiceGenerateDto,
        @Res() res: Response
    ) {
        if (store.storeIntegrations.shopify.settings.invoiceAvailable === 'false') {
            this.logger.error(
                `generateInvoice: Invoice not available: ${shopifyProxyAccountInvoiceGenerateDto?.orderId}`
            );
            throw new HttpException(
                I18nContext.current().translate('exception.failed'),
                400
            );
        }

        const invoice = await this.invoiceService.generateInvoice(store, {
            fulfillment_id: shopifyProxyAccountInvoiceGenerateDto.fulfillmentId,
            order_id: shopifyProxyAccountInvoiceGenerateDto.orderId
        })

        if (!invoice.invoice) {
            this.logger.error(
                `generateInvoice: Failed: ${shopifyProxyAccountInvoiceGenerateDto?.orderId}`
            );
            throw new HttpException(
                I18nContext.current().translate('exception.failed'),
                400
            );
        }
        
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', `attachment; filename=${invoice.fulfillment.name}.pdf`);
        res.setHeader('Content-Length', invoice.invoice.length);
        res.send(invoice.invoice);

        return;
    }
}
