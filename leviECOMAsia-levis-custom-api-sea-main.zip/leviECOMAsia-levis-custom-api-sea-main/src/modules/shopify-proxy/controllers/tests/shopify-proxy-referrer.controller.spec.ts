import { MuleService } from 'src/modules/mule/mule.service';
import { CustomLoggerService } from 'src/modules/utils/custom-logger.service';
import { HttpException } from '@nestjs/common';
import { AuthFlows } from 'src/enums/auth-flows.enum';
import { ShopifyProxyReferrerController } from '../shopify-proxy-referrer.controller';
import { ShopifyProxyReferrerDto } from '../../dto/shopify-proxy-referrer-refer.dto';

describe('ShopifyProxyReferrerController', () => {
    let controller: ShopifyProxyReferrerController;
    let mockMuleService: Partial<MuleService>;
    let mockCustomLoggerService: Partial<CustomLoggerService>;

    beforeEach(() => {
        mockMuleService = {
            friendInvitationCreate: jest.fn(),
        };
        mockCustomLoggerService = {
            error: jest.fn(),
        };
        controller = new ShopifyProxyReferrerController(
            mockMuleService as MuleService,
            mockCustomLoggerService as CustomLoggerService
        );
    });

    afterEach(() => {
        jest.clearAllMocks();
    });

    it('should create a friend invitation successfully', async () => {
        const mockDto: ShopifyProxyReferrerDto = {
            username: 'test',
        };
        const mockStore: any = {}; // provide mock store data
        const mockCustomer: any = {}; // provide mock customer data

        // mockMuleService.friendInvitationCreate.mockResolvedValue({
        //     success: true,
        //     data: null, // provide any mock data as needed
        // });


        const result = await controller.friendInvitationCreate(
            mockStore,
            mockCustomer,
            mockDto
        );

        expect(result.data.nextflow).toBe(AuthFlows.None);
        expect(result.data.info).toBeNull();
        expect(result.data.settings).toBe(mockStore.storeIntegrations.shopify.settings);
    });

    it('should throw an error if friend invitation creation fails', async () => {
        const mockDto: ShopifyProxyReferrerDto = {
            username: 'test',            
        };
        const mockStore: any = {}; // provide mock store data
        const mockCustomer: any = {}; // provide mock customer data

        // mockMuleService.friendInvitationCreate.mockResolvedValue({
        //     success: false,
        //     data: null,
        // });

        await expect(() =>
            controller.friendInvitationCreate(mockStore, mockCustomer, mockDto)
        ).rejects.toThrow(HttpException);

        expect(mockCustomLoggerService.error).toHaveBeenCalled();
    });
});
