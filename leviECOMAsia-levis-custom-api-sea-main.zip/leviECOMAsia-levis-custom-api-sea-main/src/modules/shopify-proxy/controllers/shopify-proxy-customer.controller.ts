import {
    Body,
    Controller,
    Header,
    HttpCode,
    HttpException,
    Logger,
    Post,
    Put
} from '@nestjs/common';
import { ApiOkResponse, ApiTags } from '@nestjs/swagger';
import { ShopifyAdminApiService } from 'src/modules/shopify-admin-api/shopify-admin-api.service';
import { MuleService } from 'src/modules/mule/mule.service';
import { JsonResponse } from 'src/interfaces/http/json-response.interface';
import { AuthFlows } from 'src/enums/auth-flows.enum';
import { GetStore } from 'src/decorators/store.decorator';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { I18nContext } from 'nestjs-i18n';
import { GetCustomer } from 'src/decorators/customer.decorator';
import { ShopifyCustomer } from 'src/modules/shopify-admin-api/interfaces/shopify-customer.interface';
import { ShopifyProxyCustomerUpdateDto } from '../dto/shopify-proxy-customer-update.dto';
import { ShopifyCustomMeta } from 'src/enums/shopify-custom-meta.enum';
import { ShopifyProxyCustomerPasswordResetDto } from '../dto/shopify-proxy-customer-password-reset.dto';
import { ShopifyStorefrontApiService } from 'src/modules/shopify-storefront-api/shopify-storefront-api.service';
import { CustomLoggerService } from 'src/modules/utils/custom-logger.service';
import { ShopifyProxyService } from '../shopify-proxy.service';
import { CrmLoyaltyFactory } from 'src/modules/crm-loyalty/crm-loyalty.factory';

@Controller('shopify-proxy-customer')
@ApiTags('Shopify Proxy App - Customer')
export class ShopifyProxyCustomerController {
    private logger: CustomLoggerService;
    constructor(
        private shopifyAdminApiService: ShopifyAdminApiService,
        private muleService: MuleService,
        private shopifyStorefrontApiService: ShopifyStorefrontApiService,
        private customLoggerService: CustomLoggerService,
        private shopifyProxyService: ShopifyProxyService,
        private crmLoyaltyFactory: CrmLoyaltyFactory
    ) {
        this.customLoggerService.setContext(ShopifyProxyCustomerController.name);
        this.logger = this.customLoggerService
    }

    @ApiOkResponse({ description: 'Profile Update' })
    @Put('profile-update')
    @Header('Content-Type', 'application/json')
    @HttpCode(200)
    async profileUpdate(
        @GetStore() store: StoreDto,
        @GetCustomer() shopifyCustomer: ShopifyCustomer,
        @Body() shopifyProxyCustomerUpdateDto: ShopifyProxyCustomerUpdateDto
    ): Promise<JsonResponse> {
        const response: JsonResponse = {
            message: '',
            data: {
                nextflow: AuthFlows.None,
                info: null,
                settings: store.storeIntegrations.shopify.settings
            }
        };

        const updateCustomer =
            await this.shopifyProxyService.updateShopifyCustomer(
                store,
                shopifyCustomer,
                {
                    firstName: shopifyProxyCustomerUpdateDto.firstName,
                    lastName: shopifyProxyCustomerUpdateDto.lastName,
                    gender: shopifyProxyCustomerUpdateDto.gender,
                    postalCode: shopifyProxyCustomerUpdateDto.postalCode,
                }
            );

        if (updateCustomer.success) {
            const shopifyUpdateData = {
                firstName: shopifyProxyCustomerUpdateDto.firstName,
                lastName: shopifyProxyCustomerUpdateDto.lastName,
                gender: shopifyProxyCustomerUpdateDto.gender,
                emailOptIn: shopifyProxyCustomerUpdateDto.emailOptIn,
                smsOptIn: shopifyProxyCustomerUpdateDto.smsOptIn,
                membershipId: shopifyCustomer.metafields.find((metafield) => metafield.key === ShopifyCustomMeta.MembershipId)?.value
            }
            const loyaltyService = this.crmLoyaltyFactory.getIntegration(store);
            if (loyaltyService) {
                 await loyaltyService.memberUpdate(
                    store,
                    shopifyUpdateData
                );
            }

            await this.shopifyAdminApiService.updateEmailMarketingConsent(
                store,
                shopifyCustomer,
                shopifyProxyCustomerUpdateDto.emailOptIn
            )

            await this.shopifyAdminApiService.updateSmsMarketingConsent(
                store,
                shopifyCustomer,
                shopifyProxyCustomerUpdateDto.smsOptIn
            )

            response.message = I18nContext.current().translate('message.profile_updated_successfully');
            
            return response;
        }
        
        this.logger.error(
            `customerUpdate: shopifyCustomer Failed: ${shopifyCustomer.email} - ${updateCustomer.message}`
        );
        throw new HttpException(
            I18nContext.current().translate('exception.failed'),
            400
        );
    }

    @ApiOkResponse({ description: 'Password Reset' })
    @Post('password-reset')
    @Header('Content-Type', 'application/json')
    @HttpCode(200)
    async passwordReset(
        @GetStore() store: StoreDto,
        @GetCustomer() shopifyCustomer: ShopifyCustomer,
        @Body() shopifyProxyCustomerPasswordResetDto: ShopifyProxyCustomerPasswordResetDto
    ): Promise<JsonResponse> {
        const response: JsonResponse = {
            message: '',
            data: {
                nextflow: AuthFlows.None,
                info: null,
                settings: store.storeIntegrations.shopify.settings
            }
        };

        if (shopifyProxyCustomerPasswordResetDto.currentPassword === shopifyProxyCustomerPasswordResetDto.password) {
            
            throw new HttpException(
                I18nContext.current().translate('validation.same_password'),
                400
            );
        }

        const customerAccessToken = await this.shopifyStorefrontApiService.login(store, shopifyCustomer.email, shopifyProxyCustomerPasswordResetDto.currentPassword);

        if (!customerAccessToken.success || !customerAccessToken.data?.accessToken) {
            this.logger.error(
                `passwordReset: shopifyCustomer Failed: ${shopifyCustomer.email} - ${customerAccessToken.message}`
            );
            throw new HttpException(
                I18nContext.current().translate('validation.current_password_wrong'),
                400
            );
        }

        const passwordReset = await this.shopifyStorefrontApiService.customerUpdatePassword(
            store,
            customerAccessToken.data.accessToken,
            shopifyProxyCustomerPasswordResetDto.password
        )

        if (passwordReset.success) {
            response.message = I18nContext.current().translate('message.password_reset_success');
            return response;
        }

        this.logger.error(
            `passwordReset: shopifyCustomer Failed: ${shopifyCustomer.email} - ${passwordReset.message}`
        );
        throw new HttpException(
            I18nContext.current().translate('exception.failed'),
            400
        );
    }
}