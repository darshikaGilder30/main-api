import { Controller, Get, Header, HttpCode, Query } from '@nestjs/common';
import { ApiOkResponse, ApiTags } from '@nestjs/swagger';
import { JsonResponse } from 'src/interfaces/http/json-response.interface';
import { GetStore } from 'src/decorators/store.decorator';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { CustomLoggerService } from 'src/modules/utils/custom-logger.service';
import { AddressesService } from 'src/entities/addresses/addresses.service';
import { ShopifyProxyAddressQueryDto } from '../dto/shopify-proxy-address-query.dto';
import { Address } from 'src/entities/addresses/addresses.entity';

@Controller('shopify-proxy-address')
@ApiTags('Shopify Proxy App - Address')
export class ShopifyProxyAddressController {
    private logger: CustomLoggerService;
    constructor(
        private customLoggerService: CustomLoggerService,
        private addressesService: AddressesService
    ) {
        this.customLoggerService.setContext(ShopifyProxyAddressController.name);
        this.logger = this.customLoggerService;
    }

    @ApiOkResponse({ description: 'Get Addresses' })
    @Get('addresses')
    @Header('Content-Type', 'application/json')
    @HttpCode(200)
    async addresses(
        @GetStore() store: StoreDto,
        @Query()
        shopifyProxyAddressQueryDto: ShopifyProxyAddressQueryDto & Address
    ): Promise<JsonResponse> {
        if (shopifyProxyAddressQueryDto.province) {
            shopifyProxyAddressQueryDto.province = decodeURIComponent(
                shopifyProxyAddressQueryDto.province
            );
        }
        if (shopifyProxyAddressQueryDto.city) {
            shopifyProxyAddressQueryDto.city = decodeURIComponent(
                shopifyProxyAddressQueryDto.city
            );
        }
        if (shopifyProxyAddressQueryDto.district) {
            shopifyProxyAddressQueryDto.district = decodeURIComponent(
                shopifyProxyAddressQueryDto.district
            );
        }

        const response: JsonResponse = {
            message: '',
            data: {
                addresses: await this.addressesService.find(
                    store,
                    shopifyProxyAddressQueryDto
                )
            }
        };

        return response;
    }

    @Get('migrate')
    async migrateAddress() {
        this.addressesService.migrateFiles();
    }
}
