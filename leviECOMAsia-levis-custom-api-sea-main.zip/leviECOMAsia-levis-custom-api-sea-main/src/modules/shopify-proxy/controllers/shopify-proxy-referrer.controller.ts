import {
    Body,
    Controller,
    Header,
    HttpCode,
    HttpException,
    Logger,
    Post
} from '@nestjs/common';
import { ApiOkResponse, ApiTags } from '@nestjs/swagger';
import { MuleService } from 'src/modules/mule/mule.service';
import { JsonResponse } from 'src/interfaces/http/json-response.interface';
import { AuthFlows } from 'src/enums/auth-flows.enum';
import { GetStore } from 'src/decorators/store.decorator';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { InjectStoreToBody } from 'src/decorators/inject-store/inject-store.decorator';
import { ShopifyProxyReferrerDto } from '../dto/shopify-proxy-referrer-refer.dto';
import { GetCustomer } from 'src/decorators/customer.decorator';
import { ShopifyCustomer } from 'src/modules/shopify-admin-api/interfaces/shopify-customer.interface';
import { I18nContext } from 'nestjs-i18n';
import { CustomLoggerService } from 'src/modules/utils/custom-logger.service';

@Controller('shopify-proxy-referrer')
@ApiTags('Shopify Proxy App - Referrer')
export class ShopifyProxyReferrerController {
    private logger: CustomLoggerService;
    constructor(
        private muleService: MuleService,
        private customLoggerService: CustomLoggerService
    ) {
        this.customLoggerService.setContext(ShopifyProxyReferrerController.name);
        this.logger = this.customLoggerService
    }

    @ApiOkResponse({ description: 'Referrer' })
    @Post('invite')
    @Header('Content-Type', 'application/json')
    @InjectStoreToBody()
    @HttpCode(200)
    async friendInvitationCreate(
        @GetStore() store: StoreDto,
        @GetCustomer() shopifyCustomer: ShopifyCustomer,
        @Body() shopifyProxyReferrerDto: ShopifyProxyReferrerDto
    ): Promise<JsonResponse> {
        const response: JsonResponse = {
            message: '',
            data: {
                nextflow: AuthFlows.None,
                info: null,
                settings: store.storeIntegrations.shopify.settings
            }
        };

        const muleResponse = await this.muleService.friendInvitationCreate(
            shopifyProxyReferrerDto,
            store,
            shopifyCustomer
        );

        if (muleResponse.success && muleResponse.data) {
            response.data.info = null;

            return response;
        }

        this.logger.error(
            `friendInvitationCreate: friendInvitationCreate Failed: ${shopifyProxyReferrerDto.username}`
        );
        throw new HttpException(
            I18nContext.current().translate('exception.failed'),
            400
        );
    }
}
