import {
    Body,
    Controller,
    Get,
    Header,
    HttpCode,
    HttpException,
    Logger,
    Post,
    Query
} from '@nestjs/common';
import { ApiOkResponse, ApiTags } from '@nestjs/swagger';
import { MuleService } from 'src/modules/mule/mule.service';
import { GetStore } from 'src/decorators/store.decorator';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { I18nContext } from 'nestjs-i18n';
import { GetCustomer } from 'src/decorators/customer.decorator';
import { ShopifyCustomer } from 'src/modules/shopify-admin-api/interfaces/shopify-customer.interface';
import { plainToClass, plainToInstance } from 'class-transformer';
import { ShopifyCustomMeta } from 'src/enums/shopify-custom-meta.enum';
import { AscentiesVoucherListTransformer } from '../transformers/ascentis-voucher-list.transformer';
import { JsonResponse } from 'src/interfaces/http/json-response.interface';
import { AscentiesCardInfoTransformer } from '../transformers/ascentis-card-info.transformer';
import { HelperService } from 'src/modules/utils/helper.service';
import { ShopifyProxyLoyaltyApplyDto } from '../dto/shopify-proxy-loyalty-apply.dto';
import { ShopifyProxyVoucherApplyDto } from '../dto/shopify-proxy-voucher-apply.dto';
import { AscentiesVoucherTransformer } from '../transformers/ascentis-voucher.transformer';
import * as moment from 'moment-timezone';
import { CacheHelper } from 'src/modules/utils/cache/cache-helper.service';
import { ShopifyAdminApiService } from 'src/modules/shopify-admin-api/shopify-admin-api.service';
import { AscentiesVoucherTypeTransformer } from '../transformers/ascentis-voucher-type.transformer';
import { CustomLoggerService } from 'src/modules/utils/custom-logger.service';
import { LoyaltyHelperService } from 'src/modules/utils/loyalty-helper.service';
import { VoucherTypes } from '../enums/ascentis-voucher.enum';

@Controller('shopify-proxy-discount')
@ApiTags('Shopify Proxy App - Discount')
export class ShopifyProxyDiscountController {
    private logger: CustomLoggerService;
    constructor(
        private muleService: MuleService,
        private shopifyAdminApiService: ShopifyAdminApiService,
        private cacheHelper: CacheHelper,
        private customLoggerService: CustomLoggerService
    ) { 
        this.customLoggerService.setContext(ShopifyProxyDiscountController.name);
        this.logger = this.customLoggerService
    }

    @ApiOkResponse({ description: 'Vouchers' })
    @Get('vouchers')
    @Header('Content-Type', 'application/json')
    @HttpCode(200)
    async vouchers(
        @GetStore() store: StoreDto,
        @GetCustomer() shopifyCustomer: ShopifyCustomer
    ): Promise<JsonResponse> {
        const response: JsonResponse = {
            message: '',
            data: {
                vouchers: [],
                settings: store.storeIntegrations.shopify.settings
            }
        };
        const cardNo = shopifyCustomer.metafields.find(
            (metafield) => metafield.key === ShopifyCustomMeta.LoyaltyCardNo
        )?.value;

        if (!cardNo) {
            throw new HttpException(
                I18nContext.current().translate('exception.ascentis_error'),
                400
            );
        }

        const muleResponse = await this.muleService.vouchers(store, cardNo);

        if (muleResponse.success && muleResponse.data) {
            const voucherList = plainToClass(
                AscentiesVoucherListTransformer,
                muleResponse.data,
                {
                    exposeUnsetFields: true,
                    strategy: 'excludeAll'
                }
            );
            voucherList.activeVouchers = voucherList.activeVouchers.filter(
                (voucher) => voucher.type !== VoucherTypes.TOKEN
            );

            voucherList.activeVouchers.forEach((voucher) => {
                voucher.validFrom = voucher.validFrom
                    ? moment(voucher.validFrom, 'DD-MM-YYYY HH:mm:ss')
                        .tz(store.storeIntegrations.shopify.settings.timezone)
                        .format('DD-MM-YYYY HH:mm:ss')
                    : null;
                voucher.validTo = voucher.validTo
                    ? moment(voucher.validTo, 'DD-MM-YYYY HH:mm:ss')
                        .tz(store.storeIntegrations.shopify.settings.timezone)
                        .format('DD-MM-YYYY HH:mm:ss')
                    : null;
            });

            response.data.vouchers = voucherList.activeVouchers;
        }

        return response;
    }

    @ApiOkResponse({ description: 'Apply Loyalty Points' })
    @Post('loyalty-points')
    @Header('Content-Type', 'application/json')
    @HttpCode(200)
    async loyaltyPoints(
        @GetStore() store: StoreDto,
        @GetCustomer() shopifyCustomer: ShopifyCustomer,
        @Body() shopifyProxyLoyaltyApplyDto: ShopifyProxyLoyaltyApplyDto
    ): Promise<JsonResponse> {
        const response: JsonResponse = {
            message: '',
            data: {
                calculation: {},
                attributes: [],
                failedRules: []
            }
        };

        const cardNo = shopifyCustomer.metafields.find(
            (metafield) => metafield.key === ShopifyCustomMeta.LoyaltyCardNo
        )?.value;

        if (!cardNo) {
            throw new HttpException(
                I18nContext.current().translate('exception.ascentis_error'),
                400
            );
        }

        const muleResponse = await this.cacheHelper.remember(
            `${store.id}:ascentis-card-info-${cardNo}`,
            60,
            async () => {
                return await this.muleService.cardEnquiry(store, cardNo);
            }
        );

        if (muleResponse.success && muleResponse.data) {
            const cardInfo = plainToClass(
                AscentiesCardInfoTransformer,
                muleResponse.data,
                {
                    exposeUnsetFields: true,
                    strategy: 'excludeAll'
                }
            );

            response.data.calculation =
                LoyaltyHelperService.calculateRedeemableLoyalty(
                    cardInfo.totalPointsBalance,
                    cardInfo.dollarToPointsRatio,
                    shopifyProxyLoyaltyApplyDto,
                    store.storeIntegrations.ascentis.settings
                );
            response.data.failedRules = [
                ...response.data.failedRules,
                ...response.data.calculation.failedRules
            ];
            delete response.data.calculation.failedRules;

            if (shopifyProxyLoyaltyApplyDto.applyLoyalty === true) {
                response.data.attributes = [
                    {
                        key: '_loyalty_redemption_payload',
                        value: Buffer.from(
                            JSON.stringify({
                                points: cardInfo.totalPointsBalance,
                                cash: cardInfo.totalCash,
                                dollarToPointsRatio:
                                    cardInfo.dollarToPointsRatio,
                                tierCode: cardInfo.tierCode,
                                settings:
                                    store.storeIntegrations.ascentis.settings,
                                // timestamp: new Date().getTime(),
                                calculation: response.data.calculation
                            })
                        ).toString('base64')
                    }
                ];
            } else {
                response.data.attributes = [
                    {
                        key: '_loyalty_redemption_payload',
                        value: Buffer.from('{}').toString('base64')
                    }
                ];
            }
        } else {
            this.logger.error(
                `Failed to get card info for card no: ${cardNo} with error: ${muleResponse?.message}`
            );

            throw new HttpException(
                I18nContext.current().translate('exception.ascentis_error'),
                400
            );
        }

        return response;
    }

    @ApiOkResponse({ description: 'Apply Voucher' })
    @Post('apply-voucher')
    @Header('Content-Type', 'application/json')
    @HttpCode(200)
    async applyVoucher(
        @GetStore() store: StoreDto,
        @GetCustomer() shopifyCustomer: ShopifyCustomer,
        @Body() shopifyProxyVoucherApplyDto: ShopifyProxyVoucherApplyDto
    ): Promise<JsonResponse> {
        const response: JsonResponse = {
            message: '',
            data: {}
        };

        const cardNo = shopifyCustomer.metafields.find(
            (metafield) => metafield.key === ShopifyCustomMeta.LoyaltyCardNo
        )?.value;

        if (!cardNo) {
            throw new HttpException(
                I18nContext.current().translate('exception.ascentis_error'),
                400
            );
        }

        const muleResponse = await this.muleService.vouchers(
            store,
            cardNo,
            shopifyProxyVoucherApplyDto.code
        );
        if (
            muleResponse.success &&
            muleResponse.data &&
            muleResponse.data['ActiveVoucherLists']?.length > 0
        ) {
            const voucher = plainToClass(
                AscentiesVoucherTransformer,
                muleResponse.data['ActiveVoucherLists'][0],
                {
                    exposeUnsetFields: true,
                    strategy: 'excludeAll'
                }
            );

            const discountCode = await this.shopifyAdminApiService.createOrGetCustomerDiscount(
                store,
                shopifyCustomer,
                voucher
            )

            if (discountCode) {
                response.data = {
                    settings: store.storeIntegrations.shopify.settings
                };

                return response;
            }
        }

        this.logger.error(
            `Failed to get card info for card no: ${cardNo} with error: ${muleResponse?.message}`
        );
        // delete voucher in shopify
        this.shopifyAdminApiService.deleteDiscountIfExist(
            store,
            shopifyCustomer,
            shopifyProxyVoucherApplyDto.code
        ).then((res) => {
            this.logger.log(`Delete voucher ${shopifyProxyVoucherApplyDto.code} in shopify ${res}`);
        }).catch((err) => {
            this.logger.error(`Delete voucher ${shopifyProxyVoucherApplyDto.code} in shopify failed`);
        })

        throw new HttpException(
            I18nContext.current().translate('exception.ascentis_error'),
            400
        );
    }

    @ApiOkResponse({ description: 'Remove Voucher' })
    @Post('remove-voucher')
    @Header('Content-Type', 'application/json')
    @HttpCode(200)
    async removeVoucher(
        @GetStore() store: StoreDto,
        @GetCustomer() shopifyCustomer: ShopifyCustomer,
        @Body() shopifyProxyVoucherApplyDto: ShopifyProxyVoucherApplyDto
    ): Promise<JsonResponse> {
        const response: JsonResponse = {
            message: '',
            data: {}
        };

        // delete voucher in shopify
        const deletedDiscount = await this.shopifyAdminApiService.deleteDiscountIfExist(
            store,
            shopifyCustomer,
            shopifyProxyVoucherApplyDto.code
        )

        return response;
    }

    @ApiOkResponse({ description: 'Voucher Type' })
    @Get('voucher-type')
    @Header('Content-Type', 'application/json')
    @HttpCode(200)
    async voucherType(
        @GetStore() store: StoreDto,
        @GetCustomer() shopifyCustomer: ShopifyCustomer,
        @Query() shopifyProxyVoucherApplyDto: ShopifyProxyVoucherApplyDto
    ): Promise<JsonResponse> {
        const response: JsonResponse = {
            message: '',
            data: {
                voucherType: null,
                settings: store.storeIntegrations.shopify.settings
            }
        };

        const muleResponse = await this.muleService.voucherType(store, shopifyProxyVoucherApplyDto.code);

        if (muleResponse.success && muleResponse.data && muleResponse.data.VoucherTypeLists?.length > 0) {

            response.data.voucherType = plainToInstance(
                AscentiesVoucherTypeTransformer,
                muleResponse.data.VoucherTypeLists[0],
                {
                    exposeUnsetFields: true,
                    strategy: 'excludeAll'
                }
            )
        }

        return response;
    }
}
