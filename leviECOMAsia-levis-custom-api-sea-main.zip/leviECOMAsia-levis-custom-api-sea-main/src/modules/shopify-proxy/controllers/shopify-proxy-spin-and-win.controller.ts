import {
    BadRequestException,
    Controller,
    Get,
    Header,
    HttpCode,
    Redirect
} from '@nestjs/common';
import { ApiOkResponse, ApiTags } from '@nestjs/swagger';
import { MuleService } from 'src/modules/mule/mule.service';
import { GetStore } from 'src/decorators/store.decorator';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { GetCustomer } from 'src/decorators/customer.decorator';
import { ShopifyCustomer } from 'src/modules/shopify-admin-api/interfaces/shopify-customer.interface';
import { ShopifyCustomMeta } from 'src/enums/shopify-custom-meta.enum';
import { JsonResponse } from 'src/interfaces/http/json-response.interface';
import { CustomLoggerService } from 'src/modules/utils/custom-logger.service';
import { HelperService } from 'src/modules/utils/helper.service';
import { VoucherCodes, VoucherTypes } from '../enums/ascentis-voucher.enum';

@Controller('shopify-proxy-spin-and-win')
@ApiTags('Shopify Proxy App - Discount')
export class ShopifyProxySpinAndWinController {
    private logger: CustomLoggerService;
    constructor(
        private muleService: MuleService,
        private customLoggerService: CustomLoggerService
    ) {
        this.customLoggerService.setContext(
            ShopifyProxySpinAndWinController.name
        );
        this.logger = this.customLoggerService;
    }

    @ApiOkResponse({ description: 'Spin and Win Token vouchers' })
    @Get('tokens-and-vouchers')
    @Header('Content-Type', 'application/json')
    @HttpCode(200)
    async tokenVoucher(
        @GetStore() store: StoreDto,
        @GetCustomer() shopifyCustomer: ShopifyCustomer
    ): Promise<JsonResponse> {
        const response: JsonResponse = {
            message: '',
            data: {}
        };
        try {
            const cardNo = shopifyCustomer.metafields.find(
                (metafield) => metafield.key === ShopifyCustomMeta.LoyaltyCardNo
            ).value;
            this.logger.debug(
                `${store.name} - Fetching Spin Token and Vouchers count for ${shopifyCustomer.displayName}`
            );
            if (!cardNo) {
                this.logger
                    .warn(`${store.name} - Loyalty card number not found for customer ${shopifyCustomer.id} | ${shopifyCustomer.email},
                }`);
                response.message = 'Loyalty card number not found';
                return response;
            }
            const vouchersMuleResponse = await this.muleService.vouchers(
                store,
                cardNo,
                '',
                VoucherCodes.SWT
            );

            if (vouchersMuleResponse.success && vouchersMuleResponse.data) {
                const activeVouchers =
                    vouchersMuleResponse.data?.ActiveVoucherLists || [];
                    const tokenVouchers = activeVouchers.filter(voucher => voucher.Type === "Token").length || 0;
                    const cashVouchers = activeVouchers.filter(voucher => voucher.Type === "Cash").length || 0;

                this.logger.log(
                    `${store.name} - Successfully received voucher data from Mule service. cashVouchersCount: ${cashVouchers}, tokenVouchersCount ${tokenVouchers}`
                );

                response.data = {
                    vouchers_count: cashVouchers,
                    spin_tokens: tokenVouchers
                };
            }

        } catch (error) {
            this.logger.error(
                `${store.name} - Error fetching Spin Tokens or Vouchers: ${error.message}`,
                error.stack
            );

            response.message = 'An error occurred while fetching data. Please try again later.';
            return response;
        }

        return response;
    }

    @ApiOkResponse({
        description: 'Encrypt Shopify Customer Email and Member ID and Redirect'
    })
    @Get('redirect')
    @Header('Content-Type', 'application/json')
    @HttpCode(302)
    @Redirect()
    async spinWinRedirect(
        @GetStore() store: StoreDto,
        @GetCustomer() shopifyCustomer: ShopifyCustomer
    ) {
        const response: JsonResponse = {
            message: '',
            data: null
        };
        try {
            const email = shopifyCustomer.email;
            this.logger.debug(
                `${store.name} - Redirecting to Ascentis Spin the Wheel page for customer ${shopifyCustomer.displayName}`
            );
            if (!email) {
                this.logger.warn(
                    `${store.name} - Missing required data: Email for customer ${shopifyCustomer.displayName}`
                );
                response.message =
                    'Missing required data: Email';
                throw new BadRequestException(response);
            }

            const accessToken = HelperService.encodeToUtf16Hex(email);

            const spinWinUrl = store.storeIntegrations.ascentis.settings.spinWinUrl;
            if (!spinWinUrl) {
                this.logger.error(
                    `${store.name} - Ascentis spinWin redirection url and configured`
                );
                return;
            }

            const redirectUrl = `${spinWinUrl}?access_token=${accessToken}`;
            this.logger.log(
                `${store.name} - Redirecting to Spin & Win URL: ${redirectUrl}`
            );
            return { url: redirectUrl };
        } catch (error) {
            this.logger.error(
                `${store.name} - Error during Spin & Win redirection: ${error.message}`,
                error.stack
            );

            throw new BadRequestException({
                message: 'An error occurred while processing your request.',
                data: null
            });
        }
    }
}
