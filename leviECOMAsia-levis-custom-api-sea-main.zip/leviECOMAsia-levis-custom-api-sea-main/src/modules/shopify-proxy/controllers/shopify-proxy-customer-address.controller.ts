import {
    Body,
    Controller,
    Header,
    HttpCode,
    HttpException,
    Logger,
    Post,
    Put
} from '@nestjs/common';
import { ApiOkResponse, ApiTags } from '@nestjs/swagger';
import { JsonResponse } from 'src/interfaces/http/json-response.interface';
import { AuthFlows } from 'src/enums/auth-flows.enum';
import { GetStore } from 'src/decorators/store.decorator';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { I18nContext } from 'nestjs-i18n';
import { GetCustomer } from 'src/decorators/customer.decorator';
import { ShopifyCustomer } from 'src/modules/shopify-admin-api/interfaces/shopify-customer.interface';
import { ShopifyStorefrontApiService } from 'src/modules/shopify-storefront-api/shopify-storefront-api.service';
import { ShopifyProxyCustomerAddressDto } from '../dto/shopify-proxy-customer-address.dto';
import { ShopifyProxyService } from '../shopify-proxy.service';
import { ShopifyProxyCustomerAddressUpdateDto } from '../dto/shopify-proxy-customer-address-update.dto';
import { InjectStoreToBody } from 'src/decorators/inject-store/inject-store.decorator';
import { CustomLoggerService } from 'src/modules/utils/custom-logger.service';

@Controller('shopify-proxy-customer-address')
@ApiTags('Shopify Proxy App - Customer Address')
export class ShopifyProxyCustomerAddressController {
    private logger: CustomLoggerService;
    constructor(
        private shopifyStorefrontApiService: ShopifyStorefrontApiService,
        private shopifyProxyService: ShopifyProxyService,
        private customLoggerService: CustomLoggerService
    ) {
        this.customLoggerService.setContext(ShopifyProxyCustomerAddressController.name);
        this.logger = this.customLoggerService
    }

    @ApiOkResponse({ description: 'Address Create' })
    @Post('address-create')
    @Header('Content-Type', 'application/json')
    @InjectStoreToBody()
    @HttpCode(200)
    async addressCreate(
        @GetStore() store: StoreDto,
        @GetCustomer() shopifyCustomer: ShopifyCustomer,
        @Body() shopifyProxyCustomerAddressDto: ShopifyProxyCustomerAddressDto
    ): Promise<JsonResponse> {
        const response: JsonResponse = {
            message: '',
            data: {
                nextflow: AuthFlows.None,
                info: null,
                settings: store.storeIntegrations.shopify.settings
            }
        };

        if (shopifyCustomer) {
            const multipassToken = this.shopifyProxyService.getMultipassToken(
                store,
                shopifyCustomer
            );
            const accessToken =
                await this.shopifyStorefrontApiService.customerAccessTokenCreateWithMultipass(
                    store,
                    multipassToken
                );

            const createdCustomerAddress =
                await this.shopifyStorefrontApiService.createAddress(
                    store,
                    accessToken.data.accessToken,
                    shopifyProxyCustomerAddressDto
                );

            if (createdCustomerAddress.success && createdCustomerAddress.data) {
                this.logger.debug(
                    `addressCreate: shopifyCreateCustomerAddress success: ${
                        shopifyCustomer.email
                    } - ${JSON.stringify(createdCustomerAddress.data)}`
                );

                return response;
            }
        }

        this.logger.error(
            `addressCreate: shopifyCustomerAddress Failed: ${shopifyCustomer?.email}`
        );
        throw new HttpException(
            I18nContext.current().translate('exception.failed'),
            400
        );
    }

    @ApiOkResponse({ description: 'Address Update' })
    @Put('address-update')
    @Header('Content-Type', 'application/json')
    @InjectStoreToBody()
    @HttpCode(200)
    async addressUpdate(
        @GetStore() store: StoreDto,
        @GetCustomer() shopifyCustomer: ShopifyCustomer,
        @Body()
        shopifyProxyCustomerAddressUpdateDto: ShopifyProxyCustomerAddressUpdateDto
    ): Promise<JsonResponse> {
        const response: JsonResponse = {
            message: '',
            data: {
                nextflow: AuthFlows.None,
                info: null,
                settings: store.storeIntegrations.shopify.settings
            }
        };

        if (shopifyCustomer) {
            const multipassToken = this.shopifyProxyService.getMultipassToken(
                store,
                shopifyCustomer
            );
            const accessToken =
                await this.shopifyStorefrontApiService.customerAccessTokenCreateWithMultipass(
                    store,
                    multipassToken
                );

            const createdCustomerAddress =
                await this.shopifyStorefrontApiService.updateAddress(
                    store,
                    accessToken.data.accessToken,
                    shopifyProxyCustomerAddressUpdateDto
                );

            if (createdCustomerAddress.success && createdCustomerAddress.data) {
                this.logger.debug(
                    `addressUpdate: shopifyUpdateCustomerAddress success: ${shopifyCustomer.email}`
                );

                return response;
            }
        }

        this.logger.error(
            `addressUpdate: shopifyCustomerAddress Failed: ${shopifyCustomer?.email}`
        );
        throw new HttpException(
            I18nContext.current().translate('exception.failed'),
            400
        );
    }
}
