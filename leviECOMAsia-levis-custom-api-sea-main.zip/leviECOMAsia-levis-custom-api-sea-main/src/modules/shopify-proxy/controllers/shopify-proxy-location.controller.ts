import {
    Controller,
    Get,
    Header,
    HttpCode,
    HttpException,
    Logger,
    Query
} from '@nestjs/common';
import { ApiOkResponse, ApiTags } from '@nestjs/swagger';
import { JsonResponse } from 'src/interfaces/http/json-response.interface';
import { GetStore } from 'src/decorators/store.decorator';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { InjectStoreToBody } from 'src/decorators/inject-store/inject-store.decorator';
import { ShopifyProxyFindInLocationDto } from '../dto/shopify-proxy-find-in-location.dto';
import { ShopifyAdminApiService } from 'src/modules/shopify-admin-api/shopify-admin-api.service';
import { LiquidTemplateService } from 'src/modules/utils/liquid.service';
import { HelperService } from 'src/modules/utils/helper.service';
import { plainToClass } from 'class-transformer';
import { LocationTransformer } from '../transformers/shopify-location.transformer';
import { CacheHelper } from 'src/modules/utils/cache/cache-helper.service';
import { CustomLoggerService } from 'src/modules/utils/custom-logger.service';
import { StocksService } from 'src/entities/stocks/stocks.service';
import { In } from 'typeorm';

@Controller('shopify-proxy-location')
@ApiTags('Shopify Proxy App - Location')
export class ShopifyProxyLocationController {
    private logger: CustomLoggerService;
    constructor(
        private liquidService: LiquidTemplateService,
        private shopifyAdminApiService: ShopifyAdminApiService,
        private cacheHelper: CacheHelper,
        private customLoggerService: CustomLoggerService,
        private stocksService: StocksService
    ) {
        this.customLoggerService.setContext(
            ShopifyProxyLocationController.name
        );
        this.logger = this.customLoggerService;
    }

    @ApiOkResponse({ description: 'Find in stores' })
    @Get('product-find-in-stores')
    @Header('Content-Type', 'application/json')
    @InjectStoreToBody()
    @HttpCode(200)
    async productFindInStores(
        @GetStore() store: StoreDto,
        @Query() shopifyProxyFindInLocationDto: ShopifyProxyFindInLocationDto
    ): Promise<JsonResponse> {
        const response: JsonResponse = {
            message: '',
            data: {
                content: ''
            }
        };

        const productVariant = await this.cacheHelper.remember(
            `${store.id}:product_variant_${shopifyProxyFindInLocationDto.variantId}`,
            86400,
            async () => {
                return await this.shopifyAdminApiService.getVariant(
                    store,
                    shopifyProxyFindInLocationDto.variantId
                );
            }
        );

        if (!productVariant.success || !productVariant.data) {
            throw new HttpException(productVariant.message, 404);
        }

        const locations = await this.cacheHelper.remember(
            `${store.id}:locations`,
            86400,
            async () => {
                const locations =
                    await this.shopifyAdminApiService.findLocations(store);
                const storeCodeLocations = {};
                locations?.data?.forEach((location) => {
                    const storeCode = location.metafields.find(
                        (metafield) => metafield.key === 'store_code'
                    )?.value;
                    if (storeCode && location.address?.latitude && location.address?.longitude && !location.shipsInventory) {
                        storeCodeLocations[storeCode] = location;
                    }
                });

                return storeCodeLocations;
            }
        );
        const nearByLocations = [];
        const nearByLocationIds = [];

        if (locations) {

            const inventories = await this.stocksService.find({
                pc13: productVariant.data.sku,
                locationCode: In(Object.keys(locations)),
                storeId: store.id
            });

            if (inventories?.length) {
                for (const inventory of inventories) {
                    const location = locations[inventory.locationCode];

                    if (!location) {
                        continue;
                    }
                    const distance = HelperService.getDistance(
                        +shopifyProxyFindInLocationDto.lat,
                        +shopifyProxyFindInLocationDto.lng,
                        location.address.latitude,
                        location.address.longitude
                    );

                    this.logger.debug(
                        `Distance between ${location.name} is ${distance}`
                    );

                    // Make it as configurable
                    if (distance > 10 || location.shipsInventory) {
                        continue;
                    }

                    if (inventory.qty > 0) {
                        location.distance = distance;
                        location.quantity = inventory.qty;
                        const formatedLocation = plainToClass(
                            LocationTransformer,
                            location,
                            {
                                exposeUnsetFields: true,
                                strategy: 'excludeAll'
                            }
                        );

                        if (
                            !formatedLocation.address.formatted ||
                            !formatedLocation.storeCode
                        ) {
                            continue;
                        }

                        if (nearByLocationIds.includes(location.id)) {
                            continue;
                        }

                        nearByLocations.push(formatedLocation);
                        nearByLocationIds.push(location.id);
                    }
                }
            }

            this.logger.log(
                `Find in store request for store ${store.name} with variant ${shopifyProxyFindInLocationDto.variantId} and location ${shopifyProxyFindInLocationDto.lat},${shopifyProxyFindInLocationDto.lng} with ${nearByLocations.length} locations found`
            );
        }

        if (nearByLocations.length) {
            // sort by distance
            nearByLocations.sort((a, b) => a.distance - b.distance);

            // limit to 10
            nearByLocations.splice(10);
        }

        response.data.content = await this.liquidService.render(
            store,
            'find-in-store',
            {
                locations: nearByLocations
            }
        );

        return response;
    }
}
