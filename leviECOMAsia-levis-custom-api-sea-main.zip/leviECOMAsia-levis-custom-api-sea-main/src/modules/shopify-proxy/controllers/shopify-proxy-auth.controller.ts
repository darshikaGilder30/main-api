import {
    Body,
    Controller,
    Header,
    Headers,
    HttpCode,
    HttpException,
    Post
} from '@nestjs/common';
import { ApiOkResponse, ApiTags } from '@nestjs/swagger';
import { ShopifyProxyAuthValidateDto } from '../dto/shopify-proxy-auth-validate.dto';
import { ShopifyAdminApiService } from 'src/modules/shopify-admin-api/shopify-admin-api.service';
import { JsonResponse } from 'src/interfaces/http/json-response.interface';
import { ShopifyProxyAuthLoginDto } from '../dto/shopify-proxy-auth-login.dto';
import { AuthFlows } from 'src/enums/auth-flows.enum';
import { ShopifyStorefrontApiService } from 'src/modules/shopify-storefront-api/shopify-storefront-api.service';
import { ConfigService } from '@nestjs/config';
import { OtpServiceService } from 'src/modules/otp-service/otp-service.service';
import { ShopifyProxyVerifyOtpDto } from '../dto/shopify-proxy-auth-verify-otp.dto';
import { OtpService } from 'src/modules/otp/otp.service';
import { ShopifyProxyService } from '../shopify-proxy.service';
import { ShopifyProxyRegisterDto } from '../dto/shopify-proxy-auth-register.dto';
import { HelperService } from 'src/modules/utils/helper.service';
import { GetStore } from 'src/decorators/store.decorator';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { I18nContext, I18nValidationException } from 'nestjs-i18n';
import { ShopifyProxyUpdateDto } from '../dto/shopify-proxy-auth-update.dto';
import { ShopifyProxyAuthTermDto } from '../dto/shopify-proxy-auth-term.dto';
import { InjectStoreToBody } from 'src/decorators/inject-store/inject-store.decorator';
import { ShopifyProxyValidateReferralCodeDto } from '../dto/shopify-proxy-validate-referral-code.dto';
import { CacheHelper } from 'src/modules/utils/cache/cache-helper.service';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { CustomLoggerService } from 'src/modules/utils/custom-logger.service';
import { CrmLoyaltyFactory } from 'src/modules/crm-loyalty/crm-loyalty.factory';

@Controller('shopify-proxy-auth')
@ApiTags('Shopify Proxy App - Authentication')
export class ShopifyProxyAuthController {
    private logger: CustomLoggerService;
    constructor(
        private shopifyAdminApiService: ShopifyAdminApiService,
        private shopifyStorefrontApiService: ShopifyStorefrontApiService,
        private configService: ConfigService,
        private otpServiceService: OtpServiceService,
        private otpService: OtpService,
        private shopifyProxyService: ShopifyProxyService,
        private cacheHelper: CacheHelper,
        private eventEmitter: EventEmitter2,
        private customLoggerService: CustomLoggerService,
        private crmLoyaltyFactory: CrmLoyaltyFactory
    ) {
        this.customLoggerService.setContext(ShopifyProxyAuthController.name);
        this.logger = this.customLoggerService
    }

    @ApiOkResponse({ description: 'User Validated' })
    @Post('validate')
    @Header('Content-Type', 'application/json')
    @InjectStoreToBody()
    @HttpCode(200)
    async validate(
        @GetStore() store: StoreDto,
        @Body() shopifyProxyAuthValidateDto: ShopifyProxyAuthValidateDto
    ): Promise<JsonResponse> {
        const shopifyCustomer =
            await this.shopifyAdminApiService.searchCustomerByUsername(
                store,
                shopifyProxyAuthValidateDto.username
            );
        const response: JsonResponse = {
            message: '',
            data: {
                nextflow: AuthFlows.PASSWORD,
                info: null,
                settings: store.storeIntegrations.shopify.settings
            }
        };
        if (shopifyCustomer.success) {
            this.logger.debug(
                `validate: shopifyCustomer Success: ${shopifyProxyAuthValidateDto.username}`
            );
            if (!shopifyCustomer.data) {
                if (
                    (shopifyProxyAuthValidateDto.username.includes('@') &&
                        store.storeIntegrations.email?.active) ||
                    (!shopifyProxyAuthValidateDto.username.includes('@') &&
                        store.storeIntegrations.sms?.active)
                ) {
                    this.logger.debug(
                        `validate: shopifyCustomer Not Found: ${shopifyProxyAuthValidateDto.username} registration started with otp`
                    );
                    response.data.nextflow = AuthFlows.OTP;
                    const otp = await this.otpService.generateOtp(
                        shopifyProxyAuthValidateDto.username
                    );
                    await this.otpServiceService.send(
                        store,
                        shopifyProxyAuthValidateDto.username,
                        {
                            otp,
                            templateCode: 'otp'
                        }
                    );
                    if (
                        this.configService.get('environment') === 'development'
                    ) {
                        response.data.otp = otp;
                    }
                } else {
                    this.logger.debug(
                        `validate: shopifyCustomer Not Found: ${shopifyProxyAuthValidateDto.username} registration started wihtout otp`
                    );
                    response.data =
                        await this.shopifyProxyService.decideNextFlow(
                            store,
                            shopifyProxyAuthValidateDto.username,
                            shopifyCustomer.data
                        );

                    response.data.info = {
                        username: shopifyProxyAuthValidateDto.username
                    };

                    return response;
                }
            } else {
                this.logger.debug(
                    `validate: shopifyCustomer Found: ${shopifyProxyAuthValidateDto.username}`
                );

                if (HelperService.arrayMatch(shopifyCustomer.data?.tags, 'no_password') || shopifyCustomer.data?.state !== 'ENABLED') {
                    this.logger.debug(
                        `validate: shopifyCustomer Found: ${shopifyProxyAuthValidateDto.username} no_password tag found`
                    );
                    response.data.nextflow = AuthFlows.OTP;
                    const otp = await this.otpService.generateOtp(
                        shopifyProxyAuthValidateDto.username
                    );
                    await this.otpServiceService.send(
                        store,
                        shopifyProxyAuthValidateDto.username,
                        {
                            otp,
                            templateCode: 'otp'
                        }
                    );
                    if (
                        this.configService.get('environment') === 'development'
                    ) {
                        response.data.otp = otp;
                    }
                    response.data.info = {
                        username: shopifyProxyAuthValidateDto.username
                    };
                } else {
                    response.data.info = {
                        username: shopifyProxyAuthValidateDto.username
                    };
                }
            }

            return response;
        }

        this.logger.error(
            `validate: shopifyCustomer Failed: ${shopifyProxyAuthValidateDto.username}`
        );
        throw new HttpException(
            I18nContext.current().translate('exception.failed'),
            400
        );
    }

    @ApiOkResponse({ description: 'User Login' })
    @Post('login')
    @Header('Content-Type', 'application/json')
    @InjectStoreToBody()
    @HttpCode(200)
    async login(
        @GetStore() store: StoreDto,
        @Body() shopifyProxyAuthLoginDto: ShopifyProxyAuthLoginDto
    ): Promise<JsonResponse> {
        const shopifyCustomer =
            await this.shopifyAdminApiService.searchCustomerByUsername(
                store,
                shopifyProxyAuthLoginDto.username
            );

        if (shopifyCustomer.success && shopifyCustomer.data) {
            this.logger.debug(
                `login: shopifyCustomer Success: ${shopifyProxyAuthLoginDto.username}`
            );
            const shopifyCustomerToken =
                await this.shopifyStorefrontApiService.login(
                    store,
                    shopifyCustomer.data.email,
                    shopifyProxyAuthLoginDto.password
                );
            const response: JsonResponse = {
                message: '',
                data: {
                    nextflow: AuthFlows.Redirect,
                    info: null,
                    settings: store.storeIntegrations.shopify.settings
                }
            };
            if (shopifyCustomerToken.success) {
                if (!shopifyCustomerToken.data) {
                    this.logger.debug(
                        `login: shopifyCustomerToken Not Found: ${shopifyProxyAuthLoginDto.username}`
                    );
                    throw new HttpException(
                        I18nContext.current().translate('validation.invalid_credentials'),
                        401
                    );
                }

                response.data = await this.shopifyProxyService.decideNextFlow(
                    store,
                    shopifyProxyAuthLoginDto.username,
                    shopifyCustomer.data
                );

                return response;
            }
        }

        this.logger.error(
            `login: shopifyCustomer Failed: ${shopifyProxyAuthLoginDto.username}`
        );
        throw new HttpException(
            I18nContext.current().translate('exception.failed'),
            400
        );
    }

    @ApiOkResponse({ description: 'Otp Verified Successfully' })
    @Post('verify-otp')
    @Header('Content-Type', 'application/json')
    @HttpCode(200)
    @InjectStoreToBody()
    async verifyOtp(
        @GetStore() store: StoreDto,
        @Body() shopifyProxyVerifyOtpDto: ShopifyProxyVerifyOtpDto
    ): Promise<JsonResponse> {
        if (
            !(
                (shopifyProxyVerifyOtpDto.username.includes('@') &&
                    store.storeIntegrations.email?.active) ||
                (!shopifyProxyVerifyOtpDto.username.includes('@') &&
                    store.storeIntegrations.sms?.active)
            )
        ) {
            this.logger.error(
                `verifyOtp: Mode of communication not available: ${shopifyProxyVerifyOtpDto.username}`
            );
            throw new HttpException(
                I18nContext.current().translate('exception.access_denied'),
                403
            );
        }

        const shopifyCustomer =
            await this.shopifyAdminApiService.searchCustomerByUsername(
                store,
                shopifyProxyVerifyOtpDto.username
            );

        if (shopifyCustomer.success) {
            const tries: any = await this.cacheHelper.get(`${shopifyProxyVerifyOtpDto.username}-otp-tries`);

            if (tries && parseInt(tries) >= 3) {
                throw new HttpException(
                    I18nContext.current().translate('validation.max_attempts'),
                    401
                );
            }
            const response: JsonResponse = {
                message: '',
                data: {
                    nextflow: AuthFlows.REGISTER,
                    info: null,
                    settings: store.storeIntegrations.shopify.settings
                }
            };
            const otpVerified = await this.otpService.verifyOtp(
                shopifyProxyVerifyOtpDto.username,
                shopifyProxyVerifyOtpDto.otp,
                (tries ? parseInt(tries) : 0)
            );

            if (!otpVerified) {
                await this.cacheHelper.set(`${shopifyProxyVerifyOtpDto.username}-otp-tries`, (tries ? parseInt(tries) + 1 : 1), 120);
                throw new HttpException(
                    I18nContext.current().translate('validation.invalid_otp'),
                    401
                );
            }

            this.logger.debug(
                `verifyOtp: Otp Verified : ${shopifyProxyVerifyOtpDto.username}`
            );

            await this.cacheHelper.del(`${shopifyProxyVerifyOtpDto.username}-otp-tries`)

            response.data = await this.shopifyProxyService.decideNextFlow(
                store,
                shopifyProxyVerifyOtpDto.username,
                shopifyCustomer.data
            );

            return response;
        }

        this.logger.error(
            `verifyOtp: shopifyCustomer Failed: ${shopifyProxyVerifyOtpDto.username}`
        );
        throw new HttpException(
            I18nContext.current().translate('exception.failed'),
            400
        );
    }

    @ApiOkResponse({ description: 'Resend Otp' })
    @Post('resend-otp')
    @Header('Content-Type', 'application/json')
    @HttpCode(200)
    @InjectStoreToBody()
    async resendOtp(
        @GetStore() store: StoreDto,
        @Body() shopifyProxyAuthValidateDto: ShopifyProxyAuthValidateDto
    ): Promise<JsonResponse> {
        if (
            !(
                (shopifyProxyAuthValidateDto.username.includes('@') &&
                    store.storeIntegrations.email?.active) ||
                store.storeIntegrations.sms?.active
            )
        ) {
            this.logger.error(
                `resendOtp: Mode of communication not available: ${shopifyProxyAuthValidateDto.username}`
            );
            throw new HttpException(
                I18nContext.current().translate('exception.access_denied'),
                403
            );
        }

        const tries: any = await this.cacheHelper.get(`${shopifyProxyAuthValidateDto.username}-otp-tries`);

        if (tries && parseInt(tries) >= 3) {
            throw new HttpException(
                I18nContext.current().translate('validation.max_attempts'),
                401
            );
        }

        const shopifyCustomer =
            await this.shopifyAdminApiService.searchCustomerByUsername(
                store,
                shopifyProxyAuthValidateDto.username
            );
        const response: JsonResponse = {
            message: '',
            data: {
                nextflow: AuthFlows.OTP,
                info: null,
                settings: store.storeIntegrations.shopify.settings
            }
        };
        if (shopifyCustomer.success) {

            this.logger.debug(
                `resendOtp: shopifyCustomer Success: ${shopifyProxyAuthValidateDto.username}`
            );
            const otp = await this.otpService.generateOtp(
                shopifyProxyAuthValidateDto.username,
                true
            );
            await this.otpServiceService.send(
                store,
                shopifyProxyAuthValidateDto.username,
                { otp, templateCode: 'otp'}
            );
            if (this.configService.get('environment') === 'development') {
                response.data.otp = otp;
            }

            if (shopifyCustomer.data) {
                response.data.info = {
                    username: shopifyProxyAuthValidateDto.username
                }
            }

            await this.cacheHelper.set(`${shopifyProxyAuthValidateDto.username}-otp-tries`, (tries ? parseInt(tries) + 1 : 1), 120);

            return response;
        }

        this.logger.error(
            `resendOtp: shopifyCustomer Failed: ${shopifyProxyAuthValidateDto.username}`
        );
        throw new HttpException(
            I18nContext.current().translate('exception.failed'),
            400
        );
    }

    @ApiOkResponse({ description: 'User Registered' })
    @Post('register')
    @Header('Content-Type', 'application/json')
    @HttpCode(201)
    @InjectStoreToBody()
    async register(
        @GetStore() store: StoreDto,
        @Body() shopifyProxyRegisterDto: ShopifyProxyRegisterDto,
        @Headers('referer') referer: string
    ): Promise<JsonResponse> {
        const tokenData = await this.shopifyProxyService.getTokenInfo(
            shopifyProxyRegisterDto.token
        );

        if (!tokenData) {
            this.logger.error(
                `register: Invalid Token: ${shopifyProxyRegisterDto.email}`
            );
            throw new HttpException(
                I18nContext.current().translate('validation.invalid_token'),
                401
            );
        }
        
        if (referer?.includes('possource')) {
            shopifyProxyRegisterDto.posSource = HelperService.getQueryParam(
                referer,
                'possource'
            );
        }

        let { membershipId, shopifyCustomer, username } = tokenData;
        if (username.includes('@')) {
            shopifyProxyRegisterDto.email = username;
            shopifyProxyRegisterDto.verifiedSource = 'Email';
        } else {
            shopifyProxyRegisterDto.phone = username;
            shopifyProxyRegisterDto.verifiedSource = 'Phone';
        }

        // Check if customer already exists in Shopify after caching user data in token
        if (!shopifyCustomer) {
            const shopifyCustomerQuery =
                await this.shopifyAdminApiService.searchCustomerByUsername(
                    store,
                    username
                );

            if (shopifyCustomerQuery.success && shopifyCustomerQuery.data) {
                this.logger.debug(
                    `register: shopifyCustomer exists check Success: ${username}`
                );

                shopifyCustomer = shopifyCustomerQuery.data;
            }
        }

        let createdShopifyCustomer = null;
        if (!shopifyCustomer) {
            // Validate Email exists if verified source is Phone
            if (shopifyProxyRegisterDto.verifiedSource === 'Phone') {
                const shopifyCustomerByEmail = await this.shopifyProxyService.checkEmailExists(
                    store,
                    shopifyProxyRegisterDto.email
                );

                if (shopifyCustomerByEmail) {
                    throw new I18nValidationException(
                        [
                            {
                                property: 'email',
                                constraints: {
                                    isEmail: 'validation.already_taken'
                                }
                            }
                        ]
                    );
                }
            }
            createdShopifyCustomer =
                await this.shopifyStorefrontApiService.createCustomer(
                    store,
                    shopifyProxyRegisterDto
                );
            if (!createdShopifyCustomer.success || !createdShopifyCustomer.data) {
                this.logger.warn(
                    `register: shopifyCreateCustomer Failed: ${shopifyProxyRegisterDto.email} error: ${createdShopifyCustomer.message}`
                );
                throw new HttpException(
                    createdShopifyCustomer.message ||
                        I18nContext.current().translate('exception.failed'),
                    400
                );
            } 
        }

        const loyaltyService = this.crmLoyaltyFactory.getIntegration(store);

        if (loyaltyService) {
            if (!membershipId) {
                const loyalty = await loyaltyService.memberRegister(
                    store,
                    shopifyProxyRegisterDto
                );
    
                membershipId = loyalty
            } else {
                shopifyProxyRegisterDto.membershipId = membershipId;
                await loyaltyService.memberUpdate(
                    store,
                    shopifyProxyRegisterDto
                );
            }
        }
        shopifyProxyRegisterDto.membershipId = membershipId;
        shopifyProxyRegisterDto.terms = true;

        if (shopifyCustomer) {
            const multipassToken = this.shopifyProxyService.getMultipassToken(
                store,
                shopifyCustomer
            );
            const accessToken =
                await this.shopifyStorefrontApiService.customerAccessTokenCreateWithMultipass(
                    store,
                    multipassToken
                );

            createdShopifyCustomer =
                await this.shopifyStorefrontApiService.customerUpdatePassword(
                    store,
                    accessToken.data.accessToken,
                    shopifyProxyRegisterDto.password
                );

            const updateCustomer =
                await this.shopifyProxyService.updateShopifyCustomer(
                    store,
                    shopifyCustomer,
                    shopifyProxyRegisterDto
                );

            if (updateCustomer.success && updateCustomer.data) {
                this.logger.debug(
                    `register: shopifyUpdateCustomer success: ${shopifyProxyRegisterDto.email}`
                );
            } else {
                this.logger.error(
                    `register: shopifyUpdateCustomer Failed: ${shopifyProxyRegisterDto.email}`
                );
                throw new HttpException(
                    updateCustomer.message ||
                        I18nContext.current().translate('exception.failed'),
                    400
                );
            }

            this.logger.debug(
                `register: shopifyUpdateCustomerPassword success: ${shopifyProxyRegisterDto.email}`
            );
        }

        if (createdShopifyCustomer.success && createdShopifyCustomer.data) {
            this.logger.debug(
                `register: shopifyCreateCustomer success: ${shopifyProxyRegisterDto.email}`
            );

            if (!shopifyCustomer) {
                shopifyCustomer = createdShopifyCustomer.data;
            }
            delete shopifyProxyRegisterDto.referralCode;
            const updatedShopifyCustomer =
                await this.shopifyProxyService.updateShopifyCustomerOtherInfo(
                    store,
                    createdShopifyCustomer.data.id,
                    shopifyProxyRegisterDto
                );
            if (updatedShopifyCustomer.success && updatedShopifyCustomer.data) {
                // trigger customer create event
                this.eventEmitter.emit('customer.created', {
                    store,
                    data: {
                        customerId: shopifyCustomer.id.replace('gid://shopify/Customer/', ''),
                    }
                });
                const response: JsonResponse = {
                    message: '',
                    data: {
                        nextflow: AuthFlows.Redirect,
                        info: null,
                        url: null,
                        settings: store.storeIntegrations.shopify.settings
                    }
                };

                response.data.url = await this.shopifyProxyService.getLoginUrl(
                    store,
                    shopifyCustomer
                );

                this.shopifyProxyService.deleteToken(
                    shopifyProxyRegisterDto.token,
                    'register'
                )

                return response;
            }
        }

        this.logger.error(
            `register: shopifyCreateCustomer Failed: ${shopifyProxyRegisterDto.email} error: ${createdShopifyCustomer.message}`
        );
        throw new HttpException(
            createdShopifyCustomer.message ||
                I18nContext.current().translate('exception.failed'),
            400
        );
    }

    @ApiOkResponse({ description: 'User Update' })
    @Post('update')
    @Header('Content-Type', 'application/json')
    @HttpCode(200)
    @InjectStoreToBody()
    async update(
        @GetStore() store: StoreDto,
        @Body() shopifyProxyUpdateDto: ShopifyProxyUpdateDto
    ): Promise<JsonResponse> {
        const tokenData = await this.shopifyProxyService.getTokenInfo(
            shopifyProxyUpdateDto.token,
            'update'
        );

        if (!tokenData) {
            this.logger.error(
                `update: Invalid Token: ${shopifyProxyUpdateDto.email}`
            );
            throw new HttpException(
                I18nContext.current().translate('validation.invalid_token'),
                401
            );
        }

        let { membershipId, shopifyCustomer, username } = tokenData;
        if (username.includes('@')) {
            shopifyProxyUpdateDto.email = username;
            shopifyProxyUpdateDto.verifiedSource = 'Email';
        } else {
            shopifyProxyUpdateDto.phone = username;
            shopifyProxyUpdateDto.verifiedSource = 'Phone';
        }
        shopifyProxyUpdateDto.membershipId = membershipId;
        shopifyProxyUpdateDto.terms = true;
         // refresh customer data
         if (shopifyCustomer) {
            const shopifyCustomerQuery =
                await this.shopifyAdminApiService.getCustomer(
                    store,
                    shopifyCustomer.id
                );

            if (shopifyCustomerQuery.success && shopifyCustomerQuery.data) {
                this.logger.debug(
                    `update: refresh shopifyCustomer Success: ${username}`
                );

                shopifyCustomer = shopifyCustomerQuery.data;
            }
        }
        const response: JsonResponse = {
            message: '',
            data: {
                nextflow: AuthFlows.Redirect,
                info: null,
                url: null,
                settings: store.storeIntegrations.shopify.settings
            }
        };

        const loyaltyService = this.crmLoyaltyFactory.getIntegration(store);
        if (loyaltyService) {
             const loyalty = await loyaltyService.memberUpdate(
                store,
                shopifyProxyUpdateDto
            );
            membershipId = loyalty;
        }

        const updateCustomer =
            await this.shopifyProxyService.updateShopifyCustomer(
                store,
                shopifyCustomer,
                shopifyProxyUpdateDto
            );

        if (updateCustomer.success && updateCustomer.data) {
            this.logger.debug(
                `update: shopifyUpdateCustomer success: ${shopifyProxyUpdateDto.email}`
            );
        } else {
            this.logger.error(
                `update: shopifyUpdateCustomer Failed: ${shopifyProxyUpdateDto.email}`
            );
            throw new HttpException(
                updateCustomer.message ||
                    I18nContext.current().translate('exception.failed'),
                400
            );
        }

        if (HelperService.arrayMatch(shopifyCustomer?.tags, 'no_password') && shopifyProxyUpdateDto.password) {
            const multipassToken = this.shopifyProxyService.getMultipassToken(
                store,
                shopifyCustomer
            );
            const accessToken =
                await this.shopifyStorefrontApiService.customerAccessTokenCreateWithMultipass(
                    store,
                    multipassToken
                );

            const passwordUpdate =
                await this.shopifyStorefrontApiService.customerUpdatePassword(
                    store,
                    accessToken.data.accessToken,
                    shopifyProxyUpdateDto.password
                );

            if (passwordUpdate.success && passwordUpdate.data) {
                this.logger.debug(
                    `register: shopifyUpdateCustomer success: ${shopifyProxyUpdateDto.email}`
                );
            } else {
                this.logger.error(
                    `register: shopifyUpdateCustomer Failed: ${shopifyProxyUpdateDto.email}`
                );
                throw new HttpException(
                    updateCustomer.message ||
                        I18nContext.current().translate('exception.failed'),
                    400
                );
            }

            this.logger.debug(
                `register: shopifyUpdateCustomerPassword success: ${shopifyProxyUpdateDto.email}`
            );
        }

        const updatedShopifyCustomer =
        await this.shopifyProxyService.updateShopifyCustomerOtherInfo(
            store,
            shopifyCustomer.id,
            shopifyProxyUpdateDto
        );

        if (updatedShopifyCustomer.success && updatedShopifyCustomer.data) {
            this.logger.debug(
                `update: shopifyUpdateCustomer success: ${shopifyProxyUpdateDto.email}`
            );

            response.data.url = await this.shopifyProxyService.getLoginUrl(
                store,
                shopifyCustomer
            );

            this.shopifyProxyService.deleteToken(
                shopifyProxyUpdateDto.token,
                'update'
            )

            return response;
        }

        this.logger.error(
            `update: shopifyUpdateCustomer Failed: ${shopifyProxyUpdateDto.email} error: ${updatedShopifyCustomer.message}`
        );
        throw new HttpException(
            updatedShopifyCustomer.message ||
                I18nContext.current().translate('exception.failed'),
            400
        );
    }

    @ApiOkResponse({ description: 'User Terms and condition update' })
    @Post('terms')
    @Header('Content-Type', 'application/json')
    @HttpCode(200)
    async terms(
        @GetStore() store: StoreDto,
        @Body() shopifyProxyAuthTermDto: ShopifyProxyAuthTermDto
    ): Promise<JsonResponse> {
        const tokenData = await this.shopifyProxyService.getTokenInfo(
            shopifyProxyAuthTermDto.token,
            'terms'
        );

        if (!tokenData) {
            this.logger.error(
                `terms: Invalid Token: ${shopifyProxyAuthTermDto.token}`
            );
            throw new HttpException(
                I18nContext.current().translate('validation.invalid_token'),
                401
            );
        }

        const { membershipId, shopifyCustomer, username } = tokenData;
        const response: JsonResponse = {
            message: '',
            data: {
                nextflow: AuthFlows.Redirect,
                info: null,
                url: null,
                settings: store.storeIntegrations.shopify.settings
            }
        };

        const updatedShopifyCustomer =
            await this.shopifyProxyService.updateShopifyCustomerOtherInfo(
                store,
                shopifyCustomer.id,
                {
                    terms: true
                }
            );

        if (updatedShopifyCustomer.success && updatedShopifyCustomer.data) {
            this.logger.debug(
                `terms: shopifyUpdateCustomer success: ${shopifyCustomer.email}`
            );

            response.data.url = await this.shopifyProxyService.getLoginUrl(
                store,
                shopifyCustomer
            );

            this.shopifyProxyService.deleteToken(
                updatedShopifyCustomer.token,
                'terms'
            )

            return response;
        }

        this.logger.error(
            `terms: shopifyUpdateCustomer Failed: ${shopifyCustomer.email}`
        );
        throw new HttpException(
            updatedShopifyCustomer.message ||
                I18nContext.current().translate('exception.failed'),
            400
        );
    }

    @ApiOkResponse({ description: 'Forgot password' })
    @Post('forgot-password')
    @Header('Content-Type', 'application/json')
    @HttpCode(200)
    @InjectStoreToBody()
    async forgotPassword(
        @GetStore() store: StoreDto,
        @Body() shopifyProxyAuthValidateDto: ShopifyProxyAuthValidateDto
    ) {
        if (!shopifyProxyAuthValidateDto.username.includes('@')) {
            const shopifyCustomer =
                await this.shopifyAdminApiService.searchCustomerByUsername(
                    store,
                    shopifyProxyAuthValidateDto.username
                );

            if (!shopifyCustomer.success || !shopifyCustomer.data) {
                throw new HttpException(
                    I18nContext.current().translate('validation.customer_not_found'),
                    400
                );
            }

            shopifyProxyAuthValidateDto.username = shopifyCustomer.data.email;
        }

        const recoverPassword =
            await this.shopifyStorefrontApiService.forgotPassword(
                store,
                shopifyProxyAuthValidateDto.username
            );

        if (recoverPassword.success) {
            const response: JsonResponse = {
                message: '',
                data: {
                    nextflow: null,
                    info: null,
                    url: null,
                    settings: store.storeIntegrations.shopify.settings
                }
            };
            
            if (recoverPassword.data?.customerUserErrors?.length > 0) {
                throw new HttpException(
                    recoverPassword.data?.customerUserErrors[0]?.message,
                    400
                );
            }
            this.logger.debug(
                `forgotPassword: recoverPassword success: ${shopifyProxyAuthValidateDto.username}`
            );

            response.message = I18nContext.current().translate('validation.password_reset');

            return response;
        }

        this.logger.error(
            `forgotPassword: recoverPassword Failed: ${shopifyProxyAuthValidateDto.username}`
        );

        throw new HttpException(
            recoverPassword.message ||
                I18nContext.current().translate('exception.failed'),
            400
        );
    }

    @ApiOkResponse({ description: 'Validate Referral Code' })
    @Post('validate-referral-code')
    @Header('Content-Type', 'application/json')
    @InjectStoreToBody()
    @HttpCode(200)
    async referralCodeValidate(
        @GetStore() store: StoreDto,
        @Body()
        shopifyProxyValidateReferralCodeDto: ShopifyProxyValidateReferralCodeDto
    ): Promise<JsonResponse> {
        return {
            message: '',
            data: {
                nextflow: AuthFlows.None,
                info: null,
                url: null,
                settings: store.storeIntegrations.shopify.settings
            }
        };
    }
}