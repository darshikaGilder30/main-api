import {
    Body,
    Controller,
    Header,
    HttpCode,
    HttpException,
    Logger,
    Post,
    UseInterceptors
} from '@nestjs/common';
import { ApiOkResponse, ApiTags } from '@nestjs/swagger';
import { ShopifyProxyAuthValidateDto } from '../dto/shopify-proxy-auth-validate.dto';
import { JsonResponse } from 'src/interfaces/http/json-response.interface';
import { ConfigService } from '@nestjs/config';
import { OtpServiceService } from 'src/modules/otp-service/otp-service.service';
import { ShopifyProxyVerifyOtpDto } from '../dto/shopify-proxy-auth-verify-otp.dto';
import { OtpService } from 'src/modules/otp/otp.service';
import { GetStore } from 'src/decorators/store.decorator';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { I18nContext } from 'nestjs-i18n';
import { InjectStoreToBody } from 'src/decorators/inject-store/inject-store.decorator';
import { CacheHelper } from 'src/modules/utils/cache/cache-helper.service';
import { CustomLoggerService } from 'src/modules/utils/custom-logger.service';
import { UsernameSanitizeInterceptor } from 'src/interceptors/username.interceptors';

@Controller('shopify-proxy-otp')
@ApiTags('Shopify Proxy App - Otp')
export class ShopifyProxyOtpController {
    private logger: CustomLoggerService;
    constructor(
        private configService: ConfigService,
        private otpServiceService: OtpServiceService,
        private otpService: OtpService,
        private cacheHelper: CacheHelper,
        private customLoggerService: CustomLoggerService
    ) {
        this.customLoggerService.setContext(ShopifyProxyOtpController.name);
        this.logger = this.customLoggerService
     }

    @ApiOkResponse({ description: 'Otp Verified Successfully' })
    @Post('verify-otp')
    @Header('Content-Type', 'application/json')
    @HttpCode(200)
    @InjectStoreToBody()
    @UseInterceptors(UsernameSanitizeInterceptor)
    async verifyOtp(
        @GetStore() store: StoreDto,
        @Body() shopifyProxyVerifyOtpDto: ShopifyProxyVerifyOtpDto
    ): Promise<JsonResponse> {
        if (!store.storeIntegrations.sms?.active) {
            this.logger.error(
                `verifyOtp: Mode of communication not available: ${shopifyProxyVerifyOtpDto.username}`
            );
            throw new HttpException(
                I18nContext.current().translate('exception.access_denied'),
                403
            );
        }

        const tries: any = await this.cacheHelper.get(`${shopifyProxyVerifyOtpDto.username}-general-otp-tries`);

        if (tries && parseInt(tries) >= 3) {
            throw new HttpException(
                I18nContext.current().translate('validation.max_attempts'),
                401
            );
        }
        const response: JsonResponse = {
            message: '',
            data: {}
        };
        const otpVerified = await this.otpService.verifyOtp(
            shopifyProxyVerifyOtpDto.username,
            shopifyProxyVerifyOtpDto.otp,
            (tries ? parseInt(tries) : 0)
        );

        if (!otpVerified) {
            await this.cacheHelper.set(`${shopifyProxyVerifyOtpDto.username}-general-otp-tries`, (tries ? parseInt(tries) + 1 : 1), 120);
            throw new HttpException(
                I18nContext.current().translate('validation.invalid_otp'),
                401
            );
        }

        this.logger.debug(
            `verifyOtp: Otp Verified : ${shopifyProxyVerifyOtpDto.username}`
        );

        await this.cacheHelper.del(`${shopifyProxyVerifyOtpDto.username}-general-otp-tries`)

        return response;
    }

    @ApiOkResponse({ description: 'Send Otp' })
    @Post('send-otp')
    @Header('Content-Type', 'application/json')
    @HttpCode(200)
    @InjectStoreToBody()
    @UseInterceptors(UsernameSanitizeInterceptor)
    async sendOtp(
        @GetStore() store: StoreDto,
        @Body() shopifyProxyAuthValidateDto: ShopifyProxyAuthValidateDto
    ): Promise<JsonResponse> {
        if (!(store.storeIntegrations.sms?.active)) {
            this.logger.error(
                `resendOtp: Mode of communication not available: ${shopifyProxyAuthValidateDto.username}`
            );
            throw new HttpException(
                I18nContext.current().translate('exception.access_denied'),
                403
            );
        }

        if (store.storeIntegrations.shopify.settings.countryCode !== 'ID') {
            this.logger.error(
                `resendOtp: Country Code not supported: ${shopifyProxyAuthValidateDto.username}`
            );
            throw new HttpException(
                I18nContext.current().translate('exception.access_denied'),
                403
            );
        }

        const response: JsonResponse = {
            message: '',
            data: {
            }
        };

        const tries: any = await this.cacheHelper.get(`${shopifyProxyAuthValidateDto.username}-general-otp-tries`);

        if (tries && parseInt(tries) >= 3) {
            throw new HttpException(
                I18nContext.current().translate('validation.max_attempts'),
                401
            );
        }

        this.logger.debug(
            `sendOtp: shopifyCustomer Success: ${shopifyProxyAuthValidateDto.username}`
        );
        const otp = await this.otpService.generateOtp(
            shopifyProxyAuthValidateDto.username,
            true
        );
        await this.otpServiceService.send(
            store,
            shopifyProxyAuthValidateDto.username,
            { otp, templateCode: 'cod_otp'}
        );

        if (this.configService.get('environment') === 'development') {
            response.data.otp = otp;
        }

        await this.cacheHelper.set(`${shopifyProxyAuthValidateDto.username}-general-otp-tries`, (tries ? parseInt(tries) + 1 : 1), 120);

        return response;
    }
}
