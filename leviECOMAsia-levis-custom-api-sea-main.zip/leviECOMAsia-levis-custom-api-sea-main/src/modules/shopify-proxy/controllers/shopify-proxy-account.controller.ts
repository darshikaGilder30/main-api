import {
    Controller,
    Get,
    Header,
    HttpCode,
    HttpException,
    Param,
    Post
} from '@nestjs/common';
import { ApiOkResponse, ApiTags } from '@nestjs/swagger';
import { MuleService } from 'src/modules/mule/mule.service';
import { GetStore } from 'src/decorators/store.decorator';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { I18nContext } from 'nestjs-i18n';
import { GetCustomer } from 'src/decorators/customer.decorator';
import { ShopifyCustomer } from 'src/modules/shopify-admin-api/interfaces/shopify-customer.interface';
import { LiquidTemplateService } from 'src/modules/utils/liquid.service';
import { plainToClass } from 'class-transformer';
import { AscentiesCardInfoTransformer } from '../transformers/ascentis-card-info.transformer';
import { ShopifyCustomMeta } from 'src/enums/shopify-custom-meta.enum';
import { AscentiesTransactionHistoryTransformer } from '../transformers/ascentis-transaction-history.transformer';
import { JsonResponse } from 'src/interfaces/http/json-response.interface';
import * as moment from 'moment-timezone';
import { ShopifyAdminApiService } from 'src/modules/shopify-admin-api/shopify-admin-api.service';
import { ShopifyProxyService } from '../shopify-proxy.service';
import { AscentiesVoucherListTransformer } from '../transformers/ascentis-voucher-list.transformer';
import { CustomLoggerService } from 'src/modules/utils/custom-logger.service';
import { StampsApiService } from 'src/modules/stamps/stamps-api.service';
import { VoucherTypes } from '../enums/ascentis-voucher.enum';

@Controller('shopify-proxy-account')
@ApiTags('Shopify Proxy App - Account')
export class ShopifyProxyAccountController {
    private logger: CustomLoggerService;
    constructor(
        private muleService: MuleService,
        private liquidService: LiquidTemplateService,
        private shopifyAdminApiService: ShopifyAdminApiService,
        private shopifyProxyService: ShopifyProxyService,
        private customLoggerService: CustomLoggerService,
        private stampsApiService: StampsApiService
    ) {
        moment.tz.setDefault('Etc/GMT+0');
        this.customLoggerService.setContext(ShopifyProxyAccountController.name);
        this.logger = this.customLoggerService;
    }

    @ApiOkResponse({ description: 'Info' })
    @Get('info')
    @Header('Content-Type', 'application/json')
    @HttpCode(200)
    async info(
        @GetStore() store: StoreDto,
        @GetCustomer() shopifyCustomer: ShopifyCustomer
    ): Promise<JsonResponse> {
        const response: JsonResponse = {
            message: '',
            data: {
                info: this.shopifyProxyService.getUserInfo(
                    store,
                    shopifyCustomer
                )
            }
        };

        return response;
    }

    @ApiOkResponse({ description: 'Rewards' })
    @Get('rewards')
    @Header('Content-Type', 'application/json')
    @HttpCode(200)
    async rewards(
        @GetStore() store: StoreDto,
        @GetCustomer() shopifyCustomer: ShopifyCustomer
    ): Promise<JsonResponse> {
        const response: JsonResponse = {
            message: '',
            data: {
                content: ''
            }
        };
        const cardNo = shopifyCustomer.metafields.find(
            (metafield) => metafield.key === ShopifyCustomMeta.LoyaltyCardNo
        ).value;
        const muleResponse = await this.muleService.cardEnquiry(store, cardNo);

        if (muleResponse.success && muleResponse.data) {
            const cardInfo = plainToClass(
                AscentiesCardInfoTransformer,
                muleResponse.data,
                {
                    exposeUnsetFields: true,
                    strategy: 'excludeAll'
                }
            );

            const template = await this.liquidService.render(store, 'rewards', {
                cardInfo
            });
            response.data.content = template;

            await this.shopifyAdminApiService.updateCustomerMetafields(
                store,
                shopifyCustomer,
                {
                    membershipTierCode: cardInfo.tierCode,
                    loyaltyPoints: cardInfo.totalPointsBalance
                }
            );
        } else if (!muleResponse.success) {
            this.logger.error(
                `Failed to get transaction history for cardNo: ${cardNo}`
            );

            throw new HttpException(
                I18nContext.current().translate('exception.ascentis_error'),
                400
            );
        }

        return response;
    }

    @ApiOkResponse({ description: 'Vouchers' })
    @Get('vouchers')
    @Header('Content-Type', 'application/json')
    @HttpCode(200)
    async vouchers(
        @GetStore() store: StoreDto,
        @GetCustomer() shopifyCustomer: ShopifyCustomer
    ): Promise<JsonResponse> {
        const response: JsonResponse = {
            message: '',
            data: {
                content: ''
            }
        };
        const cardNo = shopifyCustomer.metafields.find(
            (metafield) => metafield.key === ShopifyCustomMeta.LoyaltyCardNo
        ).value;
        const muleResponse = await this.muleService.vouchers(store, cardNo);

        if (muleResponse.success && muleResponse.data) {
            const voucherList = plainToClass(
                AscentiesVoucherListTransformer,
                muleResponse.data,
                {
                    exposeUnsetFields: true,
                    strategy: 'excludeAll'
                }
            );
           voucherList.activeVouchers = voucherList.activeVouchers.filter(
               (voucher) => voucher.type !== VoucherTypes.TOKEN
           );

            const template = await this.liquidService.render(
                store,
                'vouchers',
                {
                    vouchers: voucherList.activeVouchers
                }
            );

            response.data.content = template;
        } else if (!muleResponse.success) {
            this.logger.error(
                `Failed to get transaction history for cardNo: ${cardNo}`
            );

            throw new HttpException(
                I18nContext.current().translate('exception.ascentis_error'),
                400
            );
        }

        return response;
    }

    @ApiOkResponse({ description: 'Transaction History' })
    @Get('transaction-histories')
    @Header('Content-Type', 'application/json')
    @HttpCode(200)
    async transactionHistories(
        @GetStore() store: StoreDto,
        @GetCustomer() shopifyCustomer: ShopifyCustomer
    ): Promise<JsonResponse> {
        const response: JsonResponse = {
            message: '',
            data: {
                content: ''
            }
        };
        const cardNo = shopifyCustomer.metafields.find(
            (metafield) => metafield.key === ShopifyCustomMeta.LoyaltyCardNo
        ).value;
        const transactionMuleResponse =
            await this.muleService.transactionHistory(store, cardNo);

        const cardMuleResponse = await this.muleService.cardEnquiry(
            store,
            cardNo
        );

        if (
            cardMuleResponse.success &&
            cardMuleResponse.data &&
            transactionMuleResponse.success &&
            transactionMuleResponse.data
        ) {
            const transactionHistories = [];
            for (const transactionHistory of transactionMuleResponse.data
                ?.TransactionLists) {
                transactionHistories.push(
                    plainToClass(
                        AscentiesTransactionHistoryTransformer,
                        transactionHistory,
                        {
                            exposeUnsetFields: true,
                            strategy: 'excludeAll'
                        }
                    )
                );
            }

            const cardInfo = plainToClass(
                AscentiesCardInfoTransformer,
                cardMuleResponse.data,
                {
                    exposeUnsetFields: true,
                    strategy: 'excludeAll'
                }
            );

            const template = await this.liquidService.render(
                store,
                'transaction-histories',
                {
                    transactionHistories,
                    cardInfo
                }
            );

            response.data.content = template;
        } else if (
            !transactionMuleResponse.success ||
            !cardMuleResponse.success
        ) {
            this.logger.error(
                `Failed to get transaction history for cardNo: ${cardNo}`
            );

            throw new HttpException(
                I18nContext.current().translate('exception.ascentis_error'),
                400
            );
        }

        return response;
    }

    @ApiOkResponse({ description: 'Purchase History' })
    @Get('purchase-histories')
    @Header('Content-Type', 'application/json')
    @HttpCode(200)
    async purchaseHistories(
        @GetStore() store: StoreDto,
        @GetCustomer() shopifyCustomer: ShopifyCustomer
    ): Promise<JsonResponse> {
        const response: JsonResponse = {
            message: '',
            data: {
                content: ''
            }
        };
        const cardNo = shopifyCustomer.metafields.find(
            (metafield) => metafield.key === ShopifyCustomMeta.LoyaltyCardNo
        ).value;

        const transactionMuleResponse =
            await this.muleService.transactionHistory(store, cardNo, true);

        if (transactionMuleResponse.success && transactionMuleResponse.data) {
            const transactionHistories = [];
            for (const transactionHistory of transactionMuleResponse.data
                .TransactionLists) {
                transactionHistories.push(
                    plainToClass(
                        AscentiesTransactionHistoryTransformer,
                        transactionHistory,
                        {
                            exposeUnsetFields: true,
                            strategy: 'excludeAll'
                        }
                    )
                );
            }

            const template = await this.liquidService.render(
                store,
                'purchase-histories',
                {
                    transactionHistories
                }
            );

            response.data.content = template;
        } else if (!transactionMuleResponse.success) {
            this.logger.error(
                `Failed to get transaction history for cardNo: ${cardNo}`
            );
            throw new HttpException(
                I18nContext.current().translate('exception.ascentis_error'),
                400
            );
        }

        return response;
    }

    @ApiOkResponse({ description: 'Create your voucher' })
    @Post('create-voucher/:voucherId')
    @Header('Content-Type', 'application/json')
    @HttpCode(200)
    async createVoucher(
        @GetStore() store: StoreDto,
        @GetCustomer() shopifyCustomer: ShopifyCustomer,
        @Param('voucherId') voucherId: number
    ): Promise<JsonResponse> {
        const response: JsonResponse = {
            message: '',
            data: {}
        };
        voucherId = parseInt(voucherId.toString());
        const membershipId = shopifyCustomer.metafields.find(
            (metafield) => metafield.key === ShopifyCustomMeta.MembershipId
        ).value;

        if (!membershipId) {
            throw new HttpException(
                I18nContext.current().translate('exception.ascentis_error'),
                400
            );
        }

        const rewards = await this.stampsApiService.vouchers(
            store,
            membershipId,
            '',
            true
        );

        if (rewards.success && rewards.data) {
            for await (const reward of rewards.data.rewards) {
                if (
                    reward.type === 4 &&
                    reward.id == voucherId &&
                    reward.membership ===
                        shopifyCustomer.metafields.find(
                            (metafield) =>
                                metafield.key ===
                                ShopifyCustomMeta.MembershipTierCode
                        )?.value
                ) {
                    const stampsResponse =
                        await this.stampsApiService.rewardRedemption(
                            store,
                            membershipId,
                            voucherId
                        );
                    if (stampsResponse.success) {
                        this.logger.log(
                            `Voucher created for membershipId: ${membershipId}`
                        );

                        response.message = I18nContext.current().translate(
                            'message.voucher_created_successfully'
                        );

                        return response;
                    } else {
                        this.logger.error(
                            `Failed to create voucher for membershipId: ${membershipId} - ${stampsResponse.message}`
                        );
                        throw new HttpException(
                            response.message ||
                                I18nContext.current().translate(
                                    'exception.ascentis_error'
                                ),
                            400
                        );
                    }
                }
            }
        } else if (!rewards.success) {
            this.logger.error(
                `Failed to get transaction history for membershipId: ${membershipId}`
            );
        }

        throw new HttpException(
            I18nContext.current().translate('exception.ascentis_error'),
            400
        );
    }
}
