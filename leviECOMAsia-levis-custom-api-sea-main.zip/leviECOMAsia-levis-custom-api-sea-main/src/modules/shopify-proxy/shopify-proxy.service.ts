import { HttpException, Inject, Injectable } from '@nestjs/common';
import { EncryptionService } from '../utils/encryption.service';
import * as moment from 'moment-timezone';
import { ShopifyCustomer } from '../shopify-admin-api/interfaces/shopify-customer.interface';
import { AuthFlows } from 'src/enums/auth-flows.enum';
import { MuleService } from '../mule/mule.service';
import { plainToInstance } from 'class-transformer';
import { AuthUserInfoTransformer } from './transformers/auth-user-info.transformer';
import { HelperService } from '../utils/helper.service';
import * as crypto from 'crypto';
import { Cache } from 'cache-manager';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { ShopifyAdminApiService } from '../shopify-admin-api/shopify-admin-api.service';
import { ShopifyProxyRegisterDto } from './dto/shopify-proxy-auth-register.dto';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { ShopifyProxyUpdateDto } from './dto/shopify-proxy-auth-update.dto';
import { REQUEST } from '@nestjs/core';
import { Request } from 'express';
import { ShopifyCustomMeta } from 'src/enums/shopify-custom-meta.enum';
import { CustomLoggerService } from '../utils/custom-logger.service';
import { CrmLoyaltyFactory } from '../crm-loyalty/crm-loyalty.factory';
import { StampsMemberEnquireInfoTransformer } from '../crm-loyalty/transformers/stamps-member-enquiry.transformer';
@Injectable()
export class ShopifyProxyService {
    private logger: CustomLoggerService;
    constructor(
        private muleService: MuleService,
        private shopifyAdminApiService: ShopifyAdminApiService,
        @Inject(CACHE_MANAGER) private cacheManager: Cache,
        @Inject(REQUEST) private request: Request,
        private customLoggerService: CustomLoggerService,
        private crmLoyaltyFactory: CrmLoyaltyFactory
    ) {
        moment.tz.setDefault('Etc/GMT+0');
        this.customLoggerService.setContext(ShopifyProxyService.name);
        this.logger = this.customLoggerService;
    }

    getUserInfo(
        store: StoreDto,
        shopifyCustomer: ShopifyCustomer
    ): AuthUserInfoTransformer {
        const shopifyCustomerInfo = plainToInstance(
            AuthUserInfoTransformer,
            shopifyCustomer,
            {
                exposeUnsetFields: true,
                strategy: 'excludeAll'
            }
        );

        if (shopifyCustomerInfo?.phone) {
            shopifyCustomerInfo.phone = shopifyCustomerInfo.phone.replaceAll(
                store.storeIntegrations.shopify.settings.callingCode,
                ''
            );
        }

        return shopifyCustomerInfo;
    }

    async generateToken(store: StoreDto, payload: any, type = 'register') {
        const token = crypto.randomBytes(64).toString('hex');
        this.cacheManager.set(
            `${token}-auth-token:${type}`,
            JSON.stringify(payload),
            30000
        );

        return token;
    }

    async getTokenInfo(token: string, type = 'register') {
        const payload: string = await this.cacheManager.get(
            `${token}-auth-token:${type}`
        );
        return payload ? JSON.parse(payload) : null;
    }

    async deleteToken(token: string, type = 'register') {
        return await this.cacheManager.del(`${token}-auth-token:${type}`);
    }

    getMultipassToken(
        store: StoreDto,
        shopifyCustomer: ShopifyCustomer,
        headerReferer?: string
    ) {
        // if headerReferer don't have domain then set domain value
        if (headerReferer && !headerReferer.startsWith('http')) {
            // remove first / if exists
            if (headerReferer.startsWith('/')) {
                headerReferer = headerReferer.slice(1);
            }
            headerReferer = `https://${store.storeIntegrations.shopify.settings.shopDomain}/${headerReferer}`;
        } else if (
            headerReferer &&
            !headerReferer.startsWith(
                `https://${store.storeIntegrations.shopify.settings.shopDomain}`
            )
        ) {
            headerReferer = `https://${store.storeIntegrations.shopify.settings.shopDomain}`;
        }

        const encryptedValue = EncryptionService.multipassEncrypt(
            store.storeIntegrations.shopify.credentials.multipassSecret,
            JSON.stringify({
                email: shopifyCustomer.email,
                created_at: moment().toISOString(),
                return_to:
                    headerReferer ||
                    `https://${store.storeIntegrations.shopify.settings.shopDomain}`
            })
        );

        return encryptedValue;
    }

    async getLoginUrl(store: StoreDto, shopifyCustomer: ShopifyCustomer) {
        const encryptedValue = this.getMultipassToken(
            store,
            shopifyCustomer,
            this.request.body?.returnUrl || this.request.headers?.referer
        );

        // Trigger success login
        await this.successLogin(store, shopifyCustomer);

        return `https://${store.shop}/account/login/multipass/${encryptedValue}`;
    }

    async successLogin(store: StoreDto, shopifyCustomer: ShopifyCustomer) {
        const loyaltyService = this.crmLoyaltyFactory.getIntegration(store);

        if (loyaltyService) {
            const loyaltyUser = await loyaltyService.memberEnquiry(
                store,
                shopifyCustomer.email,
                shopifyCustomer
            );

            this.logger.debug(
                `loyalty: getLoginUrl: ${shopifyCustomer.email} found ${loyaltyUser.returnStatus}`
            );

            if (loyaltyUser.returnStatus === 1) {
                await this.shopifyAdminApiService.updateCustomerMetafields(
                    store,
                    shopifyCustomer,
                    {
                        loyaltyCardNo: loyaltyUser.cardInfo.cardNo,
                        membershipTierCode: loyaltyUser.cardInfo.tierCode,
                        loyaltyPoints: loyaltyUser.cardInfo.totalPointsBalance
                    }
                );

                // Only proceed if referrer integration is active
                if (store.storeIntegrations.referrer?.active) {
                    const hasReferralCode =
                        !shopifyCustomer?.metafields?.find(
                            (meta) => meta.key === ShopifyCustomMeta.ReferralCode
                        )?.value;

                    if (hasReferralCode) {
                        let referralCode: string | null = null;

                        if (store.storeIntegrations.ascentis?.active) {
                            try {
                                const res = await this.muleService.getReferralCode(
                                    store,
                                    loyaltyUser.memberInfo.membershipId,
                                    loyaltyUser.cardInfo.cardNo
                                );
    
                                if (res.success && res.data?.ReferrerCode) {
                                    referralCode = res.data.ReferrerCode;
                                    this.logger.debug(
                                        `Ascentis referral code fetch successfully: ${shopifyCustomer.email} → ${referralCode}`
                                    );
                                } else {
                                    this.logger.error(
                                        `Ascentis: referral code fetch failed: ${shopifyCustomer.email} ${res.message}`
                                    );
                                }
                            } catch (err) {
                                this.logger.error(
                                    `Ascentis: referral code error: ${shopifyCustomer.email} ${err}`
                                );
                            }
                        } else if (store.storeIntegrations.stamps?.active) {
                            // Author Name: Darshika Gilder - Purpose: to fetch referral code from Stamps
                            try {
                                const stampsInfo = loyaltyUser.memberInfo as StampsMemberEnquireInfoTransformer;
                                referralCode = stampsInfo.userReferralCode || null; //fetch the referralcode from userInfo
    
                                this.logger.debug(
                                    `Stamps referral code fetch successfully: ${shopifyCustomer.email} → ${referralCode}`
                                );
    
                                if (!referralCode) {
                                    this.logger.warn(
                                        `Stamps: referral code missing in memberInfo for ${shopifyCustomer.email}`
                                    );
                                }
                            } catch (err) {
                                this.logger.error(
                                    `Stamps: error while retrieving referral code for ${shopifyCustomer.email}: ${err}`
                                );
                            }
                        }

                        if (referralCode) {
                            try {
                                await this.shopifyAdminApiService.updateCustomerMetafields(
                                    store,
                                    shopifyCustomer,
                                    { referralCode }
                                );
                                this.logger.debug(
                                    `Referral code saved: ${shopifyCustomer.email} → ${referralCode}`
                                );
                            } catch (err) {
                                this.logger.error(
                                    `Referral code save failed: ${shopifyCustomer.email}  -> ${referralCode} -> ${err}`
                                );
                            }
                        }
                    }
                }
            }
        }

        if (HelperService.arrayMatch(shopifyCustomer?.tags, 'no_password')) {
            // remove no_password tag

            this.shopifyAdminApiService
                .updateCustomerTags(
                    store,
                    shopifyCustomer.id,
                    shopifyCustomer.tags.filter(
                        (tag) => tag.toLowerCase() !== 'no_password'
                    )
                )
                .then((res) => {
                    this.logger.debug(
                        `remove no_password tag: ${shopifyCustomer.email} ${res}`
                    );
                })
                .catch((err) => {
                    this.logger.error(
                        `remove no_password tag: ${shopifyCustomer.email} ${err}`
                    );
                });
        }
    }    

    async membershipCheck(
        store: StoreDto,
        username: string,
        shopifyCustomer?: ShopifyCustomer
    ): Promise<any> {
        const response = {
            nextflow: AuthFlows.Redirect,
            info: null
        };

        const shopifyCustomerInfo = shopifyCustomer
            ? this.getUserInfo(store, shopifyCustomer)
            : null;
        if (shopifyCustomerInfo?.membershipId) {
            response.info = shopifyCustomerInfo;

            return response;
        } else {
            // loyalty call to get membership id
            const loyaltyService = this.crmLoyaltyFactory.getIntegration(store);
            const loyaltyUser = await loyaltyService.memberEnquiry(
                store,
                username,
                shopifyCustomer
            );

            if (loyaltyUser) {
                this.logger.debug(
                    `loyalty: membershipCheck: ${username} found ${loyaltyUser.returnStatus}`
                );
                if (loyaltyUser.returnStatus === 1) {
                    response.info = loyaltyUser.memberInfo;
                    if (shopifyCustomer?.id) {
                        if (
                            loyaltyUser.cardInfo &&
                            shopifyCustomer.state === 'ENABLED'
                        ) {
                            this.shopifyAdminApiService
                                .updateCustomerMetafields(
                                    store,
                                    shopifyCustomer,
                                    {
                                        ...response.info,
                                        loyaltyCardNo:
                                            loyaltyUser.cardInfo.cardNo,
                                        membershipTierCode:
                                            loyaltyUser.cardInfo.tierCode,
                                        loyaltyPoints:
                                            loyaltyUser.cardInfo
                                                .totalPointsBalance
                                    }
                                )
                                .then((res) => {
                                    this.logger.debug(
                                        `updateCustomerMetafields: ${username} ${res}`
                                    );
                                })
                                .catch((err) => {
                                    this.logger.error(
                                        `updateCustomerMetafields: ${username} ${err}`
                                    );
                                });
                        }
                        response.nextflow = AuthFlows.Redirect;
                    } else {
                        response.nextflow = AuthFlows.REGISTER;
                    }
                } else if (loyaltyUser.returnStatus === 51) {
                    response.nextflow = AuthFlows.REGISTER;
                } else {
                    throw new HttpException(
                        'One Or More results are found. Please contact support',
                        400
                    );
                }
            } else {
                this.logger.error(
                    `loyalty: membershipCheck: ${username} error loyalty service not found`
                );
                throw new HttpException('Error processing request', 400);
            }
        }

        return response;
    }

    async decideNextFlow(
        store: StoreDto,
        username: string,
        shopifyCustomer?: ShopifyCustomer
    ) {
        const shopifyCustomerInfo = shopifyCustomer
            ? this.getUserInfo(store, shopifyCustomer)
            : null;

        const response = {
            nextflow: AuthFlows.Redirect,
            info: shopifyCustomerInfo,
            url: null,
            token: null,
            settings: store.storeIntegrations.shopify.settings
        };

        if (
            store.storeIntegrations.ascentis?.active ||
            store.storeIntegrations.stamps?.active
        ) {
            const membershipRespone = await this.membershipCheck(
                store,
                username,
                shopifyCustomer
            );
            if (membershipRespone.info) {
                response.info = membershipRespone.info;
            }
            response.nextflow = membershipRespone.nextflow;
        } else if (!shopifyCustomer) {
            response.nextflow = AuthFlows.REGISTER;
        }

        // Check if metafields are available if not then trigger update flow
        if (response.nextflow !== AuthFlows.REGISTER) {
            const customerInfo = this.checkAllInfoAvailable(
                store,
                shopifyCustomer
            );

            if (customerInfo.success) {
                this.logger.debug(
                    `login: customerInfo available: ${username} logging in`
                );
                response.nextflow = AuthFlows.Redirect;
            } else {
                this.logger.debug(
                    `login: customerInfo not available: ${username} updating info`
                );
                response.nextflow = AuthFlows.Update;
            }
        }

        // Check if terms and conditions are accepted
        if (response.nextflow === AuthFlows.Redirect) {
            if (!shopifyCustomerInfo.loyalty) {
                this.logger.debug(
                    `login: terms and conditions not accepted: ${username} updating info`
                );
                response.nextflow = AuthFlows.Terms;
            }
        }

        await this.generateNextFlowData(
            store,
            username,
            response,
            shopifyCustomer as ShopifyCustomer
        );

        this.logger.debug(`next flow: ${username} ${response.nextflow}`);

        return response;
    }

    async generateNextFlowData(
        store: StoreDto,
        username: string,
        response: any,
        shopifyCustomer?: ShopifyCustomer
    ) {
        this.logger.debug(
            `generating next flow data: ${username} ${response.nextflow}`
        );
        switch (response.nextflow) {
            case AuthFlows.REGISTER:
            case AuthFlows.Update:
            case AuthFlows.Terms:
                response.token = await this.generateToken(
                    store,
                    {
                        shopifyCustomer: shopifyCustomer,
                        membershipId: response.info?.membershipId,
                        username
                    },
                    response.nextflow
                );
                break;
            case AuthFlows.Redirect:
                response.url = await this.getLoginUrl(
                    store,
                    shopifyCustomer as ShopifyCustomer
                );
                break;
        }

        return response;
    }

    async updateShopifyCustomerOtherInfo(
        store: StoreDto,
        cutomerId: string,
        shopifyProxyRegisterDto: ShopifyProxyRegisterDto | ShopifyProxyUpdateDto
    ) {
        const shopifyCustomer = await this.shopifyAdminApiService.getCustomer(
            store,
            cutomerId
        );
        if (shopifyCustomer.success && shopifyCustomer.data) {
            const response =
                await this.shopifyAdminApiService.updateCustomerMetafields(
                    store,
                    shopifyCustomer.data,
                    shopifyProxyRegisterDto
                );

            if (shopifyProxyRegisterDto.smsOptIn !== undefined) {
                this.shopifyAdminApiService
                    .updateSmsMarketingConsent(
                        store,
                        shopifyCustomer.data,
                        shopifyProxyRegisterDto.smsOptIn
                    )
                    .then((res) => {
                        this.logger.debug(
                            `update sms marketing consent: ${cutomerId}`
                        );
                    })
                    .catch((err) => {
                        this.logger.error(
                            `update sms marketing consent: ${cutomerId} ${err}`
                        );
                    });
            }

            if (shopifyProxyRegisterDto.emailOptIn !== undefined) {
                this.shopifyAdminApiService
                    .updateEmailMarketingConsent(
                        store,
                        shopifyCustomer.data,
                        shopifyProxyRegisterDto.emailOptIn
                    )
                    .then((res) => {
                        this.logger.debug(
                            `update email marketing consent: ${cutomerId}`
                        );
                    })
                    .catch((err) => {
                        this.logger.error(
                            `update email marketing consent: ${cutomerId} ${err}`
                        );
                    });
            }

            if (shopifyProxyRegisterDto.postalAddress) {
                this.shopifyAdminApiService
                    .updateCustomer(store, cutomerId, {
                        addresses: [
                            {
                                address1: shopifyProxyRegisterDto.postalAddress,
                                countryCode:
                                    store.storeIntegrations.shopify.settings
                                        .countryCode,
                                firstName:
                                    shopifyProxyRegisterDto.firstName.trim(),
                                lastName:
                                    shopifyProxyRegisterDto.lastName.trim(),
                                phone: `${store.storeIntegrations.shopify.settings.callingCode}${shopifyProxyRegisterDto.phone}`
                            }
                        ]
                    } as any)
                    .then((res) => {
                        this.logger.debug(
                            `${store.name} update postal address: ${cutomerId} ${res}`
                        );
                    })
                    .catch((err) => {
                        this.logger.error(
                            `${
                                store.name
                            } update postal address: ${cutomerId} ${JSON.stringify(
                                err
                            )}`
                        );
                    });
            }

            return response;
        } else {
            return await this.updateShopifyCustomerOtherInfo(
                store,
                cutomerId,
                shopifyProxyRegisterDto
            );
        }
    }

    async updateShopifyCustomer(
        store: StoreDto,
        shopifyCustomer: ShopifyCustomer,
        shopifyProxyRegisterDto: ShopifyProxyRegisterDto | ShopifyProxyUpdateDto
    ) {
        const updateFields = {};
        if (!shopifyCustomer.phone && shopifyProxyRegisterDto.phone) {
            updateFields[
                'phone'
            ] = `${store.storeIntegrations.shopify.settings.callingCode}${shopifyProxyRegisterDto.phone}`;
        }

        if (shopifyProxyRegisterDto.firstName) {
            updateFields['firstName'] =
                shopifyProxyRegisterDto.firstName.trim();
        }

        if (shopifyProxyRegisterDto.lastName) {
            updateFields['lastName'] = shopifyProxyRegisterDto.lastName.trim();
        }

        if (shopifyProxyRegisterDto.gender) {
            updateFields['metafields'] =
                await this.shopifyAdminApiService.getMetafields(
                    store,
                    shopifyProxyRegisterDto,
                    shopifyCustomer
                );
        }

        return await this.shopifyAdminApiService.updateCustomer(
            store,
            shopifyCustomer.id,
            updateFields
        );
    }

    checkAllInfoAvailable(store: StoreDto, shopifyCustomer: ShopifyCustomer) {
        const customerInfo = plainToInstance(
            AuthUserInfoTransformer,
            shopifyCustomer,
            {
                exposeUnsetFields: true,
                strategy: 'excludeAll'
            }
        );

        if (
            customerInfo.firstName &&
            customerInfo.lastName &&
            customerInfo.phone &&
            customerInfo.dob &&
            customerInfo.gender &&
            (customerInfo.membershipId ||
                (!store.storeIntegrations.ascentis?.active && !store.storeIntegrations.stamps?.active)) &&
            customerInfo.email &&
            !HelperService.arrayMatch(shopifyCustomer.tags, 'no_password')
        ) {
            return {
                success: true,
                data: customerInfo
            };
        }

        return {
            success: false,
            data: customerInfo
        };
    }

    async checkEmailExists(store: StoreDto, email: string) {
        const shopifyCustomerByEmail =
            await this.shopifyAdminApiService.searchCustomerByUsername(
                store,
                email
            );

        if (shopifyCustomerByEmail.success && shopifyCustomerByEmail.data) {
            this.logger.debug(
                `register: shopifyCustomerByEmail Found: ${email}`
            );

            return true;
        }

        return false;
    }
}
