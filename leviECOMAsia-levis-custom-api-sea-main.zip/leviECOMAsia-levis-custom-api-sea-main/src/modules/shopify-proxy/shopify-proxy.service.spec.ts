import { Test, TestingModule } from '@nestjs/testing';
import { ShopifyProxyService } from './shopify-proxy.service';

describe('ShopifyProxyService', () => {
  let service: ShopifyProxyService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ShopifyProxyService],
    }).compile();

    service = module.get<ShopifyProxyService>(ShopifyProxyService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
