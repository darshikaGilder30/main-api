import { ApiProperty, PartialType } from '@nestjs/swagger';
import { ShopifyProxyCustomerAddressDto } from './shopify-proxy-customer-address.dto';
import { IsNotEmpty, IsString } from 'class-validator';

export class ShopifyProxyCustomerAddressUpdateDto extends PartialType(
    ShopifyProxyCustomerAddressDto
) {
    @ApiProperty({
        description: 'A unique address identifier.'
    })
    @IsNotEmpty()
    @IsString()
    id: string;
}
