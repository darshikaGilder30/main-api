import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsOptional } from 'class-validator';
import { i18nValidationMessage } from 'nestjs-i18n';
import { UsernameValidate } from 'src/validation-rules/username-validate/username-validate.decorator';
import { I18nTranslations } from 'src/generated/i18n.generated';

export class ShopifyProxyReferrerDto {
    @ApiProperty({
        description: 'The Email/Phone of the referrer',
        examples: ['user@example.com', '9899899898']
    })
    @IsNotEmpty({
        message: i18nValidationMessage<I18nTranslations>(
            'validation.username_not_empty'
        )
    })
    @UsernameValidate()
    username: string;

    @ApiProperty({
        description: 'The Refree name',
        examples: ['John Doe'],
        required: false
    })
    @IsNotEmpty({
        message: i18nValidationMessage<I18nTranslations>(
            'validation.name_not_empty'
        )
    })
    @IsOptional()
    name?: string;
}
