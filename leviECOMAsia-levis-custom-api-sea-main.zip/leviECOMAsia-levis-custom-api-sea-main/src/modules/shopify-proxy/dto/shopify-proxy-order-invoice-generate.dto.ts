import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class ShopifyProxyAccountInvoiceGenerateDto {
    @ApiProperty({
        description: 'A unique order identifier.'
    })
    @IsNotEmpty()
    orderId: number;

    @ApiProperty({
        description: 'A unique fulfillment identifier.'
    })
    @IsNotEmpty()
    fulfillmentId: number;
}
