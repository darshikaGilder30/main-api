import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, ValidateIf } from 'class-validator';
import { i18nValidationMessage } from 'nestjs-i18n';
import { I18nTranslations } from 'src/generated/i18n.generated';
import { UsernameValidate } from 'src/validation-rules/username-validate/username-validate.decorator';

export class ShopifyProxyAccountTrackOrderDto {
    @ApiProperty({
        description: 'The Email/Phone of the user to authenticate.',
        examples: ['user@example.com', '9899899898']
    })
    @ValidateIf((o) => !o.token)
    @IsNotEmpty({
        message: i18nValidationMessage<I18nTranslations>(
            'validation.username_not_empty'
        )
    })
    @UsernameValidate()
    username: string;

    @ApiProperty({
        description: 'A unique order identifier.'
    })
    @ValidateIf((o) => !o.token)
    @IsNotEmpty()
    orderId: string;

    @ApiProperty({
        description: 'A unique order token.'
    })
    @ValidateIf((o) => !o.orderId && !o.username)
    @IsNotEmpty()
    token: string;
}
