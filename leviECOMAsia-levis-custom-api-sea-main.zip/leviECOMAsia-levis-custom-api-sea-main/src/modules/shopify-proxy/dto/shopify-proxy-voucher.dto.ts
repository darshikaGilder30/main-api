import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsOptional } from 'class-validator';

export class ShopifyProxyVoucherDto {
    @ApiProperty({
        description: 'Voucher code'
    })
    @IsOptional()
    code?: string;

    @ApiProperty({
        description: 'Voucher type'
    })
    @IsOptional()
    type: string;
}
