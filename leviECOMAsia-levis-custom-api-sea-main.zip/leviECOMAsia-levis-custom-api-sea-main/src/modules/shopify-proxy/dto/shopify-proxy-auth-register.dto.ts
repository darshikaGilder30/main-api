import { ApiProperty } from '@nestjs/swagger';
import {
    IsBoolean,
    IsDateString,
    IsEnum,
    IsNotEmpty,
    IsOptional,
    IsString,
    Matches
} from 'class-validator';
import { i18nValidationMessage } from 'nestjs-i18n';
import { UsernameValidate } from 'src/validation-rules/username-validate/username-validate.decorator';
import { I18nTranslations } from 'src/generated/i18n.generated';
import { ReferralCodeValidate } from 'src/validation-rules/referral-code/referral-code.decorator';

export class ShopifyProxyRegisterDto {
    @ApiProperty({
        description: 'token'
    })
    @IsNotEmpty()
    token: string;

    @ApiProperty({
        description: 'The first name of the user',
        example: 'John'
    })
    @IsNotEmpty()
    @Matches(/^[a-zA-Z\u0E00-\u0E7F\u4E00-\u9FFF\s]+$/, {
        message: i18nValidationMessage<I18nTranslations>(
            'validation.invalid_characters', {
                args: {
                    property: 'First name'
                }
            }
        )
    })
    firstName: string;

    @ApiProperty({
        description: 'The last name of the user',
        example: 'Doe'
    })
    @IsNotEmpty()
    @Matches(/^[a-zA-Z\u0E00-\u0E7F\u4E00-\u9FFF\s]+$/, {
        message: i18nValidationMessage<I18nTranslations>(
            'validation.invalid_characters', {
                args: {
                    property: 'Last name'
                }
            }
        )
    })
    lastName: string;

    @ApiProperty({
        description: 'The email of the user to authenticate.',
        example: 'john@example.com'
    })
    @IsNotEmpty()
    @UsernameValidate({
        message: i18nValidationMessage<I18nTranslations>(
            'validation.invalid_email'
        ),
        context: {
            type: 'email'
        }
    })
    email: string;

    @ApiProperty({
        description: 'The phone of the user to authenticate.',
        example: '+1234567890'
    })
    @IsNotEmpty()
    @UsernameValidate({
        message: i18nValidationMessage<I18nTranslations>(
            'validation.invalid_phone'
        ),
        context: {
            type: 'phone'
        }
    })
    phone: string;

    @ApiProperty({
        description: 'The password of the user to authenticate.'
    })
    @IsNotEmpty()
    password: string;

    @ApiProperty({
        description: 'The password of the user to authenticate.'
    })
    @IsNotEmpty()
    confirmPassword: string;

    @ApiProperty({
        description: 'Referral code'
    })
    @ReferralCodeValidate({
        message: i18nValidationMessage<I18nTranslations>(
            'validation.invalid_referral_code'
        )
    })
    referralCode?: string;

    @ApiProperty({
        description: 'Date of birth',
        example: '2021-05-01'
    })
    @IsDateString()
    @IsNotEmpty()
    dob: string;

    @ApiProperty({
        description: 'Gender',
        example: 'Male',
        enum: ['Male', 'Female', 'Not Disclosed']
    })
    @IsNotEmpty()
    @IsEnum(['Male', 'Female', 'Not Disclosed'])
    gender: string;

    @ApiProperty({
        description: 'Email opt in',
        example: true
    })
    @IsBoolean()
    emailOptIn?: boolean;

    @ApiProperty({
        description: 'SMS opt in',
        example: true
    })
    @IsBoolean()
    smsOptIn?: boolean;

    @IsOptional()
    @ApiProperty({
        description: 'Postal address',
        example: '123 Main St, New York, NY 10001'
    })
    postalAddress?: string;

    @IsOptional()
    @IsBoolean()
    terms?: boolean;

    @IsOptional()
    @IsString()
    membershipId?: string;

    @IsOptional()
    @IsString()
    verifiedSource?: string;

    @IsOptional()
    @IsString()
    posSource?: string;

    @IsOptional()
    @IsString()
    postalCode?: string;
}
