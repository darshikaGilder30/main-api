import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class ShopifyProxyOrderReturnStatusDto {
    @ApiProperty({
        description: 'A unique order identifier.'
    })
    @IsNotEmpty()
    orderId: string;
}
