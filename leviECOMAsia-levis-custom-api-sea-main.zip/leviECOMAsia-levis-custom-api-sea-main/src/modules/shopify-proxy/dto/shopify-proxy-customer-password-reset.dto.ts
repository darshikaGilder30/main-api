import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class ShopifyProxyCustomerPasswordResetDto  {

    @ApiProperty({
        description: 'Current Password',
        example: '*********'
    })
    @IsNotEmpty()
    currentPassword: string;

    @ApiProperty({
        description: 'New Password',
        example: '*********'
    })
    @IsNotEmpty()
    password: string;

    @ApiProperty({
        description: 'Confirm Password',
        example: '*********'
    })
    @IsNotEmpty()
    confirmPassword: string;
}
