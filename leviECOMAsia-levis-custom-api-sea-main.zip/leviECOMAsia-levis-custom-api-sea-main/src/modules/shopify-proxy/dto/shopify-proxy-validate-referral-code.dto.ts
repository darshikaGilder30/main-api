import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, Validate } from 'class-validator';
import { i18nValidationMessage } from 'nestjs-i18n';
import { I18nTranslations } from 'src/generated/i18n.generated';
import { ReferralCodeValidate } from 'src/validation-rules/referral-code/referral-code.decorator';

export class ShopifyProxyValidateReferralCodeDto {
    @ApiProperty({
        description: 'Referral code'
    })
    @ReferralCodeValidate({
        message: i18nValidationMessage<I18nTranslations>(
            'validation.invalid_referral_code'
        )
    })
    @IsNotEmpty()
    referralCode: string;
}
