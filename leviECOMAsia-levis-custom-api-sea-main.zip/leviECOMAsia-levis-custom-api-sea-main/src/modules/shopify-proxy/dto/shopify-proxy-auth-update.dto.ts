import { ApiProperty, OmitType, PartialType } from '@nestjs/swagger';
import { ShopifyProxyRegisterDto } from './shopify-proxy-auth-register.dto';
import { IsOptional } from 'class-validator';

export class ShopifyProxyUpdateDto extends PartialType(OmitType(ShopifyProxyRegisterDto, ['password', 'confirmPassword'])) {

    @ApiProperty({
        description: 'The password of the user to authenticate.'
    })
    @IsOptional()
    password?: string;

    @ApiProperty({
        description: 'The password of the user to authenticate.'
    })
    @IsOptional()
    confirmPassword?: string;
}
