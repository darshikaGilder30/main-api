import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsOptional } from 'class-validator';
import { i18nValidationMessage } from 'nestjs-i18n';
import { I18nTranslations } from 'src/generated/i18n.generated';

export class ShopifyProxyFindInLocationDto {  

    @ApiProperty({
        description: 'Product Variant Id',
        examples: ['23232'],
        required: true
    })
    @IsNotEmpty({
        message: i18nValidationMessage<I18nTranslations>(
            'validation.required', {
                args: { property: 'Product Variant Id' }
            }
        )
    })
    variantId: string;

    @ApiProperty({
        description: 'Latitude',
        examples: ['10.123456'],
        required: true
    })
    @IsNotEmpty({
        message: i18nValidationMessage<I18nTranslations>(
            'validation.required', {
                args: { property: 'Latitude' }
            }
        )
    })
    lat: string;

    @ApiProperty({
        description: 'Longitude',
        examples: ['10.123456'],
        required: true
    })
    @IsNotEmpty({
        message: i18nValidationMessage<I18nTranslations>(
            'validation.required', {
                args: { property: 'Longitude' }
            }
        )
    })
    lng: string;
}
