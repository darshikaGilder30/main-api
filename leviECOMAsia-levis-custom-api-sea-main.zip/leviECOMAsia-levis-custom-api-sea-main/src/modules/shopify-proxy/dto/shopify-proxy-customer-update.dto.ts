import { ApiProperty, OmitType, PartialType } from '@nestjs/swagger';
import { ShopifyProxyRegisterDto } from './shopify-proxy-auth-register.dto';

export class ShopifyProxyCustomerUpdateDto extends PartialType(OmitType(ShopifyProxyRegisterDto, ['password', 'confirmPassword', 'token', 'phone', 'email', 'dob', 'referralCode'])) {

    @ApiProperty({
        description: 'Tax ID',
        example: '1234567890'
    })
    taxId?: string;

    @ApiProperty({
        description: 'Tax Address',
        example: '123 Main St'
    })

    taxAddress?: string;
}
