import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class ShopifyProxyVoucherApplyDto {
    @ApiProperty({
        description: 'Voucher code'
    })
    @IsNotEmpty()
    code: string;
}
