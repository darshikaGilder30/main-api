import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';
import { i18nValidationMessage } from 'nestjs-i18n';
import { I18nTranslations } from 'src/generated/i18n.generated';
import { UsernameValidate } from 'src/validation-rules/username-validate/username-validate.decorator';

export class ShopifyProxyCustomerAddressDto {
    @ApiProperty({
        description:
            'The first line of the address. Typically the street address or PO Box number.'
    })
    @IsNotEmpty()
    address1: string;

    @ApiProperty({
        description:
            'The second line of the address. Typically the number of the apartment, suite, or unit.'
    })
    address2: string;

    @ApiProperty({
        description: 'The name of the city, district, village, or town.'
    })
    @IsNotEmpty()
    city: string;

    @ApiProperty({
        description: `The name of the customer's company or organization.`
    })
    company: string;

    @ApiProperty({
        description: 'The name of the country.'
    })
    @IsNotEmpty()
    country: string;

    @ApiProperty({
        description: 'The first name of the customer.'
    })
    @IsNotEmpty()
    firstName: string;

    @ApiProperty({
        description: 'The last name of the customer.'
    })
    lastName: string;

    @ApiProperty({
        description: 'A unique phone number for the customer.',
        example: '+16135551111'
    })
    @UsernameValidate({
        message: i18nValidationMessage<I18nTranslations>(
            'validation.invalid_phone'
        ),
        context: {
            type: 'phone'
        }
    })
    @IsNotEmpty()
    phone: string;

    @ApiProperty({
        description:
            'The region of the address, such as the province, state, or district.'
    })
    province: string;

    @ApiProperty({
        description: 'The zip or postal code of the address.'
    })
    @IsNotEmpty()
    zip: string;
}
