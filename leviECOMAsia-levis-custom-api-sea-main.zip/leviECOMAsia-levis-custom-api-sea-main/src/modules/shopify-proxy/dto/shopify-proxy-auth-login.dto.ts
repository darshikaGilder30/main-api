import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';
import { ShopifyProxyAuthValidateDto } from './shopify-proxy-auth-validate.dto';
import { i18nValidationMessage } from 'nestjs-i18n';
import { I18nTranslations } from 'src/generated/i18n.generated';

export class ShopifyProxyAuthLoginDto extends ShopifyProxyAuthValidateDto {
    @ApiProperty({
        description: 'The password of the user to authenticate.'
    })
    @IsNotEmpty({
        message: i18nValidationMessage<I18nTranslations>("validation.password_not_empty")
    })
    password: string;
}
