import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';
import { Optional } from '@nestjs/common';

export class ShopifyProxyLoyaltyApplyDto {
    @ApiProperty({
        description: 'Loaylty apply flag'
    })
    @Optional()
    applyLoyalty: boolean;

    @ApiProperty({
        description: 'Cart Sub total'
    })
    @IsNotEmpty()
    subtotalAmount: number;

    @ApiProperty({
        description: 'Cart total'
    })
    @IsNotEmpty()
    totalAmount: number;

    @ApiProperty({
        description: 'Cart discount total with RedTab discount'
    })
    @IsNotEmpty()
    totalDiscount: number;

    @ApiProperty({
        description: 'Cart shipping total'
    })
    @IsNotEmpty()
    totalShippingAmount: number;

    @ApiProperty({
        description: 'Cart tax total'
    })
    @IsNotEmpty()
    totalTaxAmount: number;
}
