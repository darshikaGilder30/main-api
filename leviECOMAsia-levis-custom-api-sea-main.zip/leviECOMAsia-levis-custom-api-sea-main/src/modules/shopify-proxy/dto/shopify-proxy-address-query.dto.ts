import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsOptional } from 'class-validator';
import { Lang } from 'src/enums/lang.enum';

export class ShopifyProxyAddressQueryDto {
    @ApiProperty({
        description: 'The number of results to return',
        required: false,
        default: 10
    })
    @IsOptional()
    limit: number;

    @ApiProperty({
        description: 'The locale of the address',
        required: false,
        enum: Lang
    })
    @IsEnum(Lang)
    @IsOptional()
    locale: Lang;
}
