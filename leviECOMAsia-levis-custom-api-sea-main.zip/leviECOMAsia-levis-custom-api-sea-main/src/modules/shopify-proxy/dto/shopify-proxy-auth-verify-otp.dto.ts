import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, Length } from 'class-validator';
import { ShopifyProxyAuthValidateDto } from './shopify-proxy-auth-validate.dto';
import { i18nValidationMessage } from 'nestjs-i18n';
import { I18nTranslations } from 'src/generated/i18n.generated';

export class ShopifyProxyVerifyOtpDto extends ShopifyProxyAuthValidateDto {
    @ApiProperty({
        description: 'The otp of the user to authenticate.'
    })
    @IsNotEmpty({
        message: i18nValidationMessage<I18nTranslations>("validation.otp_not_empty")
    })
    @Length(6, 6, {
        message: i18nValidationMessage<I18nTranslations>("validation.otp_length")
    })
    otp: string;
}
