import { Module } from '@nestjs/common';
import { CacheHelper } from './cache-helper.service';

@Module({
    imports: [],
    providers: [CacheHelper],
    exports: [CacheHelper]
})
export class CacheHelperModule {
   
}
