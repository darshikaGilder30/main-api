import { Test, TestingModule } from '@nestjs/testing';
import { CacheHelper } from './cache-helper.service';
import { CACHE_MANAGER } from '@nestjs/cache-manager';

describe('CacheHelper', () => {
  let cacheHelper: CacheHelper;
  let cacheManagerMock: any;

  beforeEach(async () => {
    cacheManagerMock = {
      get: jest.fn(),
      set: jest.fn(),
      del: jest.fn(),
    };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        CacheHelper,
        {
          provide: CACHE_MANAGER,
          useValue: cacheManagerMock,
        },
      ],
    }).compile();

    cacheHelper = module.get<CacheHelper>(CacheHelper);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('get', () => {
    it('should call cacheManager.get with the provided key', async () => {
      const key = 'testKey';
      await cacheHelper.get(key);
      expect(cacheManagerMock.get).toHaveBeenCalledWith(key);
    });

    it('should return the value returned by cacheManager.get', async () => {
      const key = 'testKey';
      const expectedValue = 'cachedValue';
      cacheManagerMock.get.mockResolvedValueOnce(expectedValue);
      const result = await cacheHelper.get(key);
      expect(result).toEqual(expectedValue);
    });
  });

  describe('set', () => {
    it('should call cacheManager.set with the provided key, value, and ttl', async () => {
      const key = 'testKey';
      const value = 'testValue';
      const ttl = 3600;
      await cacheHelper.set(key, value, ttl);
      expect(cacheManagerMock.set).toHaveBeenCalledWith(key, value, ttl);
    });
  });

  describe('del', () => {
    it('should call cacheManager.del with the provided key', async () => {
      const key = 'testKey';
      await cacheHelper.del(key);
      expect(cacheManagerMock.del).toHaveBeenCalledWith(key);
    });
  });

  describe('remember', () => {
    it('should return value from cache if it exists', async () => {
      const key = 'testKey';
      const value = 'cachedValue';
      cacheManagerMock.get.mockResolvedValueOnce(value);
      const callback = jest.fn();
      const result = await cacheHelper.remember(key, 3600, callback);
      expect(result).toEqual(value);
      expect(callback).not.toHaveBeenCalled();
    });

    it('should return value from callback and set it in cache if not found in cache', async () => {
      const key = 'testKey';
      const value = 'cachedValue';
      const ttl = 3600;
      cacheManagerMock.get.mockResolvedValueOnce(null);
      const callback = jest.fn().mockResolvedValueOnce(value);
      const result = await cacheHelper.remember(key, ttl, callback);
      expect(result).toEqual(value);
      expect(cacheManagerMock.set).toHaveBeenCalledWith(key, value, ttl);
    });

    it('should return null if callback returns null', async () => {
      const key = 'testKey';
      const ttl = 3600;
      cacheManagerMock.get.mockResolvedValueOnce(null);
      const callback = jest.fn().mockResolvedValueOnce(null);
      const result = await cacheHelper.remember(key, ttl, callback);
      expect(result).toBeNull();
      expect(cacheManagerMock.set).not.toHaveBeenCalled();
    });
  });
});
