import { Injectable, Scope, ConsoleLogger, Inject } from '@nestjs/common';
import { REQUEST } from '@nestjs/core';
import { Request } from 'express';

@Injectable({ scope: Scope.REQUEST })
export class CustomLoggerService {
	logger = new ConsoleLogger(CustomLoggerService.name);
    constructor(@Inject(REQUEST) private request: Request) {
		
    }

	setContext(context: string) {
		this.logger.setContext(context);
	}

	addStoreInfo(message: string) {
		return `${this.request['store'].name} - ${message}`;
	}

    debug(message: any) {
        message = this.addStoreInfo(message);
        this.logger.debug(message);
	}

	error(message: any, trace?: string) {
		message = this.addStoreInfo(message);
		this.logger.error(message, trace);
	}

	log(message: any) {
		message = this.addStoreInfo(message);
		this.logger.log(message);
	}

	fatal(message: any) {
		message = this.addStoreInfo(message);
		this.logger.fatal(message);
	}

	warn(message: any) {
		message = this.addStoreInfo(message);
		this.logger.warn(message);
	}

	verbose(message: any) {
		message = this.addStoreInfo(message);
		this.logger.verbose(message);
	}
}
