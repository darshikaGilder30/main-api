import {
    createCipheriv,
    createHash,
    createDecipheriv,
    randomBytes,
    createHmac
} from 'crypto';

export class EncryptionService {
    static encrypt(payload: string): string {
        const key = createHash('sha256').update(process.env.APP_ENCRYPTION_KEY).digest('hex');
        const cipher = createCipheriv(
            'aes-256-cbc',
            Buffer.from(key, 'hex'),
            Buffer.alloc(16)
        );
        let encrypted = cipher.update(payload);
        encrypted = Buffer.concat([encrypted, cipher.final()]);
        return encrypted.toString('base64');
    }
    static decrypt(payload: string): string {
        const key = createHash('sha256').update(process.env.APP_ENCRYPTION_KEY).digest('hex');
        const encryptedText = Buffer.from(payload, 'base64');
        const decipher = createDecipheriv(
            'aes-256-cbc',
            Buffer.from(key, 'hex'),
            Buffer.alloc(16)
        );
        let decrypted = decipher.update(encryptedText);
        decrypted = Buffer.concat([decrypted, decipher.final()]);
        return decrypted.toString();
    }

    static multipassEncrypt(encKey: string, payload: any) {
        const blocksize = 16;
        const hash = createHash('sha256').update(encKey).digest();
        const encryptionKey = hash.slice(0, blocksize);
        const signingKey = hash.slice(blocksize, 32);
        var iv = randomBytes(blocksize);
        var cipher = createCipheriv('aes-128-cbc', encryptionKey, iv);

        // Use IV as first block of ciphertext
        var encrypted = Buffer.concat([
            iv,
            cipher.update(payload, 'utf8'),
            cipher.final()
        ]);

        // Sign the final ciphertext block
        var signature = createHmac('sha256', signingKey)
            .update(encrypted)
            .digest();

        // Prepend signature to ciphertext
        let encryptedValue = Buffer.concat([encrypted, signature]).toString(
            'base64'
        );

        encryptedValue = encryptedValue.replace(/\+/g, '-').replace(/\//g, '_');

        return encryptedValue;
    }
}
