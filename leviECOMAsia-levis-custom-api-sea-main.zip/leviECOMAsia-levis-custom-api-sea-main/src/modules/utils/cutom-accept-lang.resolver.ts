import { Injectable, ExecutionContext, Logger } from '@nestjs/common';
import { pick } from 'accept-language-parser';
import { I18nResolver, I18nResolverOptions, I18nService } from 'nestjs-i18n';

interface AcceptLanguageResolverOptions {
    matchType: 'strict' | 'loose' | 'strict-loose';
}

@Injectable()
export class CustomAcceptLanguageResolver implements I18nResolver {
    logger = new Logger(CustomAcceptLanguageResolver.name)
    constructor(
        @I18nResolverOptions()
        private options: AcceptLanguageResolverOptions = {
            matchType: 'strict-loose',
        },
    ) { }

    async resolve(
        context: ExecutionContext,
    ): Promise<string | string[] | undefined> {
        let req: any;
        let service: I18nService;

        switch (context.getType() as string) {
            case 'http':
                req = context.switchToHttp().getRequest();
                service = req.i18nService;
                break;
            case 'graphql':
                [, , { req, i18nService: service }] = context.getArgs();
                if (!req) return undefined;
                break;
            default:
                return undefined;
        }
        const supportedLangs = service.getSupportedLanguages();
        const referer = req.headers?.referer

        if (referer) {
            const parts = referer.split('/');
            if (parts.length > 2 && supportedLangs.includes(parts[3])) {
                this.logger.debug(`${parts[3]} Lang Resolved`)
                return parts[3];
            }
        }

        const lang = req.raw
            ? req.raw.headers?.['accept-language']
            : req?.headers?.['accept-language'];

        if (lang) {
            if (this.options.matchType === 'strict') {
                return pick(supportedLangs, lang);
            } else if (this.options.matchType === 'loose') {
                return pick(supportedLangs, lang, { loose: true });
            }
            this.logger.debug(`Accept header lang: ${lang}`)
            return (
                pick(supportedLangs, lang) ??
                pick(supportedLangs, lang, { loose: true })
            );
        }
        return lang;
    }
}