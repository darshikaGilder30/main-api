import { Injectable, Logger } from '@nestjs/common';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { ShopifyAdminApiService } from '../shopify-admin-api/shopify-admin-api.service';
import { LiquidTemplateService } from './liquid.service';
import { ShopifyAdminRestApiService } from '../shopify-admin-api/shopify-admin-rest-api.service';
import * as puppeteer from 'puppeteer';
import * as _ from 'lodash';
import { ConfigService } from '@nestjs/config';
@Injectable()
export class InvoiceService {
    logger = new Logger(InvoiceService.name)

    constructor(
        private shopifyAdminApiService: ShopifyAdminApiService,
        private liquidService: LiquidTemplateService,
        private shopifyAdminRestApiService: ShopifyAdminRestApiService,
        private configService: ConfigService
    ) { }

    async generateInvoice(store: StoreDto, fulfillmentEvent: {
        order_id: number,
        fulfillment_id: number

    }) {
        try {
            const orderDetails =
                await this.shopifyAdminRestApiService.getOrderByOrderId(
                    store,
                    fulfillmentEvent.order_id.toString()
                )
            const fulfillment = orderDetails.data.fulfillments.find(
                (fulfillment) => fulfillment.id == fulfillmentEvent.fulfillment_id
            )

            if (!fulfillment) {
                this.logger.warn(
                    `${store.name} - Fulfillment ${fulfillmentEvent.fulfillment_id} not found in order ${fulfillmentEvent.order_id}`
                )

                return {
                    invoice: null,
                    order: null,
                }
            }

            const orderMetafieldsData = await this.shopifyAdminApiService.getOrderMetafields(
                store as any,
                fulfillmentEvent.order_id.toString()
            )
            // convert metafields to object
            const orderMetafields = orderMetafieldsData.data?.reduce(
                (obj, item) => {
                    obj[item.key] = item.value
                    return obj
                },
                {}
            )

            const orderData = orderDetails['data']
            const noteAttributes = orderData['note_attributes']
            const proRateCalculation = noteAttributes.find(
                (object) => object['name'] == 'prorateCalculation'
            )
            const rateDetails = proRateCalculation
                ? JSON.parse(proRateCalculation['value'])
                : []
            const aggregateDetails = {
                subtotal: 0,
                shipping_price: 0,
                tax_details: {},
                discount: 0,
                total: 0,
                total_tax: 0,
            }

            for (const lineItem of fulfillment.line_items) {
                const variantId = lineItem['variant_id']
                const variantResponse =
                    await this.shopifyAdminApiService.getProductVariantById(
                        store as any,
                        variantId
                    )
                const variantDetails = variantResponse['data']
                let description = ''
                for (const selectedOption of variantDetails['selectedOptions']) {
                    description += `${selectedOption['name']}=${selectedOption['value']}; `
                }

                if (variantResponse.data.product?.metafields?.edges?.length > 0) {
                    if (variantResponse.data.product.metafields.edges.find(
                        (node) => node.node.key == 'levis_color'
                    )?.node?.value) {
                        description += 'Color=' + variantResponse.data.product.metafields.edges.find(
                            (node) => node.node.key == 'levis_color'
                        )?.node?.value + '; '
                    }
                }

                lineItem['variant_description'] = description
                const variantImage = variantResponse['data']['image']
                const productImage = variantResponse['data'].product?.featuredImage

                let imageUrl: string
                if (variantImage != null) {
                    imageUrl = variantImage['url']
                } else if (productImage != null) {
                    imageUrl = productImage['url']
                } else {
                    imageUrl =
                        'https://upload.wikimedia.org/wikipedia/commons/a/ac/No_image_available.svg'
                }
                lineItem['image'] = imageUrl

                let rateInfo = rateDetails.find(
                    (rateDetail) => rateDetail['id'] == lineItem['id']
                )
                if (!rateInfo) {
                    rateInfo = {
                        itemDiscountPerQuantity: 0,
                        redeemableCashPerQuantity: 0,
                        orderDiscountPerQuantity: 0,
                        shippingChargesPerQuantity: 0,
                    }
                }

                const orderLineItem = orderData.line_items.find(
                    (item) => item.id === lineItem.id
                )
                lineItem['shipping_price'] =
                    rateInfo['shippingChargesPerQuantity'] * lineItem['quantity']
                lineItem['price_per_quantity'] = orderLineItem['price']
                lineItem['subtotal'] =
                    lineItem['price_per_quantity'] * lineItem['quantity']
                lineItem['discount'] = ((rateInfo['orderDiscountPerQuantity'] || 0) * lineItem['quantity']) + ((rateInfo['redeemableCashPerQuantity'] || 0) * lineItem['quantity']) + ((rateInfo['itemDiscountPerQuantity'] || 0) * lineItem['quantity'])

                // aggregate
                lineItem['tax_lines'].forEach((taxLine) => {
                    const taxName = `${taxLine['title']} (${(taxLine['rate'] * 100).toFixed(0)
                        }%)`
                    if (aggregateDetails['tax_details'][taxName] === undefined) {
                        aggregateDetails['tax_details'][taxName] = 0
                    }
                    aggregateDetails['tax_details'][taxName] += +taxLine['price']
                    aggregateDetails['total_tax'] += +taxLine['price']
                })
                aggregateDetails['subtotal'] += +lineItem['subtotal']
                aggregateDetails['discount'] += +lineItem['discount']
                aggregateDetails['shipping_price'] += +lineItem['shipping_price']
                aggregateDetails['total'] +=
                    +lineItem['subtotal'] +
                    +lineItem['shipping_price'] -
                    lineItem['discount']
            }
            // store.storeIntegrations.shopify.settings.countryCode = 'TH';
            const templateId = `invoices/order-invoice.${_.toLower(store.storeIntegrations.shopify.settings.countryCode)}.liquid`
            let returnWindow = 30
            if (store.storeIntegrations.ascentis?.active) {
                returnWindow = store.storeIntegrations.ascentis?.settings?.returnWindow || 30
            } else if (store.storeIntegrations.salesData?.active)  {
                returnWindow = store.storeIntegrations.salesData?.settings?.returnWindow || 30
            }
            const html = await this.liquidService.render(
                store,
                templateId,
                {
                    ...fulfillment,
                    returnWindow,
                    orderInfo: orderData,
                    aggregateDetails: aggregateDetails,
                    orderMetafields
                }
            )

            const browser = await puppeteer.launch({
                headless: 'new',
                executablePath: this.configService.get('environment') === 'development' ? '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome' : puppeteer.executablePath(),
                args: [
                    '--disable-features=IsolateOrigins',
                    '--disable-site-isolation-trials',
                    '--autoplay-policy=user-gesture-required',
                    '--disable-background-networking',
                    '--disable-background-timer-throttling',
                    '--disable-backgrounding-occluded-windows',
                    '--disable-breakpad',
                    '--disable-client-side-phishing-detection',
                    '--disable-component-update',
                    '--disable-default-apps',
                    '--disable-dev-shm-usage',
                    '--disable-domain-reliability',
                    '--disable-extensions',
                    '--disable-features=AudioServiceOutOfProcess',
                    '--disable-hang-monitor',
                    '--disable-ipc-flooding-protection',
                    '--disable-notifications',
                    '--disable-offer-store-unmasked-wallet-cards',
                    '--disable-popup-blocking',
                    '--disable-print-preview',
                    '--disable-prompt-on-repost',
                    '--disable-renderer-backgrounding',
                    '--disable-setuid-sandbox',
                    '--disable-speech-api',
                    '--disable-sync',
                    '--hide-scrollbars',
                    '--ignore-gpu-blacklist',
                    '--metrics-recording-only',
                    '--mute-audio',
                    '--no-default-browser-check',
                    '--no-first-run',
                    '--no-pings',
                    '--no-sandbox',
                    '--no-zygote',
                    '--password-store=basic',
                    '--use-gl=swiftshader',
                    '--use-mock-keychain'
                ],
                // userDataDir: './tmp'
            })

            // Create a new page
            const page = await browser.newPage()
            await page.setContent(html, {
                waitUntil: 'networkidle0',
            })

            const invoice = await page.pdf({
                format: 'A4',
                scale: 0.9,
                margin: {
                    top: '10',
                    bottom: '10',
                    left: '10',
                    right: '10',
                },
            })

            await page.close()
            await browser.close()

            return {
                order: orderData,
                invoice,
                fulfillment
            }
        } catch (error) {
            this.logger.error(`${store.name} - ${error}`)
        }

        return {
            invoice: null,
            order: null,
        }
    }
}