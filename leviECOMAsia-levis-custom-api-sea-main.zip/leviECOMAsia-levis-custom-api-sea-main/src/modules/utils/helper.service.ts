import * as moment from 'moment-timezone';
import * as QRCode from 'qrcode';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { ShopifyProxyLoyaltyApplyDto } from '../shopify-proxy/dto/shopify-proxy-loyalty-apply.dto';

export class HelperService {
    constructor() {
        moment.tz.setDefault('Etc/GMT+0');
    }

    static parseAcentiesData(
        date: string,
        format = 'YYYY-MM-DD',
        toTimezone = null
    ) {
        const regex = /\/Date\((\d+)\)\//;
        const match = regex.exec(date);
        if (match) {
            const timestamp = parseInt(match[1], 10);
            let date = moment(timestamp);
            if (toTimezone) {
                date = date.tz(toTimezone);
            }

            return date.format(format);
        }

        return null;
    }

    static async generateQRCodeBase64(text: string) {
        try {
            return await QRCode.toDataURL(text);
        } catch (err) {
            console.error(err);
        }

        return null;
    }

    // Deprecated
    static calcualteRedeemableLoyaltyRoundingTotal(
        store: StoreDto,
        userLoyalty: number,
        rebate: string,
        orderCost: ShopifyProxyLoyaltyApplyDto
    ) {
        const orderTotal =
            orderCost.subtotalAmount - (orderCost.totalDiscount || 0);
        const minRedeemableLoyaltyPoints =
            store.storeIntegrations.ascentis.settings[
                'minRedeemableLoyaltyPoints'
            ] || 100;
        const maxAllowedRedeemableCashFromPointPercentage =
            store.storeIntegrations.ascentis.settings[
                'maxAllowedRedeemableCashFromPointPercentage'
            ] || 100;
        const maxCashRedeemable =
            store.storeIntegrations.ascentis.settings['maxCashRedeemable'] ||
            1000;
        const maxAllowedCashRedeemable = Math.min(
            maxCashRedeemable,
            (orderTotal * maxAllowedRedeemableCashFromPointPercentage) / 100
        );
        let maxRedeemableCash = 0;
        let maxRedeemablePoints = 0;
        if (userLoyalty > minRedeemableLoyaltyPoints) {
            const userLoyaltyToCash = this.rebateValueFromPoints(
                userLoyalty,
                rebate
            );
            if (userLoyaltyToCash >= orderTotal) {
                maxRedeemablePoints = this.pointsFromCash(orderTotal, rebate);
                maxRedeemableCash = orderTotal;
            } else {
                let orderTotalAfterPointsCashRedemption =
                    orderTotal - userLoyaltyToCash;
                const orderDecialValue = orderTotal % 1;
                if (!Number.isInteger(orderTotalAfterPointsCashRedemption)) {
                    maxRedeemableCash = Math.floor(
                        orderTotal - orderTotalAfterPointsCashRedemption
                    );
                    maxRedeemablePoints = this.pointsFromCash(
                        maxRedeemableCash,
                        rebate
                    );

                    if (!Number.isInteger(orderDecialValue)) {
                        maxRedeemableCash -= 1 - orderDecialValue;
                        maxRedeemablePoints = this.pointsFromCash(
                            maxRedeemableCash,
                            rebate
                        );
                    }
                } else {
                    maxRedeemablePoints = userLoyalty;
                    maxRedeemableCash = userLoyaltyToCash;
                }
            }

            // check max cash redeemable
            if (maxRedeemableCash > maxAllowedCashRedeemable) {
                let orderTotalAfterPointsCashRedemption =
                    orderTotal - maxAllowedCashRedeemable;
                const orderDecialValue = orderTotal % 1;
                if (!Number.isInteger(orderTotalAfterPointsCashRedemption)) {
                    maxRedeemableCash = Math.floor(
                        orderTotal - orderTotalAfterPointsCashRedemption
                    );
                    maxRedeemablePoints = this.pointsFromCash(
                        maxRedeemableCash,
                        rebate
                    );

                    if (!Number.isInteger(orderDecialValue)) {
                        maxRedeemableCash -= 1 - orderDecialValue;
                        maxRedeemablePoints = this.pointsFromCash(
                            maxRedeemableCash,
                            rebate
                        );
                    }
                } else {
                    maxRedeemablePoints = userLoyalty;
                    maxRedeemableCash = maxRedeemableCash;
                }
            }
        }

        return {
            redeemablePoints: parseInt(maxRedeemablePoints.toFixed(0)),
            redeemableCash: parseFloat(maxRedeemableCash.toFixed(2)),
            userLoyalty,
            orderTotal,
            balancePayable: orderTotal - maxRedeemableCash,
            maxAllowedRedeemableCashFromPointPercentage,
            maxAllowedCashRedeemable,
            minRedeemableLoyaltyPoints,
            maxCashRedeemable
        };
    }

    // Deprecated
    static calculateRedeemableLoyaltyRoundingRewardCash(
        store: StoreDto,
        userLoyalty: number,
        rebate: string,
        orderCost: ShopifyProxyLoyaltyApplyDto,
        settings: any
    ) {
        const orderTotal =
            orderCost.subtotalAmount - (orderCost.totalDiscount || 0);
        const minRedeemableLoyaltyPoints =
            settings['minRedeemableLoyaltyPoints'] || 100;
        const maxAllowedRedeemableCashFromPointPercentage =
            settings['maxAllowedRedeemableCashFromPointPercentage'] || 100;
        const maxCashRedeemable = settings['maxCashRedeemable'] || 1000;
        const maxAllowedCashRedeemable = Math.min(
            maxCashRedeemable,
            (orderTotal * maxAllowedRedeemableCashFromPointPercentage) / 100
        );
        let maxRedeemableCash = 0;
        let maxRedeemablePoints = 0;
        if (userLoyalty > minRedeemableLoyaltyPoints) {
            const userLoyaltyToCash = this.rebateValueFromPoints(
                userLoyalty,
                rebate
            );
            if (userLoyaltyToCash >= orderTotal) {
                maxRedeemablePoints = this.pointsFromCash(orderTotal, rebate);
                maxRedeemableCash = orderTotal;
            } else {
                maxRedeemablePoints = userLoyalty;
                maxRedeemableCash = userLoyaltyToCash;
            }

            // check max cash redeemable
            if (maxRedeemableCash > maxAllowedCashRedeemable) {
                maxRedeemableCash = maxAllowedCashRedeemable;
                maxRedeemablePoints = this.pointsFromCash(
                    maxRedeemableCash,
                    rebate
                );
            }

            if (orderTotal > maxRedeemableCash) {
                // Round down redeemable cash to avoid decimal value
                const maxRedeemableCashDecimal = maxRedeemableCash % 1;
                if (!Number.isInteger(maxRedeemableCashDecimal)) {
                    maxRedeemableCash = Math.floor(maxRedeemableCash);
                    maxRedeemablePoints = this.pointsFromCash(
                        maxRedeemableCash,
                        rebate
                    );
                }
            }
        }

        return {
            redeemablePoints: parseInt(maxRedeemablePoints.toFixed(0)),
            redeemableCash: parseFloat(maxRedeemableCash.toFixed(2)),
            userLoyalty,
            orderTotal,
            balancePayable: orderTotal - maxRedeemableCash,
            maxAllowedRedeemableCashFromPointPercentage,
            maxAllowedCashRedeemable,
            minRedeemableLoyaltyPoints,
            maxCashRedeemable
        };
    }

    static rebateValueFromPoints(points: number, dollarToPointsRatio: string) {
        const dollarToPointsRatioArray = dollarToPointsRatio.split(':');
        const rebate = dollarToPointsRatioArray[0];
        const rebasePoint = dollarToPointsRatioArray[1];
        let dollarValue = (points / +rebasePoint) * +rebate;
        dollarValue = dollarValue ? Math.round(dollarValue * 100) / 100 : 0;

        return dollarValue;
    }

    static pointsFromCash(cash: number, dollarToPointsRatio: string) {
        const dollarToPointsRatioArray = dollarToPointsRatio.split(':');
        const rebate = dollarToPointsRatioArray[0];
        const rebasePoint = dollarToPointsRatioArray[1];
        const points = (cash * +rebasePoint) / +rebate;
        return points;
    }

    static getDistance(
        lat1: number,
        lon1: number,
        lat2: number,
        lon2: number
    ): number {
        const R = 6371; // Radius of the earth in km
        const dLat = this.deg2rad(lat2 - lat1); // deg2rad below
        const dLon = this.deg2rad(lon2 - lon1);
        const a =
            Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(this.deg2rad(lat1)) *
                Math.cos(this.deg2rad(lat2)) *
                Math.sin(dLon / 2) *
                Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        const d = R * c; // Distance in km
        return d;
    }

    static deg2rad(deg: number): number {
        return deg * (Math.PI / 180);
    }

    static getQueryParam(url: string, param: string) {
        const queryParams = url.split('?')[1]?.split('&');
        return queryParams
            ?.find((queryParam) => queryParam.split('=')[0] === param)
            ?.split('=')[1];
    }

    static arrayMatch(tags: string[], tag: string) {
        return tags?.find((t) => t.toLowerCase() === tag)?.length > 0
            ? true
            : false;
    }

    static findDollarToPointsRatio(store: StoreDto, tierCode: string) {
        const tiers = {
            Blue: 200,
            Silver: 250,
            Gold: 500
        };
        return `${tiers[tierCode]}:1:1:1`;
    }

    static encodeToUtf16Hex(input: string): string {
        return Array.from(input)
            .map((char) => char.charCodeAt(0).toString(16).padStart(4, '0'))
            .join('');
    }
}
