import { Test, TestingModule } from '@nestjs/testing';
import { CustomLoggerService } from './custom-logger.service';
import { ConsoleLogger } from '@nestjs/common';

describe('CustomLoggerService', () => {
    let loggerService: CustomLoggerService;
    let consoleLoggerMock: ConsoleLogger;
    let requestMock: any;

    beforeEach(async () => {
        // Mock the ConsoleLogger class
        consoleLoggerMock = {
            debug: jest.fn(),
            error: jest.fn(),
            log: jest.fn(),
            fatal: jest.fn(),
            warn: jest.fn(),
            verbose: jest.fn()
        } as any;

        requestMock = {
            store: {
                name: 'Test Store'
            }
        };

        const module: TestingModule = await Test.createTestingModule({
            providers: [
                CustomLoggerService,
                {
                    provide: ConsoleLogger,
                    useValue: consoleLoggerMock
                },
                {
                    provide: 'REQUEST',
                    inject: [],
                    useFactory: () => requestMock,
                }
            ]
        }).compile();

        loggerService = await module.resolve<CustomLoggerService>(
            CustomLoggerService
        );
    });

    it('should be defined', () => {
        expect(loggerService).toBeDefined();
    });

    describe('addStoreInfo', () => {
        it('should add store information to the provided message', () => {
            const message = 'Test message';
            const expectedResult = `${requestMock.store.name} - ${message}`;
            const result = loggerService.addStoreInfo(message);
            expect(result).toEqual(expectedResult);
        });
    });

    describe('debug', () => {
        it('should call ConsoleLogger.debug with the modified message', () => {
          const message = 'Test message';
          loggerService.debug(message);
          expect(consoleLoggerMock.debug)
        });
    });

    describe('error', () => {
        it('should call ConsoleLogger.error with the modified message', () => {
            const message = 'Test message';
            const trace = 'Test trace';
            loggerService.error(message, trace);
            expect(consoleLoggerMock.error)
        });
    });

    describe('log', () => {
        it('should call ConsoleLogger.log with the modified message', () => {
            const message = 'Test message';
            loggerService.log(message);
            expect(consoleLoggerMock.log)
        });
    });

    describe('fatal', () => {
        it('should call ConsoleLogger.fatal with the modified message', () => {
            const message = 'Test message';
            loggerService.fatal(message);
            expect(consoleLoggerMock.fatal)
        });
    });

    describe('warn', () => {
        it('should call ConsoleLogger.warn with the modified message', () => {
            const message = 'Test message';
            loggerService.warn(message);
            expect(consoleLoggerMock.warn)
        });
    });

    describe('verbose', () => {
        it('should call ConsoleLogger.verbose with the modified message', () => {
            const message = 'Test message';
            loggerService.verbose(message);
            expect(consoleLoggerMock.verbose)
        });
    });

    describe('setContext', () => {
        it('should call ConsoleLogger.setContext with the provided context', () => {
            const context = 'Test context';
            loggerService.setContext(context);
            expect(consoleLoggerMock.setContext)
        });
    });
});
