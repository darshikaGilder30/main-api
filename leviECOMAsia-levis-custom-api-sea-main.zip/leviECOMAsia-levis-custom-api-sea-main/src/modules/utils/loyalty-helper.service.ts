import * as moment from 'moment-timezone';
import { ShopifyProxyLoyaltyApplyDto } from '../shopify-proxy/dto/shopify-proxy-loyalty-apply.dto';
import { LoyaltyRedemption } from 'src/enums/loyalty.enum';

export class LoyaltyHelperService {
    constructor() {
        moment.tz.setDefault('Etc/GMT+0');
    }

    // Convert points to cash value based on rebate ratio
    static rebateValueFromPoints = (points: number, ratio: string) => {
        const [rebate, rebasePoint] = ratio.split(':').map(Number);
        return Math.round((points / rebasePoint) * rebate * 100) / 100 || 0;
    };

    static rebateValueFromPointsWithRedemptionType = (
        points: number,
        ratio: string,
        type = null,
        value = null
    ) => {
        if (type === 'points') {
            points = this.adjustCashToMultiplier(points, value);
        }
        let cash = this.rebateValueFromPoints(points, ratio);

        if (type === 'cash') {
            cash = this.adjustCashToMultiplier(cash, value);
        }

        return cash;
    }

    // Convert cash to points based on rebate ratio
    static pointsFromCash = (cash: number, ratio: string) => {
        const [rebate, rebasePoint] = ratio.split(':').map(Number);
        return (cash * rebasePoint) / rebate;
    };

    // Adjust cash to the nearest multiple of the redemption multiplier (if necessary)
    static adjustCashToMultiplier = (cash: number, multiplierValue: number) => {
        const mod = cash % multiplierValue;
        return mod === 0 ? cash : cash - mod;
    };

    // Determine points from cash based on redemption type (cash/points) and multiplier
    static pointsFromCashWithRedemptionType = (
        cash: number,
        ratio: string,
        type = null,
        value = null
    ) => {
        if (type === 'cash') {
            cash = this.adjustCashToMultiplier(cash, value);
        }
        let points = this.pointsFromCash(cash, ratio);
        if (type === 'points') {
            points = this.adjustCashToMultiplier(points, value);
        }

        return points;
    };

    static calculateRedeemableLoyalty(
        userLoyalty: number,
        rebate: string,
        orderCost: ShopifyProxyLoyaltyApplyDto,
        settings: any
    ) {
        const orderTotal = orderCost.subtotalAmount - (orderCost.totalDiscount || 0);
        const {
            minRedeemableLoyaltyPoints = 100,
            maxAllowedRedeemableCashFromPointPercentage = 100,
            maxCashRedeemable = 1000,
            redemptionMultiplier = null,
            minCartValue = 0
        } = settings;
    
        const [multiplierValue, multiplierType] = redemptionMultiplier
            ? redemptionMultiplier.split('|')
            : [null, null];
    
        let maxAllowedCashRedeemable = Math.min(
            maxCashRedeemable,
            (orderTotal * maxAllowedRedeemableCashFromPointPercentage) / 100
        );
    
        if (multiplierType === 'cash') {
            maxAllowedCashRedeemable = this.adjustCashToMultiplier(
                maxAllowedCashRedeemable,
                multiplierValue
            );
        } else if (multiplierType === 'points') {
            maxAllowedCashRedeemable = this.rebateValueFromPointsWithRedemptionType(
                maxAllowedCashRedeemable,
                rebate,
                multiplierType,
                multiplierValue
            );
        }
        let maxRedeemableCash = 0;
        let maxRedeemablePoints = 0;
        const failedRules: string[] = [];
    
        if (userLoyalty > minRedeemableLoyaltyPoints && (orderTotal >= minCartValue || minCartValue === 0)) {
            switch (multiplierType) {
                case 'cash':
                    const redeemableLoyaltyUsingCash = this.calculateRedeemableLoyaltyUsingCash(
                        userLoyalty,
                        rebate,
                        orderTotal,
                        maxAllowedCashRedeemable,
                        multiplierValue
                    );
                    maxRedeemablePoints = redeemableLoyaltyUsingCash.maxRedeemablePoints;
                    maxRedeemableCash = redeemableLoyaltyUsingCash.maxRedeemableCash;
                    break;
                case 'points':
                    const redeemableLoyaltyUsingPoints = this.calculateRedeemableLoyaltyUsingPoints(
                        userLoyalty,
                        rebate,
                        orderTotal,
                        maxAllowedCashRedeemable,
                        multiplierValue
                    );
                    maxRedeemablePoints = redeemableLoyaltyUsingPoints.maxRedeemablePoints;
                    maxRedeemableCash = redeemableLoyaltyUsingPoints.maxRedeemableCash;
                    break;
                default:
                    const redeemableLoyaltyDefault = this.calculateRedeemableLoyaltyDefault(
                        userLoyalty,
                        rebate,
                        orderTotal,
                        maxAllowedCashRedeemable
                    );
                    maxRedeemablePoints = redeemableLoyaltyDefault.maxRedeemablePoints;
                    maxRedeemableCash = redeemableLoyaltyDefault.maxRedeemableCash;
                    break;
            }
        } else if (orderTotal <= minCartValue && minCartValue) {
            maxRedeemablePoints = 0;
            maxRedeemableCash = 0;
            failedRules.push(LoyaltyRedemption.MIN_ORDER_AMOUNT);
        }
    
        if (maxRedeemablePoints < minRedeemableLoyaltyPoints) {
            maxRedeemablePoints = 0;
            maxRedeemableCash = 0;

            failedRules.push(LoyaltyRedemption.MIN_POINTS);
        }
    
        return {
            redeemablePoints: Math.round(maxRedeemablePoints),
            redeemableCash: parseFloat(maxRedeemableCash.toFixed(2)),
            userLoyalty,
            orderTotal,
            balancePayable: orderTotal - maxRedeemableCash,
            maxAllowedRedeemableCashFromPointPercentage,
            maxAllowedCashRedeemable,
            minRedeemableLoyaltyPoints,
            maxCashRedeemable,
            minCartValue,
            failedRules
        };
    }
    

    static calculateRedeemableLoyaltyUsingCash(
        userLoyalty: number,
        rebate: string,
        orderTotal: number,
        maxAllowedCashRedeemable: number,
        multiplierValue: number
    ) {
        let maxRedeemablePoints = 0;
        let maxRedeemableCash = 0;
        if (orderTotal >= multiplierValue) {
            const userLoyaltyToCash = this.rebateValueFromPointsWithRedemptionType(
                userLoyalty,
                rebate,
                'cash',
                multiplierValue
            );
            userLoyalty = this.pointsFromCashWithRedemptionType(userLoyaltyToCash, rebate, 'cash', multiplierValue);
            if (userLoyaltyToCash > 0) {
                if (userLoyaltyToCash >= orderTotal) {
                    maxRedeemablePoints = this.pointsFromCashWithRedemptionType(orderTotal, rebate, 'cash', multiplierValue);
                    maxRedeemableCash = this.rebateValueFromPointsWithRedemptionType(maxRedeemablePoints, rebate, 'cash', multiplierValue);
                    maxRedeemablePoints = this.pointsFromCash(maxRedeemableCash, rebate);
                } else {
                    maxRedeemablePoints = userLoyalty;
                    maxRedeemableCash = userLoyaltyToCash;
                }

                // check max cash redeemable
                if (maxRedeemableCash > maxAllowedCashRedeemable) {
                    maxRedeemableCash = maxAllowedCashRedeemable;
                    maxRedeemablePoints = this.pointsFromCash(
                        maxRedeemableCash,
                        rebate
                    );
                }
            }
        }

        console.log('calculateRedeemableLoyaltyUsingCash -> maxRedeemablePoints', maxRedeemablePoints);

        return {
            maxRedeemablePoints,
            maxRedeemableCash
        };
    }

    static calculateRedeemableLoyaltyUsingPoints(
        userLoyalty: number,
        rebate: string,
        orderTotal: number,
        maxAllowedCashRedeemable: number,
        multiplierValue: number
    ) {
        let maxRedeemablePoints = 0;
        let maxRedeemableCash = 0;
        if (userLoyalty >= multiplierValue) {

            userLoyalty = this.adjustCashToMultiplier(userLoyalty, multiplierValue);
            const userLoyaltyToCash = this.rebateValueFromPointsWithRedemptionType(
                userLoyalty,
                rebate,
                'points',
                multiplierValue
            );
            if (userLoyaltyToCash > 0) {
                if (userLoyaltyToCash >= orderTotal) {
                    maxRedeemablePoints = this.pointsFromCashWithRedemptionType(orderTotal, rebate, 'points', multiplierValue);
                    maxRedeemableCash = this.rebateValueFromPointsWithRedemptionType(maxRedeemablePoints, rebate, 'points', multiplierValue);
                } else {
                    maxRedeemablePoints = userLoyalty;
                    maxRedeemableCash = userLoyaltyToCash;
                }

                // check max cash redeemable
                if (maxRedeemableCash > maxAllowedCashRedeemable) {
                    maxRedeemableCash = maxAllowedCashRedeemable;
                    maxRedeemablePoints = this.pointsFromCash(
                        maxRedeemableCash,
                        rebate
                    );
                }
            }
        }

        console.log('calculateRedeemableLoyaltyUsingPoints -> maxRedeemablePoints', maxRedeemablePoints);

        return {
            maxRedeemablePoints,
            maxRedeemableCash
        };
    }

    static calculateRedeemableLoyaltyDefault(
        userLoyalty: number,
        rebate: string,
        orderTotal: number,
        maxAllowedCashRedeemable: number
    ) {
        let maxRedeemablePoints = 0;
        let maxRedeemableCash = 0;
        const userLoyaltyToCash = this.rebateValueFromPoints(
            userLoyalty,
            rebate
        );
        if (userLoyaltyToCash >= orderTotal) {
            maxRedeemablePoints = this.pointsFromCash(orderTotal, rebate);
            maxRedeemableCash = orderTotal;
        } else {
            maxRedeemablePoints = userLoyalty;
            maxRedeemableCash = userLoyaltyToCash;
        }

        // check max cash redeemable
        if (maxRedeemableCash > maxAllowedCashRedeemable) {
            maxRedeemableCash = maxAllowedCashRedeemable;
            maxRedeemablePoints = this.pointsFromCash(
                maxRedeemableCash,
                rebate
            );
        }

        if (orderTotal > maxRedeemableCash) {
            // Round down redeemable cash to avoid decimal value
            const maxRedeemableCashDecimal = maxRedeemableCash % 1;
            if (!Number.isInteger(maxRedeemableCashDecimal)) {
                maxRedeemableCash = Math.floor(maxRedeemableCash);
                maxRedeemablePoints = this.pointsFromCash(
                    maxRedeemableCash,
                    rebate
                );
            }
        }

        return {
            maxRedeemablePoints,
            maxRedeemableCash
        };
    }
}
