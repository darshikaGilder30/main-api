import { Context, Liquid } from 'liquidjs';
import * as moment from 'moment-timezone';
import { I18nContext } from 'nestjs-i18n';
import * as path from 'path';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';

export class LiquidTemplateService {
    getTemplateEngine(store: StoreDto) {
        const engine: Liquid = new Liquid({
            root: path.resolve(__dirname, '../../views'),
            extname: '.liquid',
            cache: true,
            globals: {
                settings: {
                    ...store.storeIntegrations.shopify.settings,
                    ...(store.storeIntegrations.ascentis?.settings || {}),
                    ...(store.storeIntegrations.stamps?.settings || {})
                }
            }
        });

        engine.registerFilter('money_with_currency', function (value, symbol) {
            if (typeof value === 'string') {
                value = parseFloat(value);
            }
            
            const formatter = new Intl.NumberFormat(this.context.globals['settings'].currencyLocale || 'en-US', {
                currency: this.context.globals['settings'].currencyCode
            });

            const formattedValue = formatter.format(value);

            if (symbol) {
                symbol = symbol.replace('{{amount}}', formattedValue);
                symbol = symbol.replace(
                    '{{amount_with_comma_separator}}',
                    formattedValue
                );
                symbol = symbol.replace(
                    '{{amount_no_decimals_with_comma_separator}}',
                    formattedValue
                );

                return symbol;
            }

            return formattedValue;
        });

        engine.registerFilter(
            'money_with_currency_decimal',
            function (value, symbol) {
                value =
                    typeof value === 'string'
                        ? parseFloat(value).toFixed(2)
                        : value.toFixed(2);
                const formatter = new Intl.NumberFormat(this.context.globals['settings'].currencyLocale || 'en-US', {
                    currency: this.context.globals['settings'].currencyCode
                });

                const formattedValue = formatter.format(value);
                if (symbol) {
                    symbol = symbol.replace('{{amount}}', formattedValue);
                    symbol = symbol.replace(
                        '{{amount_with_comma_separator}}',
                        formattedValue
                    );
                    symbol = symbol.replace(
                        '{{amount_no_decimals_with_comma_separator}}',
                        formattedValue
                    );

                    return symbol;
                }
                return `$${formattedValue}`;
            }
        );

        engine.registerFilter(
            'date',
            (value, format, timezone, fromFormat = null) => {
                if (fromFormat) {
                    value = moment(value, fromFormat);
                } else {
                    value = moment(value);
                }
                if (timezone) {
                    value = value.tz(timezone);
                }

                return value.format(format);
            }
        );

        engine.registerFilter('t', (value, lang, ...args: any[any]) => {
            const options = {};
            if (lang) {
                options['lang'] = lang;
            }
            if (args) {
                options['args'] = args;
            }
            return I18nContext.current().translate(value, options);
        });

        engine.registerFilter('money_with_separators', function (value) {
            if (typeof value === 'string') {
                value = parseFloat(value);
            }
        
            const formatter = new Intl.NumberFormat(this.context.globals['settings'].currencyLocale || 'en-US', {
                currency: this.context.globals['settings'].currencyCode
            });

            const formattedValue = formatter.format(value);
        
            return formattedValue;
        });

        return engine;
    }

    async render(store: StoreDto, file: string, data: any) {
        try {
            const html = await this.getTemplateEngine(store).renderFile(file, {
                storeWwwUrl: `https://www.${store.storeIntegrations.shopify.settings.shopDomain}`,
                storeWwwUrlName: `www.${store.storeIntegrations.shopify.settings.shopDomain}`,
                storeUrl: `https://${store.storeIntegrations.shopify.settings.shopDomain}`,
                storeName: store.storeIntegrations.shopify.settings.countryName,
                ...data,
                settings: {
                    ...store.storeIntegrations.shopify.settings,
                    ...(store.storeIntegrations.ascentis?.settings || {}),
                    ...(store.storeIntegrations.stamps?.settings || {})
                }
            });
            return html;
        } catch (err) {
            console.error(err);
        }

        return null;
    }

    async renderHtml(store: StoreDto, htmlString: string, data: any = {}) {
        try {
            const html = await this.getTemplateEngine(store).parseAndRender(
                htmlString,
                {
                    storeWwwUrl: `https://www.${store.storeIntegrations.shopify.settings.shopDomain}`,
                    storeWwwUrlName: `www.${store.storeIntegrations.shopify.settings.shopDomain}`,
                    storeUrl: `https://${store.storeIntegrations.shopify.settings.shopDomain}`,
                    storeName:
                        store.storeIntegrations.shopify.settings.countryName,
                    ...data,
                    settings: {
                        ...store.storeIntegrations.shopify.settings,
                        ...(store.storeIntegrations.ascentis?.settings || {}),
                        ...(store.storeIntegrations.stamps?.settings || {})
                    }
                }
            );
            return html;
        } catch (err) {
            console.error(err);
        }

        return null;
    }
}
