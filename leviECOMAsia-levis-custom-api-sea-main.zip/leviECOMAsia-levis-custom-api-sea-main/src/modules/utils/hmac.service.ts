import * as crypto from 'crypto';

export class HmacService {
    static isValidHmac(
        query: any,
        clientSecret: string,
        type = 'signature'
    ): boolean {
        const signature = query[type];

        if (signature) {
            let queryParams = query;
            delete queryParams[type];
            queryParams = Object.keys(queryParams)
                .sort()
                .map((key) => `${key}=${queryParams[key]}`)
                .join(type === 'signature' ? '' : '&');

            const generatedHash = crypto
                .createHmac('sha256', clientSecret)
                .update(queryParams.toString())
                .digest('hex');

            if (generatedHash !== signature) return false;

            return true;
        }

        return false;
    }

    static mutipassSign(data: any, clientSecret: string) {
        return crypto
            .createHmac('sha256', clientSecret)
            .update(data)
            .digest();
    }
}
