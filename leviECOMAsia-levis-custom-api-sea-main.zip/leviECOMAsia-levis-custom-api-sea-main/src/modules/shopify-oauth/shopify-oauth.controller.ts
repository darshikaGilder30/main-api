import { HttpService } from '@nestjs/axios';
import { Controller, Get, HttpCode, Query, Redirect } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { lastValueFrom } from 'rxjs';
import { GetStore } from 'src/decorators/store.decorator';
import { StoreIntegrationsService } from 'src/entities/store-integrations/store-integrations.service';
import { Store } from 'src/entities/stores/stores.entity';
import { StoreIntegrationTypeEnum } from 'src/enums/store-integrations-type.enum';
import { ShopifyAdminApiService } from '../shopify-admin-api/shopify-admin-api.service';
import { StoresService } from 'src/entities/stores/stores.service';
import { StoreIntegrationAcessessService } from 'src/entities/store-integration-accesses/store-integration-accesses.service';
import { ShopifyOauthService } from './shopify-oauth.service';
import { EncryptionService } from '../utils/encryption.service';

@Controller('shopify-oauth')
export class ShopifyOauthController {
    constructor(
        private configService: ConfigService,
        private httpService: HttpService,
        private storeService: StoresService,
        private storeIntegrationsService: StoreIntegrationsService,
        private shopifyAdminApiService: ShopifyAdminApiService,
        private storeIntegrationAccessesService: StoreIntegrationAcessessService,
        private shopifyOauthService: ShopifyOauthService
    ) {}

    @Get('init')
    @HttpCode(302)
    @Redirect()
    async init(@Query() query: any) {
        return {
            url: `https://${
                query.shop
            }/admin/oauth/authorize?client_id=${this.configService.get(
                'shopify.appProxy.clientId'
            )}&scope=${this.configService
                .get('shopify.appProxy.scopes')
                .join(',')}&redirect_uri=${this.configService.get(
                'apiUrl'
            )}/shopify-oauth/redirect&state={nonce}&grant_options[]={access_mode}`
        };
    }

    @Get('redirect')
    @HttpCode(302)
    @Redirect()
    async oauthRedirect(@GetStore() store: Store, @Query() query: any) {
        const response = await lastValueFrom(
            this.httpService.post(
                `https://${query.shop}/admin/oauth/access_token`,
                {
                    client_id: this.configService.get(
                        'shopify.appProxy.clientId'
                    ),
                    client_secret: this.configService.get(
                        'shopify.appProxy.clientSecret'
                    ),
                    code: query.code
                }
            )
        );

        const storeId = store.id;
        store = await this.storeService.findByShop(store.shop);
        let storeInfo: any = store;
        let storeIntegrations = {};
        for (const storeIntegration of store.storeIntegrations) {
            storeIntegrations[storeIntegration.type] = storeIntegration;
        }
        storeInfo.storeIntegrations = storeIntegrations;
        const otherIntegrations = [
            StoreIntegrationTypeEnum.Ascentis,
            StoreIntegrationTypeEnum.SMS,
            StoreIntegrationTypeEnum.Email,
            StoreIntegrationTypeEnum.Referrer
        ];
        if (storeInfo.storeIntegrations[StoreIntegrationTypeEnum.Shopify]) {
            const shopifyIntegration =
                storeInfo.storeIntegrations[StoreIntegrationTypeEnum.Shopify];
            let credentials = {
                ...(shopifyIntegration.credentials || {}),
                ...response.data
            };
            shopifyIntegration.credentials = credentials;
            await this.storeIntegrationsService.update(shopifyIntegration);

            if (shopifyIntegration.settings.countryCode === 'TH') {
                otherIntegrations.push(StoreIntegrationTypeEnum.Line);
            }
        } else {
            await this.storeIntegrationsService.create({
                storeId: storeId,
                type: StoreIntegrationTypeEnum.Shopify,
                credentials: response.data,
                active: false,
                default: true,
                settings: {}
            });
        }

        // Other integration enable
        for (const otherIntegration of otherIntegrations) {
            if (!storeInfo.storeIntegrations[otherIntegration]) {
                const integration = await this.storeIntegrationsService.create({
                    storeId: storeId,
                    type: otherIntegration,
                    credentials: {},
                    active: false,
                    default: true,
                    settings: {}
                });

                if (otherIntegration === StoreIntegrationTypeEnum.Line) {
                    const lineCredentials =
                        await this.storeIntegrationAccessesService.generateAccess(
                            integration
                        );
                    integration.credentials = {
                        clientId: lineCredentials.clientId,
                        clientSecret: EncryptionService.decrypt(lineCredentials.clientSecret)
                    };
                    await this.storeIntegrationsService.update(integration);
                }
            }
        }

        store = await this.storeService.findByShop(store.shop);
        storeInfo = store;
        storeIntegrations = {};
        for (const integration of store.storeIntegrations) {
            storeIntegrations[integration.type] = integration;
        }
        storeInfo.storeIntegrations = storeIntegrations;

        // Update store settings
        const shopProperties =
            await this.shopifyAdminApiService.getShopProperties(storeInfo);
        const storeSettings = {
            name: shopProperties.data?.name,
            currency: shopProperties.data?.currencyCode,
            currencyFormats: shopProperties.data?.currencyFormats,
            timezone: shopProperties.data?.ianaTimezone
        };
        const shopifyStore =
            storeInfo.storeIntegrations[StoreIntegrationTypeEnum.Shopify];
        shopifyStore.settings = {
            ...shopifyStore.settings,
            ...storeSettings
        };

        const metaDefinitions =
            this.shopifyAdminApiService.generateMetadefinitions(storeInfo);
        const customerMetafields =
            await this.shopifyAdminApiService.getMetafieldDefinitions(
                storeInfo,
                'CUSTOMER'
            );
        const locationMetafields =
            await this.shopifyAdminApiService.getMetafieldDefinitions(
                storeInfo,
                'LOCATION'
            );
        for (const metaDefinition of metaDefinitions) {
            
            if (
                customerMetafields.data.find(
                    (metafield: any) =>
                        metafield.key === metaDefinition.key &&
                        metafield.namespace === metaDefinition.namespace
                )
            ) {
                continue;
            }

            if (
                locationMetafields.data.find(
                    (metafield: any) =>
                        metafield.key === metaDefinition.key &&
                        metafield.namespace === metaDefinition.namespace
                )
            ) {
                continue;
            }

            if (metaDefinition.namespace === 'facts') {
                // const response =
                //     await this.shopifyAdminApiService.enableStandardMetafieldDefinition(
                //         storeInfo,
                //         metaDefinition
                //     );
            } else {
                const response =
                    await this.shopifyAdminApiService.createMetafieldDefinition(
                        storeInfo,
                        metaDefinition
                    );
            }
        }
        await this.shopifyOauthService.addRedTabLoyaltyDiscount(storeInfo);
        await this.shopifyOauthService.addPaymentCustomization(storeInfo);
        await this.shopifyOauthService.addWebhooks(storeInfo);

        await this.storeIntegrationsService.update(shopifyStore);

        return {
            url: `https://${query.shop}/admin/apps?shop=${query.shop}`
        };
    }
}
