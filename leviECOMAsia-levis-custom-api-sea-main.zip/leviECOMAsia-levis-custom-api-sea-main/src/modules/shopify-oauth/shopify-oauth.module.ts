import { MiddlewareConsumer, Module } from '@nestjs/common';
import { ShopifyOauthController } from './shopify-oauth.controller';
import { HttpModule } from '@nestjs/axios';
import { ConfigModule } from '@nestjs/config';
import { ShopifyProxySignatureValidateMiddleware } from 'src/middlewares/shopify-proxy-signature-validate/shopify-proxy-signature-validate.middleware';
import { StoreIntegrationsModule } from 'src/entities/store-integrations/store-integrations.module';
import { StoreMiddleware } from 'src/middlewares/store/store.middleware';
import { StoresModule } from 'src/entities/stores/stores.module';
import { ShopifyAdminApiModule } from '../shopify-admin-api/shopify-admin-api.module';
import { CacheHelperModule } from '../utils/cache/cache-helper.module';
import { StoreIntegrationAccessesModule } from 'src/entities/store-integration-accesses/store-integration-accesses.module';
import { ShopifyOauthService } from './shopify-oauth.service';
import { CustomLoggerService } from '../utils/custom-logger.service';

@Module({
    imports: [
        HttpModule.registerAsync({
            imports: [ConfigModule],
            useFactory: async () => ({
                timeout: 120000
            })
        }),
        CacheHelperModule,
        StoresModule,
        StoreIntegrationsModule,
        ShopifyAdminApiModule,
        StoreIntegrationAccessesModule
    ],
    providers: [ShopifyOauthService, CustomLoggerService],
    controllers: [ShopifyOauthController]
})
export class ShopifyOauthModule {
    configure(consumer: MiddlewareConsumer) {
        consumer.apply(ShopifyProxySignatureValidateMiddleware).forRoutes(ShopifyOauthController);
        consumer.apply(StoreMiddleware).forRoutes(ShopifyOauthController);
    }
}
