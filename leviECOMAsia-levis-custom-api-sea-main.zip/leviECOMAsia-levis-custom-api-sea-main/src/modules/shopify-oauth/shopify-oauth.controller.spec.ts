import { Test, TestingModule } from '@nestjs/testing';
import { ShopifyOauthController } from './shopify-oauth.controller';

describe('ShopifyOauthController', () => {
  let controller: ShopifyOauthController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ShopifyOauthController],
    }).compile();

    controller = module.get<ShopifyOauthController>(ShopifyOauthController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
