import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as moment from 'moment-timezone';
import { ShopifyAdminApiService } from '../shopify-admin-api/shopify-admin-api.service';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { ShopifyAdminRestApiService } from '../shopify-admin-api/shopify-admin-rest-api.service';
import { CustomLoggerService } from '../utils/custom-logger.service';

@Injectable()
export class ShopifyOauthService {
    private logger : CustomLoggerService
    private webhooks = {
        'graphql': [
            'RETURNS_CLOSE'
        ],
        'rest': [
            'orders/create',
            'orders/cancelled',
            'orders/paid',
            'refunds/create',
            'fulfillments/update',
            'fulfillments/create',
            'orders/updated',
            'shop/update',
            'orders/fulfilled',
            'orders/partially_fulfilled',
            'customers/update'
        ]
    };
    constructor(
        private configService: ConfigService,
        private shopifyAdminApiService: ShopifyAdminApiService,
        private shopifyAdminRestApiService: ShopifyAdminRestApiService,
        private customLoggerService: CustomLoggerService
    ) {
        this.customLoggerService.setContext(ShopifyOauthService.name);
        this.logger = customLoggerService;
        moment.tz.setDefault('Etc/GMT+0');
    }

    async addRedTabLoyaltyDiscount(store: StoreDto) {
        const orderDiscountFunction = await this.shopifyAdminApiService.getCustomAppFunction(store, 'order_discounts');

        if (orderDiscountFunction.success && orderDiscountFunction.data) {
            const discount = await this.shopifyAdminApiService.createRedTabFunctionDiscount(store, orderDiscountFunction.data.id);
            this.logger.log(`${store.shop} : Redtab Discount created: ${orderDiscountFunction.data.id}`);
            return discount;
        }

        return null;
    }

    async addPaymentCustomization(store: StoreDto) {
        const paymentCustomizationFunction = await this.shopifyAdminApiService.getCustomAppFunction(store, 'payment_customization');

        if (paymentCustomizationFunction.success && paymentCustomizationFunction.data) {
            let paymentCustomization = await this.shopifyAdminApiService.getPaymentCustomization(store, paymentCustomizationFunction.data.id);
            if (paymentCustomization.success && paymentCustomization.data) {
                this.logger.log(`${store.shop} : Payment Customization already exists: ${paymentCustomization.data.id} : ${paymentCustomizationFunction.data.id}`);
                return paymentCustomization;
            }

            paymentCustomization = await this.shopifyAdminApiService.createPaymentCustomizationFunction(store, paymentCustomizationFunction.data.id);
            this.logger.log(`${store.shop} : Payment Customization created: ${paymentCustomizationFunction.data.id}`);
            return paymentCustomization;
        }

        return null;
    }

    async addWebhooks(store: StoreDto) {
        const webhooks = await this.shopifyAdminRestApiService.getWebhooks(store);
        for (const topic of this.webhooks.rest) {
            if (webhooks.data?.find((webhook) => webhook.topic === topic && webhook.address === this.configService.get('shopify.appProxy.webhookUrl'))) {
                this.logger.log(`${store.shop} : Webhook already exists: ${topic}`);
                continue;
            }
            await this.shopifyAdminRestApiService.createWebhook(store, topic, this.configService.get('shopify.appProxy.webhookUrl'), 'json');
        }
    }
}
