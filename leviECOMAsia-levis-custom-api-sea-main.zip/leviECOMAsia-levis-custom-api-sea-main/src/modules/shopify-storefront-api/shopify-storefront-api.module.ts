import { Module } from '@nestjs/common';
import { ShopifyStorefrontApiService } from './shopify-storefront-api.service';
import { CustomLoggerService } from '../utils/custom-logger.service';

@Module({
    providers: [ShopifyStorefrontApiService, CustomLoggerService],
    exports: [ShopifyStorefrontApiService]
})
export class ShopifyStorefrontApiModule {}
