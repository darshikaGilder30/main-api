import { Inject, Injectable, Logger } from '@nestjs/common';
import '@shopify/shopify-api/adapters/node';
import { shopifyApi, ApiVersion, Session } from '@shopify/shopify-api';
import { ConfigService } from '@nestjs/config';
import { MuleServiceResponse } from '../mule/interfaces/mule-general.interface';
import { ShopifyProxyRegisterDto } from '../shopify-proxy/dto/shopify-proxy-auth-register.dto';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { REQUEST } from '@nestjs/core';
import { Request } from 'express';
import { ShopifyProxyCustomerAddressDto } from '../shopify-proxy/dto/shopify-proxy-customer-address.dto';
import { ShopifyProxyCustomerAddressUpdateDto } from '../shopify-proxy/dto/shopify-proxy-customer-address-update.dto';
import * as jsonwebtoken from 'jsonwebtoken';
import { I18nValidationException } from 'nestjs-i18n';
import { CustomLoggerService } from '../utils/custom-logger.service';
@Injectable()
export class ShopifyStorefrontApiService {
    private logger: CustomLoggerService;
    constructor(
        private configService: ConfigService,
        @Inject(REQUEST) private request: Request,
        private customLoggerService: CustomLoggerService
    ) { 
        this.customLoggerService.setContext(ShopifyStorefrontApiService.name);
        this.logger = this.customLoggerService
    }

    private getClientIp() {
        const ip = this.request.headers['x-shopify-client-ip'] || this.request.headers['x-forwarded-for'];
        return ip;
    }

    getClient(store: StoreDto) {
        const client = shopifyApi({
            apiKey: this.configService.get('shopify.appProxy.clientId'),
            apiSecretKey: this.configService.get(
                'shopify.appProxy.clientSecret'
            ),
            scopes: this.configService.get('shopify.appProxy.scopes'),
            adminApiAccessToken:
                store.storeIntegrations.shopify.credentials.access_token,
            hostName: store.shop,
            hostScheme: 'https',
            apiVersion: ApiVersion.October23,
            isEmbeddedApp: false
        });

        const session = new Session({
            id: '',
            shop: store.shop,
            state: '',
            isOnline: false,
            accessToken:
                store.storeIntegrations.shopify.credentials.access_token
        });
        return new client.clients.Storefront({
            session,
            apiVersion: ApiVersion.October23
        });
    }

    verifyCustomerToken(store: StoreDto, token: string) {
        return jsonwebtoken.decode(token);
        // const tokenPayload = this.client(store).session.decodeSessionToken(token, {
        //     checkAudience: true
        // });
    }

    async login(store: StoreDto, username: string, password: string) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            const data = await this.getClient(store).query({
                data: `mutation customerAccessTokenCreate {
                    customerAccessTokenCreate(input: {email: "${username}", password: "${password}"}) {
                      customerAccessToken {
                        accessToken
                      }
                      customerUserErrors {
                        message
                      }
                    }
                }`,
                extraHeaders: {
                    'Shopify-Storefront-Buyer-IP': this.getClientIp()
                }
            });

            result.data =
                data?.body[
                    'data'
                ].customerAccessTokenCreate.customerAccessToken;
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
        }

        return result;
    }

    async multiPassLogin(store: StoreDto, token: string) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            const data = await this.getClient(store).query({
                data: `mutation customerAccessTokenCreate {
                    customerAccessTokenCreate(input: {multipassToken: "${token}"}) {
                      customerAccessToken {
                        accessToken
                      }
                      customerUserErrors {
                        message
                      }
                    }
                }`,
                extraHeaders: {
                    'Shopify-Storefront-Buyer-IP': this.getClientIp()
                }
            });

            result.data =
                data?.body[
                    'data'
                ].customerAccessTokenCreate.customerAccessToken;
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
        }

        return result;
    }

    async createCustomer(
        store: StoreDto,
        shopifyProxyRegisterDto: ShopifyProxyRegisterDto
    ) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            const data = await this.getClient(store).query({
                data: {
                    query: `mutation customerCreate($input: CustomerCreateInput!) {
                    customerCreate(input: $input) {
                      customer {
                        id
                        firstName
                        lastName
                        email
                        phone
                        acceptsMarketing
                      }
                      customerUserErrors {
                        field
                        message
                        code
                      }
                    }
                  }`,
                    variables: {
                        input: {
                            firstName: shopifyProxyRegisterDto.firstName,
                            lastName: shopifyProxyRegisterDto.lastName,
                            email: shopifyProxyRegisterDto.email,
                            phone: `${store.storeIntegrations.shopify.settings.callingCode}${shopifyProxyRegisterDto.phone}`,
                            password: shopifyProxyRegisterDto.password,
                            acceptsMarketing: shopifyProxyRegisterDto.emailOptIn
                                ? true
                                : false
                        }
                    }
                },
                extraHeaders: {
                    'Shopify-Storefront-Buyer-IP': this.getClientIp()
                }
            });
            result.data = data?.body['data'].customerCreate?.customer;
            if (!result.data) {
                const error = data?.body['data'].customerCreate?.customerUserErrors.length ?  data?.body['data'].customerCreate?.customerUserErrors[0] : null;

                if (error?.code === 'INVALID' && error?.field.includes('phone')) {
                    this.logger.warn(`Invalid phone number: ${shopifyProxyRegisterDto.phone}`)
                    throw new I18nValidationException(
                        [
                            {
                                property: 'phone',
                                constraints: {
                                    isPhoneNumber: 'validation.invalid_phone'
                                }
                            }
                        ]
                    );
                }

                throw new Error(
                    data?.body[
                        'data'
                    ].customerCreate?.customerUserErrors[0]?.message
                );
            }
            result.success = true;
        } catch (error) {
            result.message = error.message;

            if (error instanceof I18nValidationException) {
                throw error;
            }

            this.logger.error(error);
        }

        return result;
    }

    async customerUpdatePassword(
        store: StoreDto,
        customerAccessToken: string,
        password: string
    ) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            const data = await this.getClient(store).query({
                data: {
                    query: `mutation customerUpdate($customerAccessToken: String!, $customer: CustomerUpdateInput!) {
                    customerUpdate(customerAccessToken: $customerAccessToken, customer: $customer) {
                      customer {
                        id
                      }
                      customerAccessToken {
                        accessToken
                      }
                      customerUserErrors {
                        field
                        message
                        code
                      }
                    }
                  }`,
                    variables: {
                        customerAccessToken,
                        customer: {
                            password
                        }
                    }
                },
                extraHeaders: {
                    'Shopify-Storefront-Buyer-IP': this.getClientIp()
                }
            });
            result.data = data?.body['data'].customerUpdate?.customer;
            if (!result.data) {
                throw new Error(
                    data?.body[
                        'data'
                    ].customerUpdate?.customerUserErrors[0]?.message
                );
            }
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
        }

        return result;
    }

    async forgotPassword(store: StoreDto, email: string) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            const data = await this.getClient(store).query({
                data: {
                    query: `mutation customerRecover($email: String!) {
                    customerRecover(email: $email) {
                      customerUserErrors {
                        field
                        message
                        code
                      }
                    }
                  }`,
                    variables: {
                        email
                    }
                },
                extraHeaders: {
                    'Shopify-Storefront-Buyer-IP': this.getClientIp()
                }
            });
            result.data = data?.body['data'].customerRecover;
            if (!result.data) {
                throw new Error(
                    data?.body[
                        'data'
                    ].customerRecover?.customerUserErrors[0]?.message
                );
            }
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
        }

        return result;
    }

    async customerAccessTokenCreateWithMultipass(
        store: StoreDto,
        token: string
    ) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            const data = await this.getClient(store).query({
                data: {
                    query: `mutation customerAccessTokenCreateWithMultipass($multipassToken: String!) {
                    customerAccessTokenCreateWithMultipass(multipassToken: $multipassToken) {
                      customerAccessToken {
                        accessToken
                      }
                      customerUserErrors {
                        field
                        message
                        code
                      }
                    }
                  }`,
                    variables: {
                        multipassToken: token
                    }
                },
                extraHeaders: {
                    'Shopify-Storefront-Buyer-IP': this.getClientIp()
                }
            });
            result.data =
                data?.body[
                    'data'
                ].customerAccessTokenCreateWithMultipass?.customerAccessToken;
            if (!result.data) {
                throw new Error(
                    data?.body[
                        'data'
                    ].customerAccessTokenCreateWithMultipass?.customerUserErrors[0]?.message
                );
            }
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
        }

        return result;
    }

    async createAddress(
        store: StoreDto,
        customerAccessToken: string,
        shopifyProxyCustomerAddressDto: ShopifyProxyCustomerAddressDto
    ) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            const data = await this.getClient(store).query({
                data: {
                    query: `mutation customerAddressCreate($address: MailingAddressInput!, $customerAccessToken: String!) {
                      customerAddressCreate(address: $address, customerAccessToken: $customerAccessToken) {
                      customerAddress {
                        id
                        address1
                        address2
                        city
                        country
                        firstName
                        lastName
                        phone
                        province
                        zip
                      }
                      customerUserErrors {
                        field
                        message
                        code
                      }
                    }
                  }`,
                    variables: {
                        address: {
                            address1:
                                shopifyProxyCustomerAddressDto.address1 || '',
                            address2:
                                shopifyProxyCustomerAddressDto.address2 || '',
                            city: shopifyProxyCustomerAddressDto.city || '',
                            company:
                                shopifyProxyCustomerAddressDto.company || '',
                            country:
                                shopifyProxyCustomerAddressDto.country || '',
                            firstName:
                                shopifyProxyCustomerAddressDto.firstName || '',
                            lastName:
                                shopifyProxyCustomerAddressDto.lastName || '',
                            phone: shopifyProxyCustomerAddressDto.phone || '',
                            province:
                                shopifyProxyCustomerAddressDto.province || '',
                            zip: shopifyProxyCustomerAddressDto.zip || ''
                        },
                        customerAccessToken: customerAccessToken
                    }
                },
                extraHeaders: {
                    'Shopify-Storefront-Buyer-IP': this.getClientIp()
                }
            });
            result.data =
                data?.body['data'].customerAddressCreate?.customerAddress;
            if (!result.data) {
                throw new Error(
                    data?.body[
                        'data'
                    ].customerAddressCreate?.customerUserErrors[0]?.message
                );
            }
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
        }

        return result;
    }

    async updateAddress(
        store: StoreDto,
        customerAccessToken: string,
        shopifyProxyCustomerAddressUpdateDto: ShopifyProxyCustomerAddressUpdateDto
    ) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        const addressId = shopifyProxyCustomerAddressUpdateDto?.id?.replace(
            'gid://shopify/MailingAddress/',
            ''
        );

        try {
            const data = await this.getClient(store).query({
                data: {
                    query: `mutation customerAddressUpdate($address: MailingAddressInput!, $customerAccessToken: String!, $id: ID!) {
                      customerAddressUpdate(address: $address, customerAccessToken: $customerAccessToken, id: $id) {
                      customerAddress {
                        id
                        address1
                        address2
                        city
                        country
                        firstName
                        lastName
                        phone
                        province
                        zip
                      }
                      customerUserErrors {
                        field
                        message
                        code
                      }
                    }
                  }`,
                    variables: {
                        address: {
                            address1:
                                shopifyProxyCustomerAddressUpdateDto.address1 ||
                                '',
                            address2:
                                shopifyProxyCustomerAddressUpdateDto.address2 ||
                                '',
                            city:
                                shopifyProxyCustomerAddressUpdateDto.city || '',
                            company:
                                shopifyProxyCustomerAddressUpdateDto.company ||
                                '',
                            country:
                                shopifyProxyCustomerAddressUpdateDto.country ||
                                '',
                            firstName:
                                shopifyProxyCustomerAddressUpdateDto.firstName ||
                                '',
                            lastName:
                                shopifyProxyCustomerAddressUpdateDto.lastName ||
                                '',
                            phone:
                                shopifyProxyCustomerAddressUpdateDto.phone ||
                                '',
                            province:
                                shopifyProxyCustomerAddressUpdateDto.province ||
                                '',
                            zip: shopifyProxyCustomerAddressUpdateDto.zip || ''
                        },
                        customerAccessToken: customerAccessToken,
                        id: `gid://shopify/MailingAddress/${addressId}?model_name=CustomerAddress`
                    }
                },
                extraHeaders: {
                    'Shopify-Storefront-Buyer-IP': this.getClientIp()
                }
            });

            result.data = data?.body['data'].customerAddressUpdate?.customerAddress;
            if (!result.data) {
                throw new Error(
                    data?.body[
                        'data'
                    ].customerAddressUpdate?.customerUserErrors[0]?.message
                );
            }
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
        }

        return result;
    }
}
