import { Test, TestingModule } from '@nestjs/testing';
import { ShopifyStorefrontApiService } from './shopify-storefront-api.service';

describe('ShopifyStorefrontApiService', () => {
  let service: ShopifyStorefrontApiService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ShopifyStorefrontApiService],
    }).compile();

    service = module.get<ShopifyStorefrontApiService>(ShopifyStorefrontApiService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
