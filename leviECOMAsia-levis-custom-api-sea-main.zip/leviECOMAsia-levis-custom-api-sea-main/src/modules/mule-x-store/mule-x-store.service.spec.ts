import { Test, TestingModule } from '@nestjs/testing';
import { MuleXStoreService } from './mule-x-store.service';

describe('MuleXStoreService', () => {
  let service: MuleXStoreService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [MuleXStoreService],
    }).compile();

    service = module.get<MuleXStoreService>(MuleXStoreService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
