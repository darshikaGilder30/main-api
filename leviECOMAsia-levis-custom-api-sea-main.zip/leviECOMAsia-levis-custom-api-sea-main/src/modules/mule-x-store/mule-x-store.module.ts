import { Module } from '@nestjs/common'
import { MuleXStoreService } from './mule-x-store.service'
import { HttpModule } from '@nestjs/axios'
import { ConfigModule, ConfigService } from '@nestjs/config'
import { CacheHelperModule } from '../utils/cache/cache-helper.module'
import { CustomerCreateUpdateXStoreListener } from './customer-create-update-xstore.event'
import { ShopifyAdminApiModule } from '../shopify-admin-api/shopify-admin-api.module'
import { CustomersModule } from 'src/entities/customers/customers.module'
import { CustomLoggerService } from '../utils/custom-logger.service'

@Module({
    imports: [
        HttpModule.registerAsync({
            imports: [ConfigModule],
            useFactory: async (configService) => ({
                timeout: 120000,
            }),
            inject: [ConfigService],
        }),
		CacheHelperModule,
        CustomersModule,
        ShopifyAdminApiModule
    ],
    providers: [MuleXStoreService, CustomerCreateUpdateXStoreListener, CustomLoggerService],
	exports: [MuleXStoreService],
})
export class MuleXStoreModule {}
