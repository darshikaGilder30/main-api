import { HttpService } from '@nestjs/axios'
import { Injectable } from '@nestjs/common'
import { StoreDto } from 'src/entities/stores/dto/stores.dto'
import { lastValueFrom } from 'rxjs'
import { MuleServiceResponse } from '../mule/interfaces/mule-general.interface'
import { CacheHelper } from '../utils/cache/cache-helper.service'
import { AuthUserInfoTransformer } from '../shopify-proxy/transformers/auth-user-info.transformer'
import { CustomLoggerService } from '../utils/custom-logger.service'

@Injectable()
export class MuleXStoreService {
    private logger: CustomLoggerService;
    
    constructor(
        private httpService: HttpService, 
        private cacheHelper: CacheHelper,
        private customLoggerService: CustomLoggerService
    ) {
        this.customLoggerService.setContext(MuleXStoreService.name);
        this.logger = customLoggerService;
        this.httpService.axiosRef.interceptors.request.clear()
        this.httpService.axiosRef.interceptors.request.use(config => {
            this.logger.debug(`Mule XStore Request: ${JSON.stringify(config.data)}`);
            return config;
        });
    }

    private getRequestDetails(store: StoreDto) {
        return {
            headers: {
                'Content-Type': 'application/xml',
                client_id: store.storeIntegrations.xstore.credentials.muleClientId,
                client_secret: store.storeIntegrations.xstore.credentials.muleClientSecret,
            },
            url: store.storeIntegrations.xstore.credentials.muleBaseUrl
        }
    }

    async createOrUpdateMember(
        store: StoreDto,
        customer: AuthUserInfoTransformer
    ) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false,
        }
        const xml = `<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" xmlns:v3="http://v3_1.customer.webservices.csx.dtv.com/">
        <SOAP-ENV:Body>
            <v3:addOrUpdateCustomer>
                <customerData>
                    <RetailStoreID>${customer.source || store.storeIntegrations.xstore.settings.retailStore}</RetailStoreID>
                    <EntityInformation>
                        <Individual>
                            <Name>
                                <Name Location="First">${
                                    customer.firstName
                                }</Name>
                                <Name Location="Last">${
                                    customer.lastName
                                }</Name>
                            </Name>
                            <ContactInformation>
                                <Address>
                                    <Country/>
                                    <PostalCode/>
                                </Address>
                                <EMail>
                                    <EMailAddress>${
                                        customer.email
                                    }</EMailAddress>
                                </EMail>
                                <Telephone>
                                    <PhoneNumber>${
                                        store.storeIntegrations.shopify.settings
                                            .callingCode.replace('+', '')
                                    }${customer.phone}</PhoneNumber>
                                    <Extension/>
                                </Telephone>
                            </ContactInformation>
                            <PersonalSummary>
                                <GenderType>${
                                    customer.gender === 'Male'
                                        ? 'M'
                                        : customer.gender === 'Female'
                                        ? 'F'
                                        : 'D'
                                }</GenderType>
                                <BirthDate>${customer.dob}</BirthDate>
                            </PersonalSummary>
                        </Individual>
                    </EntityInformation>
                    <AlternateKey TypeCode="${store.storeIntegrations.xstore.settings.typeCode}">
                        <AlternateID>${customer.membershipId}</AlternateID>
                    </AlternateKey>
                </customerData>
                <securityUserId>${store.storeIntegrations.xstore.settings.securityUserId}</securityUserId>
            </v3:addOrUpdateCustomer>
        </SOAP-ENV:Body>
        </SOAP-ENV:Envelope>`
        const requestDetails = this.getRequestDetails(store)
        
        try {
            const response = await lastValueFrom(
                this.httpService.post(`${requestDetails.url}/createMember`, xml, {
                    headers: requestDetails.headers,
                })
            )
        
            result.success = true
            result.message = 'Member created successfully'
            result.data = response.data
        } catch (error) {
            result.message = error.message
            this.logger.error(`${store.id}: Member creation failed: ${error.message} ${JSON.stringify(error?.response?.data)}`)
            const attempt: number = await this.cacheHelper.get(
                `${customer.membershipId}-x-store-member-creation`
            )
            await this.cacheHelper.set(
                `${customer.membershipId}-x-store-member-creation`,
                (+attempt || 0) + 1,
                300
            )

            if (attempt < 3) {
                return await this.createOrUpdateMember(store, customer)
            }

            this.cacheHelper.del(`${customer.membershipId}-x-store-member-creation`)
        }
        
        return result
    }
}
