import { Injectable, Logger } from '@nestjs/common'
import { OnEvent } from '@nestjs/event-emitter'
import { ShopifyAdminApiService } from 'src/modules/shopify-admin-api/shopify-admin-api.service'
import { StoreDto } from 'src/entities/stores/dto/stores.dto'
import { plainToInstance } from 'class-transformer'
import { ShopifyCustomer } from 'src/modules/shopify-admin-api/interfaces/shopify-customer.interface'
import { MuleXStoreService } from 'src/modules/mule-x-store/mule-x-store.service'
import { CustomersService } from 'src/entities/customers/customers.service'
import { AuthUserInfoTransformer } from '../shopify-proxy/transformers/auth-user-info.transformer'
import { CustomLoggerService } from '../utils/custom-logger.service'

@Injectable()
export class CustomerCreateUpdateXStoreListener {
    private logger : CustomLoggerService
    constructor(
        private muleXStoreService: MuleXStoreService,
        private shopifyAdminApiService: ShopifyAdminApiService,
        private customerService: CustomersService,
        private customLoggerService: CustomLoggerService
    ) {
        this.customLoggerService.setContext(CustomerCreateUpdateXStoreListener.name);
        this.logger = customLoggerService;
    }

    @OnEvent('customer.created', { async: true })
    async handleCustomerCreateUpdateXStoreEvent(data: {
        data: {
            customerId: string
        }
        store: StoreDto
    }) {
        if (data.store.storeIntegrations.xstore?.active) {
            this.logger.debug(
                `${data.store.id}:Processing customer update event`
            )
            const store = data.store

            const shopifyCustomer =
                await this.shopifyAdminApiService.getCustomer(
                    store,
                    data.data.customerId
                )

            if (shopifyCustomer.success && shopifyCustomer.data) {
                const shopifyCustomerData = this.getUserInfo(
                    store,
                    shopifyCustomer.data
                )

                if (shopifyCustomerData.membershipId) {

                    const existingCustomer = await this.customerService.updateOrCreate(
                        store,
                        shopifyCustomerData,
                        'xStore'
                    )
                    if (existingCustomer && this.customerService.isDataModfied(existingCustomer, shopifyCustomerData, ['firstName', 'lastName', 'email', 'phone', 'gender', 'dob', 'membershipId'])) {
                        this.logger.debug(
                            `${store.id}:Updating customer on xStore ${shopifyCustomerData.email}`
                        )
                        const response = await this.muleXStoreService.createOrUpdateMember(
                            store,
                            shopifyCustomerData
                        )

                        if (response.success && response.data) {
                            existingCustomer.lastProcessedStatus = 'success'
                            existingCustomer.rawData = shopifyCustomerData
                            this.logger.debug(
                                `${store.id}:Member updated on xStore ${JSON.stringify(response.data)} ${shopifyCustomerData.email}`
                            )
                        } else {
                            existingCustomer.lastProcessedStatus = 'failed'
                            existingCustomer.lastProcessedMessage = response.message
                            this.logger.error(
                                `${store.id}:Member update failed on xStore ${response.message} ${shopifyCustomerData.email}`
                            )
                        }

                        await this.customerService.update(existingCustomer)
                    } else {
                        this.logger.debug(
                            `${store.id}:Customer data not modified ${shopifyCustomerData.email}. Skipping update on xStore`
                        )
                    }
                } else {
                    this.logger.debug(
                        `${store.id}:Customer membership id not found on shopify ${shopifyCustomerData.email}`
                    )
                }
            } else {
                this.logger.debug(`${store.id}:Customer not found on shopify`)
            }

            this.logger.debug(`${store.id}:Customer xStore update event processed`)
        } else {
            this.logger.debug(
                `${data.store.id}:xStore integration not active`
            )
        }
    }

    getUserInfo(
        store: StoreDto,
        shopifyCustomer: ShopifyCustomer
    ): AuthUserInfoTransformer {
        const shopifyCustomerInfo = plainToInstance(
            AuthUserInfoTransformer,
            shopifyCustomer,
            {
                exposeUnsetFields: true,
                strategy: 'excludeAll',
            }
        )

        if (shopifyCustomerInfo?.phone) {
            shopifyCustomerInfo.phone = shopifyCustomerInfo.phone.replaceAll(
                store.storeIntegrations.shopify.settings.callingCode,
                ''
            )
        }

        return shopifyCustomerInfo
    }
}
