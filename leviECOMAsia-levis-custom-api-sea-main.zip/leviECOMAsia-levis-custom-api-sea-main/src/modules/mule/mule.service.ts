import { HttpService } from '@nestjs/axios';
import { Inject, Injectable, Logger } from '@nestjs/common';
import { lastValueFrom } from 'rxjs';
import { MuleServiceResponse } from './interfaces/mule-general.interface';
import { ShopifyProxyRegisterDto } from '../shopify-proxy/dto/shopify-proxy-auth-register.dto';
import * as moment from 'moment-timezone';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Cache, Store } from 'cache-manager';
import { ShopifyProxyUpdateDto } from '../shopify-proxy/dto/shopify-proxy-auth-update.dto';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { ShopifyProxyReferrerDto } from '../shopify-proxy/dto/shopify-proxy-referrer-refer.dto';
import { ShopifyCustomer } from '../shopify-admin-api/interfaces/shopify-customer.interface';
import { ShopifyCustomMeta } from 'src/enums/shopify-custom-meta.enum';
import { CustomLoggerService } from '../utils/custom-logger.service';

@Injectable()
export class MuleService {
    private logger: CustomLoggerService;
    command = {
        memberEnquiry: 'MEMBER ENQUIRY',
        createMember: 'MEMBERSHIP REGISTRATION2',
        updateProfile: 'UPDATE PROFILE3',
        codeValidation: 'REFERRER CODE VALIDATION',
        transactionHistory: 'GET TRANSACTION HISTORY',
        cardEnquiry: 'CARD ENQUIRY',
        friendsInvitation: 'FRIENDS INVITATION',
        vouchers: 'GET VOUCHERS',
        voucherType: 'GET VOUCHER TYPE'
    };
    constructor(
        private httpService: HttpService,
        @Inject(CACHE_MANAGER) private cacheManager: Cache,
        private customLoggerService: CustomLoggerService
    ) {
        this.customLoggerService.setContext(MuleService.name);
        this.logger = customLoggerService;
        this.httpService.axiosRef.interceptors.request.clear();
        this.httpService.axiosRef.interceptors.request.use((config) => {
            this.logger.debug(`Mule Request: ${JSON.stringify(config.data)}`);
            return config;
        });
    }

    private getRequestDetails(store: StoreDto) {
        return {
            basicParams: {
                EnquiryCode:
                    store.storeIntegrations.ascentis.settings.enquiryCode,
                OutletCode:
                    store.storeIntegrations.ascentis.settings.outletCode,
                PosID: store.storeIntegrations.ascentis.settings.posId,
                CashierID: store.storeIntegrations.ascentis.settings.cashierId,
                IgnoreCCNchecking:
                    store.storeIntegrations.ascentis.settings.ignoreCcnChecking,
                CountryCode:
                    store.storeIntegrations.ascentis.settings.ecomCountryCode
            },
            headers: {
                'Content-Type': 'application/json',
                client_id:
                    store.storeIntegrations.ascentis.credentials.muleClientId,
                client_secret:
                    store.storeIntegrations.ascentis.credentials
                        .muleClientSecret,
                SoapAction: 'https://MatrixAPIs/JSONCommand2'
            },
            url: store.storeIntegrations.ascentis.credentials.muleBaseUrl
        };
    }

    async memberEnquiry(
        store: StoreDto,
        username: string,
        memberId = ''
    ): Promise<MuleServiceResponse> {
        const type = username.includes('@') ? 'email' : 'mobile';
        const requestDetails = this.getRequestDetails(store);
        const data = {
            Command: this.command.memberEnquiry,
            ...requestDetails.basicParams,
            MobileNo:
                type === 'mobile'
                    ? `${
                          store.storeIntegrations.shopify.settings.callingCode
                      }${username.replaceAll(
                          store.storeIntegrations.shopify.settings.callingCode,
                          ''
                      )}`
                    : '',
            Email: type === 'email' ? username : '',
            MemberID: memberId,
            FilterCardsByStatus: 'ACTIVE',
            MobileNoExactSearch: type === 'mobile' ? true : false,
            RetrieveBase64ImageString: false,
            RetrievePtsToNextTier: false,
            RetrieveNettToNextTier: false,
            RetrieveJournalList: false,
            JournalfilterBy_Type: '',
            RequestDynamicColumnLists: [
                {
                    Name: 'MaritalStatus'
                },
                {
                    Name: 'Gender'
                },
                {
                    Name: 'CountryCode'
                },
                {
                    Name: 'NotifySMS'
                }
            ],
            RequestDynamicFieldLists: [
                {
                    Name: 'LastName'
                },
                {
                    Name: 'FirstName'
                }
            ],
            CardLists_PageNumber: 1,
            CardLists_PageCount: 1
        };
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };
        try {
            const response = await lastValueFrom(
                this.httpService.post(
                    `${requestDetails.url}/memberEnquiry`,
                    data,
                    {
                        headers: requestDetails.headers
                    }
                )
            );
            result.data = response.data;
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
            const attempt: number = await this.cacheManager.get(
                `${username}-member-enquiry`
            );
            await this.cacheManager.set(
                `${username}-member-enquiry`,
                (+attempt || 0) + 1,
                300
            );

            if (attempt < 3) {
                return await this.memberEnquiry(store, username, memberId);
            }

            this.cacheManager.del(`${username}-member-enquiry`);
        }

        return result;
    }

    async memberCreate(
        store: StoreDto,
        shopifyProxyRegisterDto: ShopifyProxyRegisterDto
    ): Promise<MuleServiceResponse> {
        const requestDetails = this.getRequestDetails(store);
        const data = {
            Command: this.command.createMember,
            ...requestDetails.basicParams,
            MobileNo: `${
                store.storeIntegrations.shopify.settings.callingCode
            }${shopifyProxyRegisterDto.phone.replaceAll(
                store.storeIntegrations.shopify.settings.callingCode,
                ''
            )}`,
            Email: shopifyProxyRegisterDto.email,
            Name: `${shopifyProxyRegisterDto.firstName} ${shopifyProxyRegisterDto.lastName}`.trim(),
            PrintedName:
                `${shopifyProxyRegisterDto.firstName} ${shopifyProxyRegisterDto.lastName}`.trim(),
            DOB: `/Date(${moment(shopifyProxyRegisterDto.dob).unix() * 1000})/`,
            MemberID: '',
            FilterCardsByStatus: 'ACTIVE',
            Password: shopifyProxyRegisterDto.password,
            ReferrerCode: '',
            MobileNoExactSearch: false,
            RetrieveBase64ImageString: false,
            RetrievePtsToNextTier: false,
            RetrieveNettToNextTier: false,
            RetrieveJournalList: false,
            JournalfilterBy_Type: '',
            MembershipTypeCode: 'RedTabLevis',
            TierCode: 'Blue',
            Gender:
                shopifyProxyRegisterDto.gender === 'Male'
                    ? 'M'
                    : shopifyProxyRegisterDto.gender === 'Female'
                    ? 'F'
                    : 'D',
            DynamicColumnLists: [
                {
                    Name: 'CountryCode',
                    ColValue:
                        store.storeIntegrations.shopify.settings.callingCode,
                    Type: 'nvarchar(1)'
                },
                {
                    Name: 'Gender',
                    ColValue:
                        shopifyProxyRegisterDto.gender === 'Male'
                            ? 'M'
                            : shopifyProxyRegisterDto.gender === 'Female'
                            ? 'F'
                            : 'D',
                    Type: 'nvarchar(1)'
                }
            ],
            DynamicFieldLists: [
                {
                    Name: 'LastName',
                    ColValue: shopifyProxyRegisterDto.lastName,
                    Type: 'nvarchar(50)'
                },
                {
                    Name: 'FirstName',
                    ColValue: shopifyProxyRegisterDto.firstName,
                    Type: 'nvarchar(50)'
                }
            ],
            RunRegistrationCampaign: true,
            RegistrationCampaignType: 'Registration Campaign',
            RegistrationCampaignCode: '',
            CheckQualificationRulesForRegistration: true,
            CardLists_PageNumber: 1,
            CardLists_PageCount: 1
        };

        if (shopifyProxyRegisterDto.posSource) {
            data['OutletCode'] = shopifyProxyRegisterDto.posSource;
        }

        if (shopifyProxyRegisterDto.referralCode) {
            data.ReferrerCode = shopifyProxyRegisterDto.referralCode;
        }

        data['CheckQualificationRulesForReferee'] = true;
        data['CheckQualificationRulesForReferrer'] = true;
        data['ReferrerCampaignType'] = 'Referrer Campaign';
        data['ReferrerCampaignCode'] = '';
        data['RefereeCampaignType'] = 'Referee Campaign';
        data['RefereeCampaignCode'] = '';

        if (shopifyProxyRegisterDto.emailOptIn) {
            data['MailingLists'] = [
                {
                    Name:
                        store.storeIntegrations.ascentis.settings.mailingList ||
                        ''
                }
            ];
        }

        if (shopifyProxyRegisterDto.smsOptIn) {
            data.DynamicColumnLists.push({
                Name: 'NotifySMS',
                ColValue: '1',
                Type: 'nvarchar(1)'
            });
        }

        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };
        try {
            const response = await lastValueFrom(
                this.httpService.post(
                    `${requestDetails.url}/createMember`,
                    data,
                    {
                        headers: requestDetails.headers
                    }
                )
            );
            result.data = response.data;
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
            const attempt: number = await this.cacheManager.get(
                `${shopifyProxyRegisterDto.email}-member-create`
            );
            await this.cacheManager.set(
                `${shopifyProxyRegisterDto.email}-member-create`,
                (+attempt || 0) + 1,
                300
            );

            if (attempt < 3) {
                return await this.memberCreate(store, shopifyProxyRegisterDto);
            }

            this.cacheManager.del(
                `${shopifyProxyRegisterDto.email}-member-create`
            );
        }

        return result;
    }

    async memberUpdate(
        store: StoreDto,
        shopifyProxyRegisterDto: ShopifyProxyRegisterDto | ShopifyProxyUpdateDto
    ): Promise<MuleServiceResponse> {
        const requestDetails = this.getRequestDetails(store);
        const data = {
            Command: this.command.updateProfile,
            ...requestDetails.basicParams,
            FilterByMemberID: shopifyProxyRegisterDto.membershipId,
            RetrieveBase64ImageString: false,
            Gender:
                shopifyProxyRegisterDto.gender === 'Male'
                    ? 'M'
                    : shopifyProxyRegisterDto.gender === 'Female'
                    ? 'F'
                    : 'D',
            DynamicColumnLists: [],
            DynamicFieldLists: []
        };

        if (shopifyProxyRegisterDto.lastName) {
            data.DynamicFieldLists.push({
                Name: 'LastName',
                ColValue: shopifyProxyRegisterDto.lastName,
                Type: 'nvarchar(50)'
            });
        }

        if (shopifyProxyRegisterDto.firstName) {
            data.DynamicFieldLists.push({
                Name: 'FirstName',
                ColValue: shopifyProxyRegisterDto.firstName,
                Type: 'nvarchar(50)'
            });

            data['Name'] =
                `${shopifyProxyRegisterDto.firstName} ${shopifyProxyRegisterDto.lastName}`.trim();
        }

        if (shopifyProxyRegisterDto['password']) {
            data['Password'] = shopifyProxyRegisterDto['password'];
        }

        if (typeof shopifyProxyRegisterDto.emailOptIn !== 'undefined') {
            if (shopifyProxyRegisterDto.emailOptIn) {
                data['MailingLists'] = [
                    {
                        Name:
                            store.storeIntegrations.ascentis.settings
                                .mailingList || ''
                    }
                ];
            } else {
                data['MailingLists'] = [{ Name: '' }];
            }
        }

        if (typeof shopifyProxyRegisterDto.smsOptIn !== 'undefined') {
            if (shopifyProxyRegisterDto.smsOptIn) {
                data.DynamicColumnLists.push({
                    Name: 'NotifySMS',
                    ColValue: '1',
                    Type: 'nvarchar(1)'
                });
            } else {
                data.DynamicColumnLists.push({
                    Name: 'NotifySMS',
                    ColValue: '0',
                    Type: 'nvarchar(1)'
                });
            }
        }

        if (shopifyProxyRegisterDto.email) {
            data['Email'] = shopifyProxyRegisterDto.email;
        }

        if (shopifyProxyRegisterDto.phone) {
            data['MobileNo'] = `${
                store.storeIntegrations.shopify.settings.callingCode
            }${shopifyProxyRegisterDto.phone.replaceAll(
                store.storeIntegrations.shopify.settings.callingCode,
                ''
            )}`;

            data.DynamicColumnLists.push({
                Name: 'CountryCode',
                ColValue: store.storeIntegrations.shopify.settings.callingCode,
                Type: 'nvarchar(1)'
            });
        }

        if (shopifyProxyRegisterDto.dob) {
            data['DOB'] = `/Date(${
                moment(shopifyProxyRegisterDto.dob).unix() * 1000
            })/`;
        }

        if (shopifyProxyRegisterDto.gender) {
            data.DynamicColumnLists.push({
                Name: 'Gender',
                ColValue:
                    shopifyProxyRegisterDto.gender === 'Male'
                        ? 'M'
                        : shopifyProxyRegisterDto.gender === 'Female'
                        ? 'F'
                        : 'D',
                Type: 'nvarchar(1)'
            });
        }

        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };
        try {
            const response = await lastValueFrom(
                this.httpService.post(
                    `${requestDetails.url}/updateProfile`,
                    data,
                    {
                        headers: requestDetails.headers
                    }
                )
            );
            result.data = response.data;
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
            const attempt: number = await this.cacheManager.get(
                `${shopifyProxyRegisterDto.email}-member-update`
            );
            await this.cacheManager.set(
                `${shopifyProxyRegisterDto.email}-member-update`,
                (+attempt || 0) + 1,
                300
            );

            if (attempt < 3) {
                return await this.memberUpdate(store, shopifyProxyRegisterDto);
            }

            this.cacheManager.del(
                `${shopifyProxyRegisterDto.email}-member-update`
            );
        }

        return result;
    }

    async validateReferralCode(
        store: StoreDto,
        referralCode: string
    ): Promise<MuleServiceResponse> {
        const requestDetails = this.getRequestDetails(store);
        const data = {
            Command: this.command.codeValidation,
            ...requestDetails.basicParams,
            ReferrerCode: referralCode
        };

        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };
        try {
            const response = await lastValueFrom(
                this.httpService.post(
                    `${requestDetails.url}/codeValidation`,
                    data,
                    {
                        headers: requestDetails.headers
                    }
                )
            );
            result.data = response.data;
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
            const attempt: number = await this.cacheManager.get(
                `${referralCode}-referralCode-validate`
            );
            await this.cacheManager.set(
                `${referralCode}-referralCode-validate`,
                (+attempt || 0) + 1,
                300
            );

            if (attempt < 3) {
                return await this.validateReferralCode(store, referralCode);
            }

            this.cacheManager.del(`${referralCode}-referralCode-validate`);
        }

        return result;
    }

    async vouchers(
        store: StoreDto,
        cardNo: string,
        voucherNo = '',
        voucherTypeCode = ''
    ): Promise<MuleServiceResponse> {
        const requestDetails = this.getRequestDetails(store);
        const data = {
            Command: this.command.vouchers,
            ...requestDetails.basicParams,
            CardNo: cardNo,
            RetrieveMembershipInfo: false,
            FilterBy_VoucherNo: voucherNo,
            FilterBy_VoucherType: '',
            FilterBy_VoucherTypeType: '',
            FilterBy_VoucherTypeCode: voucherTypeCode,
            FilterBy_TypeValue: '',
            FilterBy_ValidFrom: '',
            FilterBy_ValidTo: '',
            FilterBy_TriggerSource: '',
            FilterBy_TransactID: '',
            SortOrder: 'ASC',
            SortBy_VoucherNo: false,
            SortBy_VoucherType: false,
            SortBy_ValidFrom: false,
            SortBy_ValidTo: false,
            SortBy_RedeemedDate: false,
            RetrieveVoucherCap: false,
            RetrieveVoucherSummary: false,
            RetrieveActiveVouchers: true,
            PageNumber_ActiveVouchers: 1,
            PageCount_ActiveVouchers: 99,
            RetrieveRedeemedVouchers: false,
            PageNumber_RedeemedVouchers: 1,
            PageCount_RedeemedVouchers: 20,
            RetrieveExpiredVouchers: false,
            PageNumber_ExpiredVouchers: 1,
            PageCount_ExpiredVouchers: 20,
            RetrieveVoidedVouchers: false,
            PageNumber_VoidedVouchers: 1,
            PageCount_VoidedVouchers: 99,
            RetrieveDelayVouchers: false,
            PageNumber_DelayVouchers: 1,
            PageCount_DelayVouchers: 99
        };

        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };
        try {
            const response = await lastValueFrom(
                this.httpService.post(
                    `${requestDetails.url}/transactionHistory`,
                    data,
                    {
                        headers: requestDetails.headers
                    }
                )
            );
            result.data = response.data;
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
            const attempt: number = await this.cacheManager.get(
                `${cardNo}-voucher-list`
            );
            await this.cacheManager.set(
                `${cardNo}-voucher-list`,
                (+attempt || 0) + 1,
                300
            );

            if (attempt < 3) {
                return await this.vouchers(store, cardNo);
            }

            this.cacheManager.del(`${cardNo}-voucher-list`);
        }

        return result;
    }

    async voucherType(
        store: StoreDto,
        voucherType: string
    ): Promise<MuleServiceResponse> {
        const requestDetails = this.getRequestDetails(store);
        const data = {
            Command: this.command.voucherType,
            ...requestDetails.basicParams,
            RetrieveTnC: true,
            FilterBy_VoucherTypeCode: voucherType
        };

        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };
        try {
            const response = await lastValueFrom(
                this.httpService.post(
                    `${requestDetails.url}/getvoucherType`,
                    data,
                    {
                        headers: requestDetails.headers
                    }
                )
            );
            result.data = response.data;
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
            const attempt: number = await this.cacheManager.get(
                `${voucherType}-voucher-type`
            );
            await this.cacheManager.set(
                `${voucherType}-voucher-type`,
                (+attempt || 0) + 1,
                300
            );

            if (attempt < 3) {
                return await this.voucherType(store, voucherType);
            }

            this.cacheManager.del(`${voucherType}-voucher-type`);
        }

        return result;
    }

    async transactionHistory(
        store: StoreDto,
        cardNo: string,
        purchase = false
    ): Promise<MuleServiceResponse> {
        const requestDetails = this.getRequestDetails(store);
        const data = {
            Command: this.command.transactionHistory,
            ...requestDetails.basicParams,
            CardNo: cardNo,
            MemberID: '',
            RewardsCycleLog_AutoID: 0,
            FilterBy_TransactDateFrom: '',
            FilterBy_TransactDateTo: '',
            FilterBy_AddedOnFrom: '',
            FilterBy_AddedOnTo: '',
            FilterBy_Mode: '',
            FilterBy_TransactOutletCode: '',
            FilterBy_transactPOSID: '',
            FilterBy_ReceiptNo: '',
            RetrieveTransactDetailInfo: false,
            RetrieveOnlinepaymentInfo: false,
            RetrievePaymentInfo: false,
            RetrieveVoidedTransactions: false,
            RetrieveChildRecord: false,
            SortOrder: 'DESC',
            SortByCycle: false,
            SortByProgramYear: false,
            SortByTransactDate: true,
            SortByTransactTime: false,
            SortByModeNameShort: false,
            SortByMode: false,
            SortByOutlet: false,
            SortByReceiptNo: true,
            SortByAmountSpent: false,
            SortByTransactPoints: false,
            SortByVoidBy: false,
            SortByVoidOn: false,
            SortByRemarks: false,
            SortByAddedOn: false,
            PageNumber: 1,
            PageCount: 20
        };

        if (purchase) {
            data.RetrieveTransactDetailInfo = true;
            data.RetrievePaymentInfo = true;
            data.FilterBy_Mode = '1';
        }

        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };
        try {
            const response = await lastValueFrom(
                this.httpService.post(
                    `${requestDetails.url}/transactionHistory`,
                    data,
                    {
                        headers: requestDetails.headers
                    }
                )
            );
            result.data = response.data;
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
            const attempt: number = await this.cacheManager.get(
                `${cardNo}-transaction-history`
            );
            await this.cacheManager.set(
                `${cardNo}-transaction-history`,
                (+attempt || 0) + 1,
                300
            );

            if (attempt < 3) {
                return await this.transactionHistory(store, cardNo);
            }

            this.cacheManager.del(`${cardNo}-transaction-history`);
        }

        return result;
    }

    async cardEnquiry(
        store: StoreDto,
        cardNo: string
    ): Promise<MuleServiceResponse> {
        const requestDetails = this.getRequestDetails(store);
        const data = {
            Command: this.command.cardEnquiry,
            ...requestDetails.basicParams,
            CardNo: cardNo,
            MemberID: '',
            CVC: '',
            SVCurrency: '',
            RetrieveCVCInfo: false,
            RetrieveMembershipInfo: true,
            RetrieveActiveVouchersList: false,
            RetrieveJournalList: false,
            RetrieveCarparkInfo: false,
            RetrieveReceiptMessage: false,
            RetrievePtsToNextTier: false,
            RetrieveNettToNextTier: false,
            RetrieveEligibleFlag: false,
            RetrieveRedeemableVoucher: false,
            RetrieveVoucherSummary: false,
            RetrieveVoucherCap: false,
            RequestDynamicColumnLists: [],
            RequestDynamicFieldLists: [],
            JournalfilterBy_Type: '',
            FilterBy_VoucherNo: '',
            FilterBy_VoucherType: '',
            FilterBy_VoucherTypeType: '',
            FilterBy_ValidFrom: '',
            FilterBy_ValidTo: '',
            FilterBy_TriggerSource: '',
            SortOrder: 'ASC',
            SortBy_VoucherNo: false,
            SortBy_VoucherType: false,
            SortBy_ValidFrom: false,
            SortBy_ValidTo: true,
            PageNumber: 1,
            PageCount: 1
        };

        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };
        try {
            const response = await lastValueFrom(
                this.httpService.post(
                    `${requestDetails.url}/cardEnquiry`,
                    data,
                    {
                        headers: requestDetails.headers
                    }
                )
            );
            result.data = response.data;
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
            const attempt: number = await this.cacheManager.get(
                `${cardNo}-card-enquiry`
            );
            await this.cacheManager.set(
                `${cardNo}-card-enquiry`,
                (+attempt || 0) + 1,
                300
            );

            if (attempt < 3) {
                return await this.cardEnquiry(store, cardNo);
            }

            this.cacheManager.del(`${cardNo}-card-enquiry`);
        }

        return result;
    }

    async friendInvitationCreate(
        shopifyProxyReferrerDto: ShopifyProxyReferrerDto,
        store: StoreDto,
        shopifyCustomer: ShopifyCustomer
    ): Promise<MuleServiceResponse> {
        const type = shopifyProxyReferrerDto.username.includes('@')
            ? 'email'
            : 'mobile';
        const requestDetails = this.getRequestDetails(store);
        const data: any = {
            Command: this.command.friendsInvitation,
            ...requestDetails.basicParams,
            MemberID: '',
            CardNo: '',
            SMSMaskName: '',
            SendSMS: false,
            MobileNoLists: [],
            SMSMessage: '',
            SendEmail: false,
            EmailTemplateName: '',
            NameList: [
                {
                    Name: '',
                    Email: ''
                }
            ]
        };

        if (shopifyCustomer) {
            data.MemberID =
                shopifyCustomer.metafields.find(
                    (metafield) =>
                        metafield.key === ShopifyCustomMeta.MembershipId
                )?.value || '';
            data.CardNo =
                shopifyCustomer.metafields.find(
                    (metafield) =>
                        metafield.key === ShopifyCustomMeta.LoyaltyCardNo
                )?.value || '';
        }

        const referralCode = shopifyCustomer.metafields.find(
            (metafield) => metafield.key === ShopifyCustomMeta.ReferralCode
        )?.value;

        if (type === 'mobile') {
            data.SendSMS = true;
            data.MobileNoLists = [
                `${
                    store.storeIntegrations.shopify.settings.callingCode
                }${shopifyProxyReferrerDto.username.replaceAll(
                    store.storeIntegrations.shopify.settings.callingCode,
                    ''
                )}`
            ];
            data.SMSMaskName = 'Levis Red Tab';
            data.SMSMessage = `${store.name} is inviting you to shop at ${store.shop}. Use referral code ${referralCode} while registring to get exciting offers.`;
        } else {
            data.SendEmail = true;
            data.NameList = [
                {
                    Name: shopifyProxyReferrerDto.name,
                    Email: shopifyProxyReferrerDto.username
                }
            ];
            data.EmailTemplateName = 'Friends Referral';
        }

        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            const response = await lastValueFrom(
                this.httpService.post(
                    `${requestDetails.url}/friendsInvitation`,
                    data,
                    {
                        headers: requestDetails.headers
                    }
                )
            );

            result.data = response.data;
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
            const attempt: number = await this.cacheManager.get(
                `${shopifyProxyReferrerDto.username}-referred-invitation`
            );
            await this.cacheManager.set(
                `${shopifyProxyReferrerDto.username}-referred-invitation`,
                (+attempt || 0) + 1,
                300
            );

            if (attempt < 3) {
                return await this.friendInvitationCreate(
                    shopifyProxyReferrerDto,
                    store,
                    shopifyCustomer
                );
            }

            this.cacheManager.del(
                `${shopifyProxyReferrerDto.username}-referred-invitation`
            );
        }

        return result;
    }

    async getReferralCode(
        store: StoreDto,
        memberId: string,
        cardNo: string
    ): Promise<MuleServiceResponse> {
        const requestDetails = this.getRequestDetails(store);
        const data: any = {
            Command: this.command.friendsInvitation,
            ...requestDetails.basicParams,
            MemberID: memberId,
            CardNo: cardNo
        };

        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            const response = await lastValueFrom(
                this.httpService.post(
                    `${requestDetails.url}/friendsInvitation`,
                    data,
                    {
                        headers: requestDetails.headers
                    }
                )
            );

            result.data = response.data;
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
            const attempt: number = await this.cacheManager.get(
                `${memberId}-referred-fetch`
            );
            await this.cacheManager.set(
                `${memberId}-referred-fetch`,
                (+attempt || 0) + 1,
                300
            );

            if (attempt < 3) {
                return await this.getReferralCode(store, memberId, cardNo);
            }

            this.cacheManager.del(`${memberId}-referred-fetch`);
        }

        return result;
    }
}
