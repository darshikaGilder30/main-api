import { Test, TestingModule } from '@nestjs/testing';
import { MuleService } from './mule.service';
import { lastValueFrom, of } from 'rxjs';
import { HttpService } from '@nestjs/axios';

describe('MuleService', () => {
    let service: MuleService;
    let httpService: HttpService;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [
                MuleService,
                {
                    provide: HttpService,
                    useValue: {
                        post: jest.fn(() => of({ data: {}, status: 200 }))
                    }
                }
            ]
        }).compile();

        service = module.get<MuleService>(MuleService);
        httpService = module.get<HttpService>(HttpService);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });

    it('should return data and status', async () => {
        const email = 'test@example.com';
        const response = await service.memberEnquiry(email);
        expect(httpService.post).toHaveBeenCalledWith('memberEnquiry', {
            Command: 'MEMBER ENQUIRY',
            EnquiryCode: 'Portal-Xebia',
            OutletCode: 'Portal',
            PosID: 'Portal',
            CashierID: 'Portal',
            IgnoreCCNchecking: 'false',
            CountryCode: 'EcomKR',
            MobileNo: '',
            Email: email,
            MemberID: '',
            FilterCardsByStatus: 'ACTIVE',
            MobileNoExactSearch: false,
            RetrieveBase64ImageString: false,
            RetrievePtsToNextTier: false,
            RetrieveNettToNextTier: false,
            RetrieveJournalList: false,
            JournalfilterBy_Type: '',
            RequestDynamicColumnLists: [
                {
                    Name: 'MaritalStatus'
                },
                {
                    Name: 'Gender'
                },
                {
                    Name: 'CountryCode'
                },
                {
                    Name: 'NotifySMS'
                }
            ],
            RequestDynamicFieldLists: [
                {
                    Name: 'LastName'
                },
                {
                    Name: 'FirstName'
                }
            ],
            CardLists_PageNumber: 1,
            CardLists_PageCount: 99
        });
        expect(response).toEqual({ data: {}, message: '', success: true });
    });

    it('should return error message on failure', async () => {
        const email = 'test@example.com';
        jest.spyOn(httpService, 'post').mockImplementationOnce(() => {
            throw new Error('Test error');
        });
        const response = await service.memberEnquiry(email);
        expect(httpService.post).toHaveBeenCalledWith('memberEnquiry', {
            Command: 'MEMBER ENQUIRY',
            EnquiryCode: 'Portal-Xebia',
            OutletCode: 'Portal',
            PosID: 'Portal',
            CashierID: 'Portal',
            IgnoreCCNchecking: 'false',
            CountryCode: 'EcomKR',
            MobileNo: '',
            Email: email,
            MemberID: '',
            FilterCardsByStatus: 'ACTIVE',
            MobileNoExactSearch: false,
            RetrieveBase64ImageString: false,
            RetrievePtsToNextTier: false,
            RetrieveNettToNextTier: false,
            RetrieveJournalList: false,
            JournalfilterBy_Type: '',
            RequestDynamicColumnLists: [
                {
                    Name: 'MaritalStatus'
                },
                {
                    Name: 'Gender'
                },
                {
                    Name: 'CountryCode'
                },
                {
                    Name: 'NotifySMS'
                }
            ],
            RequestDynamicFieldLists: [
                {
                    Name: 'LastName'
                },
                {
                    Name: 'FirstName'
                }
            ],
            CardLists_PageNumber: 1,
            CardLists_PageCount: 99
        });
        expect(response).toEqual({
            data: null,
            message: 'Test error',
            success: false
        });
    });
});
