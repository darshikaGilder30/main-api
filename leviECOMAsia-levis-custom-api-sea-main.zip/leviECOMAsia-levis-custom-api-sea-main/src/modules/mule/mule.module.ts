import { Module } from '@nestjs/common';
import { MuleService } from './mule.service';
import { HttpModule } from '@nestjs/axios';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { CustomLoggerService } from '../utils/custom-logger.service';
import { MuleReferrerValidateService } from './mule-referrer-validate.service';

@Module({
    imports: [
        HttpModule.registerAsync({
            imports: [ConfigModule],
            useFactory: async (configService) => ({
                timeout: 120000
            }),
            inject: [ConfigService]
        })
    ],
    providers: [MuleService, CustomLoggerService, MuleReferrerValidateService],
	exports: [MuleService, MuleReferrerValidateService]
})
export class MuleModule {}
