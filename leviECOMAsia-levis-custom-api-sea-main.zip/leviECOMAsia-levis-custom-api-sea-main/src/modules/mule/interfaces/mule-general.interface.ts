export interface MuleServiceResponse<T = any> {
    data: T | null;
    message: string;
    success: boolean;
}
