import { HttpService } from '@nestjs/axios';
import { Inject, Injectable, Logger } from '@nestjs/common';
import { lastValueFrom } from 'rxjs';
import { MuleServiceResponse } from './interfaces/mule-general.interface';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Cache } from 'cache-manager';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';

@Injectable()
export class MuleReferrerValidateService {
    private logger: Logger = new Logger(MuleReferrerValidateService.name);
    command = {
        codeValidation: 'REFERRER CODE VALIDATION'
    };
    constructor(
        private httpService: HttpService,
        @Inject(CACHE_MANAGER) private cacheManager: Cache,
    ) {
        this.httpService.axiosRef.interceptors.request.clear();
        this.httpService.axiosRef.interceptors.request.use((config) => {
            this.logger.debug(`Mule Request: ${JSON.stringify(config.data)}`);
            return config;
        });
    }

    private getRequestDetails(store: StoreDto) {
        return {
            basicParams: {
                EnquiryCode:
                    store.storeIntegrations.ascentis.settings.enquiryCode,
                OutletCode:
                    store.storeIntegrations.ascentis.settings.outletCode,
                PosID: store.storeIntegrations.ascentis.settings.posId,
                CashierID: store.storeIntegrations.ascentis.settings.cashierId,
                IgnoreCCNchecking:
                    store.storeIntegrations.ascentis.settings.ignoreCcnChecking,
                CountryCode:
                    store.storeIntegrations.ascentis.settings.ecomCountryCode
            },
            headers: {
                'Content-Type': 'application/json',
                client_id:
                    store.storeIntegrations.ascentis.credentials.muleClientId,
                client_secret:
                    store.storeIntegrations.ascentis.credentials
                        .muleClientSecret,
                SoapAction: 'https://MatrixAPIs/JSONCommand2'
            },
            url: store.storeIntegrations.ascentis.credentials.muleBaseUrl
        };
    }

    async validateReferralCode(
        store: StoreDto,
        referralCode: string
    ): Promise<MuleServiceResponse> {
        const requestDetails = this.getRequestDetails(store);
        const data = {
            Command: this.command.codeValidation,
            ...requestDetails.basicParams,
            ReferrerCode: referralCode
        };

        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };
        try {
            const response = await lastValueFrom(
                this.httpService.post(
                    `${requestDetails.url}/codeValidation`,
                    data,
                    {
                        headers: requestDetails.headers
                    }
                )
            );
            result.data = response.data;
            result.success = true;
        } catch (error) {
            this.logger.error(`${store.name} - ${error}`);
            result.message = error.message;
            const attempt: number = await this.cacheManager.get(
                `${referralCode}-referralCode-validate`
            );
            await this.cacheManager.set(
                `${referralCode}-referralCode-validate`,
                (+attempt || 0) + 1,
                300
            );

            if (attempt < 3) {
                return await this.validateReferralCode(store, referralCode);
            }

            this.cacheManager.del(`${referralCode}-referralCode-validate`);
        }

        return result;
    }
}