import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Inject, Injectable } from '@nestjs/common';
import { Cache } from 'cache-manager';
import * as moment from 'moment-timezone';
import { authenticator, totp } from 'otplib';

@Injectable()
export class OtpService {
    constructor(@Inject(CACHE_MANAGER) private cacheManager: Cache) {}

    async generateSecret() {
        return authenticator.generateSecret();
    }

    async generateTotp(secret: string) {
        let startWindow = 0;
        const startWindowCache: string = await this.cacheManager.get(
            `${secret}-window`
        );
        if (startWindowCache) {
            startWindow = parseInt(startWindowCache);
        } else {
            startWindow = moment().get('second');
            await this.cacheManager.set(
                `${secret}-window`,
                startWindow.toString(),
                300
            );
        }
        totp.options = {
            epoch: Date.now(),
            step: 300,
            window: startWindow,
            digits: 6
        };
        return totp.generate(secret);
    }

    async verifyTotp(secret: string, otp: string) {
        let startWindow = 0;
        const startWindowCache: string = await this.cacheManager.get(
            `${secret}-window`
        );
        if (startWindowCache) {
            startWindow = parseInt(startWindowCache);
        }
        totp.options = {
            epoch: Date.now(),
            step: 300,
            window: startWindow,
            digits: 6
        };

        return totp.check(otp, secret);
    }

    async generateOtp(
        identity: string,
        sameOtp: boolean = false
    ): Promise<string> {
        identity = Buffer.from(identity).toString('base64');
        let secret: string = null;
        if (sameOtp) {
            secret = await this.cacheManager.get(`${identity}-otp`);
        }

        if (!secret) {
            secret = await this.generateSecret();
            await this.cacheManager.set(`${identity}-otp`, secret, 300);
        }
        const otp = await this.generateTotp(secret);

        return otp;
    }

    async verifyOtp(identity: string, otp: string, tries = 0): Promise<boolean> {
        identity = Buffer.from(identity).toString('base64');
        const secret: string = await this.cacheManager.get(`${identity}-otp`);
        if (!secret) {
            return false;
        }

        const isValid = await this.verifyTotp(secret, otp);
        if (!isValid) {
            if (tries > 3) {
                await this.cacheManager.del(`${identity}-otp`);
            }
            return false;
        }

        await this.cacheManager.del(`${identity}-otp`);

        return true;
    }
}
