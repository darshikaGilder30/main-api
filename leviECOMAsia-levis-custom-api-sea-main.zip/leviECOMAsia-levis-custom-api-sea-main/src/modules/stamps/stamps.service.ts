import { HttpException, Injectable } from '@nestjs/common';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { StampsApiService } from './stamps-api.service';
import { ShopifyCustomer } from '../shopify-admin-api/interfaces/shopify-customer.interface';
import { HttpServiceResponse, JsonResponse } from 'src/interfaces/http/json-response.interface';
import { plainToClass, plainToInstance } from 'class-transformer';
import { StampsVoucherTransformer } from './transformers/stamps-voucher.transformer';
import { I18nContext } from 'nestjs-i18n';
import { LiquidTemplateService } from '../utils/liquid.service';
import { ShopifyAdminApiService } from '../shopify-admin-api/shopify-admin-api.service';
import { StampsTransactionHistoryTransformer } from './transformers/stamps-transaction-history.transformer';
import { CustomLoggerService } from '../utils/custom-logger.service';
import { ShopifyProxyRegisterDto } from '../shopify-proxy/dto/shopify-proxy-auth-register.dto';
import { ShopifyProxyUpdateDto } from '../shopify-proxy/dto/shopify-proxy-auth-update.dto';
import { Member } from './interfaces/register-member.interface';
import { GetMemberResponse } from './interfaces/enquiry-member.interface';
import { ShopifyCustomMeta } from 'src/enums/shopify-custom-meta.enum';
import { ShopifyProxyLoyaltyApplyDto } from '../shopify-proxy/dto/shopify-proxy-loyalty-apply.dto';
import { StampsCardInfoTransformer } from './transformers/stamps-card-info.transformer';
import { StampsRewardVoucherTransformer } from '../shopify-proxy/transformers/stamps-rewards-voucher.transformer';
import { LoyaltyHelperService } from '../utils/loyalty-helper.service';
import { StampsActivityTransformer } from './transformers/stamps-activity.transformer';
import { LoyaltyRedemption } from 'src/enums/loyalty.enum';

@Injectable()
export class StampsService {
    private logger: CustomLoggerService;
    constructor(
        private stampsApiService: StampsApiService,
        private liquidService: LiquidTemplateService,
        private shopifyAdminApiService: ShopifyAdminApiService,
        private customLoggerService: CustomLoggerService
    ) {
        this.customLoggerService.setContext(StampsService.name);
        this.logger = customLoggerService;
    }

    async vouchers(
        store: StoreDto,
        shopifyCustomer: ShopifyCustomer
    ): Promise<JsonResponse> {
        const response: JsonResponse = {
            message: '',
            data: {
                vouchers: [],
                settings: store.storeIntegrations.shopify.settings
            }
        };
        const membershipId = shopifyCustomer.metafields.find(
            (metafield) => metafield.key === ShopifyCustomMeta.MembershipId
        )?.value;

        if (!membershipId) {
            throw new HttpException(
                I18nContext.current().translate('exception.ascentis_error'),
                400
            );
        }

        const vouchers = await this.stampsApiService.vouchers(
            store,
            membershipId
        );

        if (vouchers.success && vouchers.data) {
            for (const voucher of vouchers.data.vouchers) {
                const transformedVoucher = plainToClass(
                    StampsVoucherTransformer,
                    voucher,
                    {
                        exposeUnsetFields: true,
                        strategy: 'excludeAll'
                    }
                );

                response.data.vouchers.push(transformedVoucher);
            }
        }

        return response;
    }

    async accountVouchersRender(
        store: StoreDto,
        shopifyCustomer: ShopifyCustomer
    ): Promise<JsonResponse> {
        const response: JsonResponse = {
            message: '',
            data: {
                content: ''
            }
        };

        const membershipId = shopifyCustomer.metafields.find(
            (metafield) => metafield.key === ShopifyCustomMeta.MembershipId
        )?.value;

        const vouchers = await this.stampsApiService.vouchers(
            store,
            membershipId || shopifyCustomer.phone || shopifyCustomer.email
        );

        if (vouchers.success) {
            const transformedVoucher = [];
            for (const voucher of vouchers.data?.vouchers) {
                transformedVoucher.push(
                    plainToClass(StampsVoucherTransformer, voucher, {
                        exposeUnsetFields: true,
                        strategy: 'excludeAll'
                    })
                );
            }

            const template = await this.liquidService.render(
                store,
                'vouchers',
                {
                    vouchers: transformedVoucher
                }
            );

            response.data.content = template;
        } else {
            throw new HttpException(
                I18nContext.current().translate('exception.ascentis_error'),
                400
            );
        }

        return response;
    }

    async accountTransactionHistoriesRender(
        store: StoreDto,
        shopifyCustomer: ShopifyCustomer
    ): Promise<JsonResponse> {
        const response: JsonResponse = {
            message: '',
            data: {
                content: ''
            }
        };

        const membershipId = shopifyCustomer.metafields.find(
            (metafield) => metafield.key === ShopifyCustomMeta.MembershipId
        )?.value;

        const transactions = await this.stampsApiService.activityHistory(
            store,
            membershipId || shopifyCustomer.phone || shopifyCustomer.email
        );

        if (transactions.success) {
            const transactionHistories = [];
            for (const activity of transactions.data?.activities) {
                transactionHistories.push(
                    plainToInstance(StampsActivityTransformer, activity, {
                        exposeUnsetFields: true,
                        strategy: 'excludeAll'
                    })
                );
            }

            const membership = await this.stampsApiService.getMemberDetails(
                store,
                membershipId
            );

            let cardInfo = null;

            if (membership.success && membership.data) {
                cardInfo = plainToClass(
                    StampsCardInfoTransformer,
                    {
                        store: store,
                        ...membership.data
                    },
                    {
                        exposeUnsetFields: true,
                        strategy: 'excludeAll'
                    }
                );
            }

            const template = await this.liquidService.render(
                store,
                'transaction-histories',
                {
                    transactionHistories: transactionHistories,
                    cardInfo
                }
            );

            response.data.content = template;
        } else {
            if (transactions.message === 'invalid_user') {
                const template = await this.liquidService.render(
                    store,
                    'transaction-histories',
                    {
                        transactionHistories: []
                    }
                );

                response.data.content = template;
            } else {
                throw new HttpException(
                    I18nContext.current().translate('exception.ascentis_error'),
                    400
                );
            }
        }

        return response;
    }

    async applyVoucher(
        store: StoreDto,
        shopifyCustomer: ShopifyCustomer,
        voucherCode: string
    ): Promise<JsonResponse> {
        const response: JsonResponse = {
            message: '',
            data: {
                settings: store.storeIntegrations.shopify.settings
            }
        };
        const membershipId = shopifyCustomer.metafields.find(
            (metafield) => metafield.key === ShopifyCustomMeta.MembershipId
        )?.value;

        if (!membershipId) {
            throw new HttpException(
                I18nContext.current().translate('exception.ascentis_error'),
                400
            );
        }

        const vouchers = await this.stampsApiService.vouchers(
            store,
            membershipId,
            voucherCode
        );

        if (vouchers.success && vouchers.data.vouchers?.length > 0) {
            const transformedVoucher = plainToClass(
                StampsVoucherTransformer,
                vouchers.data.vouchers[0],
                {
                    exposeUnsetFields: true,
                    strategy: 'excludeAll'
                }
            );

            const discountCode =
                await this.shopifyAdminApiService.createOrGetCustomerDiscount(
                    store,
                    shopifyCustomer,
                    transformedVoucher
                );

            if (discountCode) {
                return response;
            }
        }

        this.logger.error(
            `Stamps: ${store.id}: Failed to get stamp voucher info for voucher code: ${voucherCode} with error: ${vouchers?.message}`
        );
        // delete voucher in shopify
        this.shopifyAdminApiService
            .deleteDiscountIfExist(store, shopifyCustomer, voucherCode)
            .then((res) => {
                this.logger.log(
                    `Stamps: ${store.id}: Delete voucher ${voucherCode} in shopify ${res}`
                );
            })
            .catch((err) => {
                this.logger.error(
                    `Stamps: ${store.id}: Delete voucher ${voucherCode} in shopify failed`
                );
            });

        throw new HttpException(
            I18nContext.current().translate('exception.ascentis_error'),
            400
        );
    }

    async removeVoucher(
        store: StoreDto,
        shopifyCustomer: ShopifyCustomer,
        voucherCode: string
    ): Promise<JsonResponse> {
        const response: JsonResponse = {
            message: '',
            data: {
                settings: store.storeIntegrations.shopify.settings
            }
        };
        const discountCode =
            await this.shopifyAdminApiService.deleteDiscountIfExist(
                store,
                shopifyCustomer,
                voucherCode
            );
        if (discountCode) {
            return response;
        }

        this.logger.error(
            `Stamps: ${store.id}: Failed to delete voucher code: ${voucherCode} in shopify`
        );

        throw new HttpException(
            I18nContext.current().translate('exception.ascentis_error'),
            400
        );
    }

    async memberEnquiry(
        store: StoreDto,
        user: string
    ): Promise<HttpServiceResponse<GetMemberResponse>> {
        return this.stampsApiService.getMemberDetails(store, user);
    }

    async registerMember(
        store: StoreDto,
        shopifyProxyRegisterDto: ShopifyProxyRegisterDto
    ): Promise<HttpServiceResponse<Member>> {
        return this.stampsApiService.registerMember(
            store,
            shopifyProxyRegisterDto
        );
    }

    async updateMember(
        store: StoreDto,
        shopifyProxyRegisterDto: ShopifyProxyRegisterDto | ShopifyProxyUpdateDto
    ): Promise<HttpServiceResponse<Member>> {
        return this.stampsApiService.updateMember(
            store,
            shopifyProxyRegisterDto
        );
    }

    async loyaltyPoints(
        store: StoreDto,
        shopifyCustomer: ShopifyCustomer,
        shopifyProxyLoyaltyApplyDto: ShopifyProxyLoyaltyApplyDto
    ): Promise<JsonResponse> {
        const response: JsonResponse = {
            message: '',
            data: {
                calculation: {},
                attributes: [],
                failedRules: []
            }
        };
        const membershipId = shopifyCustomer.metafields.find(
            (metafield) => metafield.key === ShopifyCustomMeta.MembershipId
        )?.value;

        if (!membershipId) {
            throw new HttpException(
                I18nContext.current().translate('exception.ascentis_error'),
                400
            );
        }
        const membership = await this.stampsApiService.getMemberDetails(
            store,
            membershipId
        );

        if (membership.success && membership.data) {
            if (
                !membership.data.membership.redemption_allowed &&
                !membership.data.membership.is_blocked
            ) {
                response.data.failedRules.push(LoyaltyRedemption.NOT_ALLOWED);
            }

            const cardInfo = plainToClass(
                StampsCardInfoTransformer,
                {
                    store: store,
                    ...membership.data
                },
                {
                    exposeUnsetFields: true,
                    strategy: 'excludeAll'
                }
            );
            const canApplyLoyalty = membership.data.membership.redemption_allowed &&
            !membership.data.membership.is_blocked;
            if (canApplyLoyalty) {
                response.data.calculation =
                    LoyaltyHelperService.calculateRedeemableLoyalty(
                        cardInfo.totalPointsBalance,
                        cardInfo.dollarToPointsRatio,
                        shopifyProxyLoyaltyApplyDto,
                        store.storeIntegrations.stamps.settings
                    );

                response.data.failedRules = [
                    ...response.data.failedRules,
                    ...response.data.calculation.failedRules
                ];
                delete response.data.calculation.failedRules;

                if (shopifyProxyLoyaltyApplyDto.applyLoyalty === true) {
                    response.data.attributes = [
                        {
                            key: '_loyalty_redemption_payload',
                            value: Buffer.from(
                                JSON.stringify({
                                    points: cardInfo.totalPointsBalance,
                                    cash: cardInfo.totalCash,
                                    dollarToPointsRatio:
                                        cardInfo.dollarToPointsRatio,
                                    tierCode: cardInfo.tierCode,
                                    settings:
                                        store.storeIntegrations.stamps.settings,
                                    calculation: response.data.calculation
                                })
                            ).toString('base64')
                        }
                    ];
                } else {
                    response.data.attributes = [
                        {
                            key: '_loyalty_redemption_payload',
                            value: Buffer.from('{}').toString('base64')
                        }
                    ];
                }
            } else {
                response.data.attributes = [
                    {
                        key: '_loyalty_redemption_payload',
                        value: Buffer.from('{}').toString('base64')
                    }
                ];
                response.data.calculation = {};
                response.data.failedRules = [
                    LoyaltyRedemption.NOT_ALLOWED
                ]
            }
        } else {
            this.logger.error(
                `Stamps: Failed to get card info for card no: ${membership} with error: ${membership?.message}`
            );

            throw new HttpException(
                I18nContext.current().translate('exception.ascentis_error'),
                400
            );
        }

        return response;
    }

    async accountRewardsRender(
        store: StoreDto,
        shopifyCustomer: ShopifyCustomer
    ): Promise<JsonResponse> {
        const response: JsonResponse = {
            message: '',
            data: {
                content: ''
            }
        };
        const membershipId = shopifyCustomer.metafields.find(
            (metafield) => metafield.key === ShopifyCustomMeta.MembershipId
        )?.value;

        if (!membershipId) {
            throw new HttpException(
                I18nContext.current().translate('exception.ascentis_error'),
                400
            );
        }
        const membership = await this.stampsApiService.getMemberDetails(
            store,
            membershipId
        );

        const rewards = await this.stampsApiService.vouchers(
            store,
            membershipId,
            '',
            true
        );

        if (membership.success && membership.data && rewards.success) {
            const cardInfo = plainToClass(
                StampsCardInfoTransformer,
                {
                    store: store,
                    ...membership.data
                },
                {
                    exposeUnsetFields: true,
                    strategy: 'excludeAll'
                }
            );

            const list = [];
            rewards.data.rewards = rewards.data.rewards.filter(
                (reward) =>
                    reward.type === 4 &&
                    reward.membership ===
                        shopifyCustomer.metafields.find(
                            (metafield) =>
                                metafield.key ===
                                ShopifyCustomMeta.MembershipTierCode
                        )?.value
            );

            // Hide voucher redemption if total points balance is less than the reward points of all rewards
            if (
                rewards.data.rewards.filter(
                    (reward) =>
                        cardInfo.totalPointsBalance >= reward.stamps_to_redeem
                ).length === 0
            ) {
                rewards.data.rewards = [];
            }
            for (const reward of rewards.data.rewards) {
                list.push(
                    plainToClass(StampsRewardVoucherTransformer, reward, {
                        exposeUnsetFields: true,
                        strategy: 'excludeAll'
                    })
                );
            }

            const template = await this.liquidService.render(
                store,
                'rewards.id.liquid',
                {
                    cardInfo: cardInfo,
                    rewards: list
                }
            );

            response.data.content = template;
        } else {
            this.logger.error(
                `Stamps: Failed to get card info for card no: ${membership} with error: ${membership?.message}`
            );

            throw new HttpException(
                I18nContext.current().translate('exception.ascentis_error'),
                400
            );
        }

        return response;
    }

    async accountPurchaseHistoriesRender(
        store: StoreDto,
        shopifyCustomer: ShopifyCustomer
    ): Promise<JsonResponse> {
        const response: JsonResponse = {
            message: '',
            data: {
                content: ''
            }
        };
        const membershipId = shopifyCustomer.metafields.find(
            (metafield) => metafield.key === ShopifyCustomMeta.MembershipId
        )?.value;

        if (!membershipId) {
            throw new HttpException(
                I18nContext.current().translate('exception.ascentis_error'),
                400
            );
        }
        const transactions = await this.stampsApiService.transactionHistory(
            store,
            membershipId
        );

        if (transactions.success) {
            const transactionHistories = [];
            for (const transaction of transactions.data?.transactions) {
                const transactionDetails =
                    await this.stampsApiService.transactionDetail(
                        store,
                        membershipId,
                        transaction.id
                    );

                transactionHistories.push(
                    plainToInstance(
                        StampsTransactionHistoryTransformer,
                        {
                            transaction,
                            transactionDetails:
                                transactionDetails.data.transaction.items
                        },
                        {
                            exposeUnsetFields: true,
                            strategy: 'excludeAll'
                        }
                    )
                );
            }

            const template = await this.liquidService.render(
                store,
                'purchase-histories',
                {
                    transactionHistories: transactionHistories
                }
            );

            response.data.content = template;
        } else {
            if (transactions.message === 'invalid_user') {
                const template = await this.liquidService.render(
                    store,
                    'purchase-history',
                    {
                        transactionHistories: []
                    }
                );

                response.data.content = template;
            } else {
                throw new HttpException(
                    I18nContext.current().translate('exception.ascentis_error'),
                    400
                );
            }
        }

        return response;
    }
}
