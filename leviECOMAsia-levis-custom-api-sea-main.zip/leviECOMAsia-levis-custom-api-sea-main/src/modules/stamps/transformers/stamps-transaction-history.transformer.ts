import { Expose, Transform, Type } from 'class-transformer';
import * as moment from 'moment-timezone';
import { StampsTransactionHistoryLineItemTransformer } from 'src/modules/shopify-proxy/transformers/stamps-transaction-history-line-item.transformer';

export class StampsTransactionHistoryTransformer {
    @Expose()
    @Transform(( value ) => {
        return moment(value.obj.transaction.created).format('YYYY-MM-DD HH:mm:ss');
    })
    transactionDate: string;

    @Transform(({ obj }) => {
        let type = null;
        switch (obj.transaction.type) {
            case 0:
                type = 'SALES';
                break;
            case 1:
                if (obj.transaction.redemption?.status) {
                    type = obj.transaction.voucher?.code ? 'VOUCHER REDEMPTION' : 'POINTS REDEMPTION';
                }
                break;
            case 2:
                type = 'ADDITIONAL REWARDS';
                break;
            case 10:
                type = 'POINTS REDEMPTION';
                break;
            case 15:
                type = 'POINTS EXPIRED';
                break;
        }

        return type;
    })
    @Expose({ name: 'type' })
    transactionType: string;

    @Transform(({ obj }) => {
        let points = 0;
        switch (obj.transaction.type) {
            case 0:
                points = obj.transaction.transaction?.stamps || 0;
                break;
            case 1:
                points = obj.transaction.redemption?.stamps || 0;
                break;
            case 2:
                points = obj.transaction.award?.stamps || 0;
                break;
            case 10:
                points = obj.transaction.stamps_deduction?.stamps || 0;
                break;
            case 15:
                points = obj.transaction.expired_stamps || 0;
                break;
        }

        return points;
    })
    @Expose()
    points: number;

    @Expose({ name: 'subtotal' })
    spendingAmount: number;

    @Expose({ name: 'discount' })
    discount: number;

    @Transform((value) => {
        return value.obj.transaction?.value;
    })
    @Expose({ name: 'value' })
    netSpent: number;

    @Transform((value) => {
        return value.obj.transaction?.id;
    })
    @Expose({ name: 'id' })
    transactionRefId: string;

    @Transform((value) => {
        return value.obj.transaction?.invoice_number;
    })
    @Expose({ name: 'invoice_number' })
    receiptNo: string;

    @Transform(({ obj }) => {
        return obj.transaction.store?.display_name || obj.transaction.store?.name;
    })
    @Expose()
    storeName: string;

    @Transform(({ obj }) => {
        return obj.transaction.voucher?.template_name;
    })
    @Expose()
    voucherCode: string;

    @Transform(({ obj }) => {
        return obj.transaction.voucher?.code;
    })
    @Expose()
    voucherNo: string;

    @Transform(({ obj }) => {
        return 'Purchased'; 
    })
    @Expose()
    status: string;

    @Expose({ name: 'transactionDetails' })
    @Type(() => StampsTransactionHistoryLineItemTransformer)
    lineItems: StampsTransactionHistoryLineItemTransformer[]; 

}
