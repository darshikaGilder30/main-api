import { Expose, Transform } from 'class-transformer';
import * as moment from 'moment-timezone';

export class StampsVoucherTransformer {

    @Expose({ name: 'id' })
    '_id': number;

    @Expose({ name: 'code' })
    'id': string;

    @Expose({ name: 'type' })
    'code': string;

    @Expose({ name: 'name' })
    'name': string;

    @Expose({ name: 'description' })
    'description': string;

    @Transform((value) => {
        return value.obj.extra_data?.voucher?.discount_type === 'percentage' ? 'Discount' : 'Cash';
    })
    @Expose({ name: 'type2'})
    'type': string;

    @Transform((value) => {
        return value.obj.extra_data?.voucher?.monetary_value || 0;
    })
    @Expose()
    'value': number;

    @Expose({ name: 'start_date' })
    @Transform(({ value }) => {
        return moment(value, 'YYYY-MM-DD').format('DD-MM-YYYY HH:mm:ss');
    })
    'validFrom': string;

    @Expose({ name: 'expires_on' })
    @Transform(({ value }) => {
        return moment(value, 'DD-MM-YYYY').format('DD-MM-YYYY HH:mm:ss');
    })
    'validTo': string;

    @Transform(({value}) => {
        return true;
    })
    @Expose()
    'isRedeemable': boolean;

    @Expose({ name: 'terms' })
    terms: string;

    @Expose()
    @Transform((value) => {
        return 'active';
    })
    'status': string;
}
