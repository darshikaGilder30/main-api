import { Expose, Transform } from 'class-transformer';
import * as moment from 'moment-timezone';
import { HelperService } from 'src/modules/utils/helper.service';

export class StampsCardRewardCycleListTransformer {
    @Expose({ name: 'PointsType' })
    type: string;

    @Expose({ name: 'PointsBALValue' })
    pointsBalance: number;

    @Transform(({value}) => {
        return moment(value).format('ll');
    })
    @Expose({ name: 'PointsExpiringDate' })
    pointsExpiringDate: string;
}

export class StampsCardInfoTransformer {
    @Transform((value) => {
        return value.obj.membership?.primary_card?.number
    })
    @Expose()
    cardNo: string;

    @Transform((value) => {
        return value.obj.membership.level_text;
    })
    @Expose()
    'tierCode': string;

    @Transform((value) => {
        return HelperService.findDollarToPointsRatio(value.obj.store, value.obj.membership.level_text);
    })
    @Expose()
    'dollarToPointsRatio': string;

    @Transform((value) => {
        return value.obj.membership.stamps
    })
    @Expose()
    'totalPointsBalance': number;

    @Transform((value) => {
        return HelperService.rebateValueFromPoints(
            value.obj.membership.stamps,
            HelperService.findDollarToPointsRatio(value.obj.store, value.obj.membership.level_text)
        );
    })
    @Expose()
    'totalCash': number;

    @Transform((value) => {
        return value.obj.membership.stamps
    })
    @Expose()
    'totalPointsEarned': number;

    @Expose()
    recentexpiryReward: StampsCardRewardCycleListTransformer;
}
