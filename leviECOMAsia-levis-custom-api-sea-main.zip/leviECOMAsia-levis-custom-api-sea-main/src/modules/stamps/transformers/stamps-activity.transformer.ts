import { Expose, Transform, Type } from 'class-transformer';
import * as moment from 'moment-timezone';

export class StampsActivityTransformer {
    @Expose()
    @Transform((value ) => {        
        return moment.unix(value.obj.created).format('DD-MM-YYYY HH:mm:ss');
    })
    transactionDate: string;

    @Transform((value) => {
        let type = null;
        switch (value.obj.type) {
            case 0:
                type = 'SALES';
            break;
            case 1:
                if (value.obj.redemption?.status) {
                    if (value.obj.voucher?.code) {
                        type = 'VOUCHER REDEMPTION';
                    } else {
                        type = 'POINTS REDEMPTION';
                    }
                }
            break;
            case 2:
                type = 'ADDITIONAL REWARDS';
            break;
            case 10:
                type = 'POINTS REDEMPTION';
            break;
            case 15:
                type = 'POINTS EXPIRED';
            break;
        }

        return type;
    })
    @Expose({ name: 'type'})
    transactionType: string;

    @Transform((value) => {
        let points = 0;
        switch (value.obj.type) {
            case 0:
                points = value.obj.transaction?.stamps || 0;
                break;
            case 1:
                points = value.obj.redemption?.stamps || 0;
                break;
            case 2:
                points = value.obj.award?.stamps || 0;
                break;
            case 10:
                points = value.obj.stamps_deduction?.stamps || 0;
                break;
            case 15:
                points = value.obj.expired_stamps || 0;
                break;
        }

        return points;
    })
    @Expose()
    points: number;

    @Expose({ name: 'subtotal' })
    spendingAmount: number;

    @Expose({ name: 'discount' })
    discount: number;

    @Expose({ name: 'subtotal' })
    netSpent: number;

    @Transform((value) => {
        return value.obj.transaction?.invoice_number;
    })
    @Expose({ name: 'invoice_number' })
    transactionRefId: string;

    @Transform((value) => {
        return value.obj.store?.display_name || value.obj.store?.name;
    })
    @Expose()
    storeName: string;

    @Transform((value) => {
        return value.obj.voucher?.template_name
    })
    @Expose()
    voucherCode: string;

    @Transform((value) => {
        return value.obj.voucher?.code
    })
    @Expose()
    voucherNo: string;

    @Transform((value) => {
        return 'Purchased';
    })
    @Expose()
    status: string;
}
