import { HttpService } from '@nestjs/axios';
import { BadRequestException, Injectable, Logger } from '@nestjs/common';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { lastValueFrom } from 'rxjs';
import { CacheHelper } from '../utils/cache/cache-helper.service';
import { CustomLoggerService } from '../utils/custom-logger.service';
import { ShopifyProxyRegisterDto } from '../shopify-proxy/dto/shopify-proxy-auth-register.dto';
import { ShopifyProxyUpdateDto } from '../shopify-proxy/dto/shopify-proxy-auth-update.dto';
import * as moment from 'moment-timezone';
import { Member } from './interfaces/register-member.interface';
import { GetMemberResponse } from './interfaces/enquiry-member.interface';
import { HttpServiceResponse } from 'src/interfaces/http/json-response.interface';

@Injectable()
export class StampsApiService {
    private logger: CustomLoggerService;
    constructor(
        private httpService: HttpService,
        private cacheHelper: CacheHelper,
        private customLoggerService: CustomLoggerService
    ) {
        this.customLoggerService.setContext(StampsApiService.name);
        this.logger = customLoggerService;
        this.httpService.axiosRef.interceptors.request.clear();
        this.httpService.axiosRef.interceptors.request.use((config) => {
            this.logger.debug(
                `Stamps Request: Body: ${JSON.stringify(
                    config.data
                )}, Param: ${JSON.stringify(config.params)}`
            );
            return config;
        });
    }

    private getRequestDetails(store: StoreDto) {
        return {
            basicParams: {
                merchant: store.storeIntegrations.stamps.settings.merchantId,
                store: store.storeIntegrations.stamps.settings.storeId,
                token: store.storeIntegrations.stamps.credentials.token
            },
            headers: {
                'Content-Type': 'application/json'
            },
            url: store.storeIntegrations.stamps.settings.apiUrl
        };
    }

    async vouchers(
        store: StoreDto,
        user: string,
        voucherNo = '',
        isRedeemable = false
    ): Promise<HttpServiceResponse> {
        const requestDetails = this.getRequestDetails(store);

        const result: HttpServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            const response = await lastValueFrom(
                this.httpService.get(`${requestDetails.url}/rewards`, {
                    params: {
                        ...requestDetails.basicParams,
                        user,
                        only_redeemable_in_this_store: isRedeemable
                    }
                })
            );

            result.data = response.data;
            result.success = true;

            if (voucherNo) {
                const voucher = result.data?.vouchers?.find((voucher) => {
                    return voucher.code === voucherNo;
                });

                if (voucher) {
                    result.data = {
                        vouchers: [voucher]
                    };
                } else {
                    throw new Error('Voucher not found');
                }
            }
        } catch (error) {
            this.logger.error(
                `Stamps: Error in vouchers: ${error}`,
                `User: ${user}, Voucher: ${voucherNo} - ${
                    error.response?.data
                        ? JSON.stringify(error.response?.data)
                        : ''
                }`
            );
            result.message = error.message;
            const attempt: number = await this.cacheHelper.get(
                `stamps:${user}-voucher-list`
            );
            await this.cacheHelper.set(
                `stamps:${user}-voucher-list`,
                (+attempt || 0) + 1,
                300
            );

            if (attempt < 3) {
                return await this.vouchers(store, user, voucherNo);
            }

            this.cacheHelper.del(`stamps:${user}-voucher-list`);
        }

        return result;
    }

    async voucherRedeem(
        store: StoreDto,
        user: string,
        voucherNo: string,
        voucherTemplate: number
    ): Promise<HttpServiceResponse> {
        const requestDetails = this.getRequestDetails(store);
        const result: HttpServiceResponse = {
            data: null,
            message: '',
            success: false
        };
        try {
            const response = await lastValueFrom(
                this.httpService.post(
                    `${requestDetails.url}/redemptions/by-voucher-code`,
                    {
                        ...requestDetails.basicParams,
                        identifier: user,
                        voucher_code: voucherNo,
                        voucher_template: voucherTemplate
                    },
                    {
                        headers: requestDetails.headers
                    }
                )
            );

            result.data = response.data;
            result.success = true;
        } catch (error) {
            this.logger.error(
                `Stamps: Error in vouchers: ${error}`,
                `User: ${user}, Voucher: ${voucherNo} - ${
                    error.response?.data
                        ? JSON.stringify(error.response?.data)
                        : ''
                }`
            );
            result.message = error.message;
        }

        return result;
    }

    async voucherRedeemVoid(
        store: StoreDto,
        redemptionId: string
    ): Promise<HttpServiceResponse> {
        const requestDetails = this.getRequestDetails(store);
        const result: HttpServiceResponse = {
            data: null,
            message: '',
            success: false
        };
        try {
            const response = await lastValueFrom(
                this.httpService.post(
                    `${requestDetails.url}/redemptions/cancel`,
                    {
                        ...requestDetails.basicParams,
                        id: redemptionId,
                        create_replacement_voucher: true
                    },
                    {
                        headers: requestDetails.headers
                    }
                )
            );

            result.data = response.data;
            result.success = true;
        } catch (error) {
            this.logger.error(
                error,
                error.response?.data ? JSON.stringify(error.response?.data) : ''
            );
            result.message = error.message;
        }

        return result;
    }

    async activityHistory(
        store: StoreDto,
        user: string
    ): Promise<HttpServiceResponse> {
        const requestDetails = this.getRequestDetails(store);
        const result: HttpServiceResponse = {
            data: null,
            message: '',
            success: false
        };
        try {
            const response = await lastValueFrom(
                this.httpService.get(`${requestDetails.url}/v3/activities`, {
                    params: {
                        ...requestDetails.basicParams,
                        user
                    }
                })
            );

            result.data = response.data;
            result.success = true;
        } catch (error) {
            this.logger.error(
                `Stamps: Error in activities: ${error}`,
                `User: ${user}  - ${
                    error.response?.data
                        ? JSON.stringify(error.response?.data)
                        : ''
                }`
            );

            result.message = error.message;
            if (error.response?.data?.error_code) {
                result.message = error.response.data.error_code;
            }
        }

        return result;
    }

    async transactionHistory(
        store: StoreDto,
        user: string
    ): Promise<HttpServiceResponse> {
        const requestDetails = this.getRequestDetails(store);
        const result: HttpServiceResponse = {
            data: null,
            message: '',
            success: false
        };
        try {
            const response = await lastValueFrom(
                this.httpService.get(
                    `${requestDetails.url}/transactions/by-user`,
                    {
                        params: {
                            ...requestDetails.basicParams,
                            user
                        }
                    }
                )
            );

            result.data = response.data;
            result.success = true;
        } catch (error) {
            this.logger.error(
                `Stamps: Error in transactions: ${error}`,
                `User: ${user}  - ${
                    error.response?.data
                        ? JSON.stringify(error.response?.data)
                        : ''
                }`
            );

            result.message = error.message;
            if (error.response?.data?.error_code) {
                result.message = error.response.data.error_code;
            }
        }

        return result;
    }

    async transactionDetail(
        store: StoreDto,
        user: string,
        transactionId: string
    ): Promise<HttpServiceResponse<TransactionResponse>> {
        const requestDetails = this.getRequestDetails(store);
        const result: HttpServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            const response = await lastValueFrom(
                this.httpService.get(
                    `${requestDetails.url}/transactions/details`,
                    {
                        params: {
                            ...requestDetails.basicParams,
                            transaction_id: transactionId
                        }
                    }
                )
            );

            result.data = response.data;
            result.success = true;
        } catch (error) {
            this.logger.error(
                `Stamps: Error in transaction details: ${error}`,
                `User: ${user} - Transaction ID: ${transactionId} - ${
                    error.response?.data
                        ? JSON.stringify(error.response?.data)
                        : ''
                }`
            );

            result.message = error.message;
            if (error.response?.data?.error_code) {
                result.message = error.response.data.error_code;
            }
        }

        return result;
    }

    async getMemberDetails(
        store: StoreDto,
        user: string
    ): Promise<HttpServiceResponse<GetMemberResponse>> {
        const requestDetails = this.getRequestDetails(store);
        const result: HttpServiceResponse = {
            data: null,
            message: '',
            success: false
        };
        try {
            const response = await lastValueFrom(
                this.httpService.get(
                    `${requestDetails.url}/v2/memberships/details`,
                    {
                        params: {
                            ...requestDetails.basicParams,
                            user
                        }
                    }
                )
            );

            result.data = response.data;
            result.success = true;
        } catch (error) {
            this.logger.error(
                `Stamps: Error in fetching Stamps membership details: ${error}`,
                `User: ${user}  - ${
                    error.response?.data
                        ? JSON.stringify(error.response?.data)
                        : ''
                }`
            );

            result.message = error.message;
            if (
                error.response?.data?.error_code &&
                error.code === 'ERR_BAD_REQUEST'
            ) {
                result.message = error['response'].data.error_code;
                result.success = true;
            }
        }

        return result;
    }

    async registerMember(
        store: StoreDto,
        shopifyProxyRegisterDto: ShopifyProxyRegisterDto
    ): Promise<HttpServiceResponse<Member>> {
        const requestDetails = this.getRequestDetails(store);
        const result: HttpServiceResponse = {
            data: null,
            message: '',
            success: false
        };
        try {
            const data = {
                ...requestDetails.basicParams,
                name: `${shopifyProxyRegisterDto.firstName} ${shopifyProxyRegisterDto.lastName}`.trim(),
                email: shopifyProxyRegisterDto.email,
                mobile_number: `${
                    store.storeIntegrations.shopify.settings.callingCode
                }${shopifyProxyRegisterDto.phone.replaceAll(
                    store.storeIntegrations.shopify.settings.callingCode,
                    ''
                )}`,
                birthday: moment(shopifyProxyRegisterDto.dob)?.format(
                    'YYYY-MM-DD'
                ),
                gender: shopifyProxyRegisterDto?.gender?.toLowerCase(),
                postal_code: shopifyProxyRegisterDto?.postalCode,
                is_active: true, // Optional, setting customer as active
                referral_code: shopifyProxyRegisterDto?.referralCode || '',
                allow_newsletters: shopifyProxyRegisterDto?.emailOptIn || false,
                allow_whatsapp_marketing:
                    shopifyProxyRegisterDto?.smsOptIn || false
            };

            if (shopifyProxyRegisterDto.posSource) {
                data['store'] = shopifyProxyRegisterDto.posSource;
            }
            const response = await lastValueFrom(
                this.httpService.post(
                    `${requestDetails.url}/v2/memberships/register`,
                    data,
                    {
                        headers: requestDetails.headers
                    }
                )
            );

            result.data = response.data;
            result.success = true;
        } catch (error) {
            this.logger.error(
                `Stamps: Error in register stamps Member: ${error}`,
                `User: ${shopifyProxyRegisterDto.email} - ${
                    error.response?.data
                        ? JSON.stringify(error.response?.data)
                        : ''
                }`
            );
            result.message = error.message;
            if (error.response?.data?.error_code) {
                result.message = error['response'].data.error_code;
                result.success = true;
            }
        }

        return result;
    }

    async updateMember(
        store: StoreDto,
        shopifyProxyRegisterDto: ShopifyProxyRegisterDto | ShopifyProxyUpdateDto
    ): Promise<HttpServiceResponse<Member>> {
        const requestDetails = this.getRequestDetails(store);
        const result: HttpServiceResponse<Member> = {
            data: null,
            message: '',
            success: false
        };
        try {
            const data = {
                ...requestDetails.basicParams,
                user: shopifyProxyRegisterDto?.membershipId,
                name: `${shopifyProxyRegisterDto.firstName} ${shopifyProxyRegisterDto.lastName}`.trim(),
                birthday: shopifyProxyRegisterDto.dob
                    ? moment(shopifyProxyRegisterDto.dob).format('YYYY-MM-DD')
                    : undefined,
                gender: shopifyProxyRegisterDto?.gender?.toLowerCase(),
                postal_code: shopifyProxyRegisterDto?.postalCode,
                address: shopifyProxyRegisterDto?.postalAddress,
                phone_is_verified:
                    shopifyProxyRegisterDto?.smsOptIn || undefined,
                email_is_verified:
                    shopifyProxyRegisterDto?.emailOptIn || undefined,
                notes: shopifyProxyRegisterDto?.verifiedSource,
                allow_whatsapp_marketing:
                    shopifyProxyRegisterDto?.smsOptIn || false,
                allow_newsletters: shopifyProxyRegisterDto?.emailOptIn || false
            };

            if (shopifyProxyRegisterDto.email) {
                data['email'] = shopifyProxyRegisterDto.email;
            }

            if (shopifyProxyRegisterDto.phone) {
                data['mobile_number'] = `${
                    store.storeIntegrations.shopify.settings.callingCode
                }${shopifyProxyRegisterDto.phone.replaceAll(
                    store.storeIntegrations.shopify.settings.callingCode,
                    ''
                )}`;
            }
            const response = await lastValueFrom(
                this.httpService.post(
                    `${requestDetails.url}/v2/memberships/change-profile`,
                    data,
                    {
                        headers: requestDetails.headers
                    }
                )
            );

            result.data = response.data;
            result.success = true;
        } catch (error) {
            this.logger.error(
                `Stamps: Error in update stamps Member: ${error}`,
                `User: ${shopifyProxyRegisterDto?.email} - ${
                    error.response?.data
                        ? JSON.stringify(error.response?.data)
                        : ''
                }`
            );
            result.message = error.message;
        }

        return result;
    }

    async rewardRedemption(
        store: StoreDto,
        user: string,
        rewardId: number
    ): Promise<HttpServiceResponse> {
        const requestDetails = this.getRequestDetails(store);
        const result: HttpServiceResponse = {
            data: null,
            message: '',
            success: false
        };
        try {
            const response = await lastValueFrom(
                this.httpService.post(
                    `${requestDetails.url}/v2/redemptions/redeem-reward`,
                    {
                        ...requestDetails.basicParams,
                        user,
                        reward: rewardId
                    },
                    {
                        headers: requestDetails.headers
                    }
                )
            );

            result.data = response.data;
            result.success = true;
        } catch (error) {
            this.logger.error(
                `Stamps: Error in reward redemption: ${error}`,
                `User: ${user}, Reward: ${rewardId} - ${
                    error.response?.data
                        ? JSON.stringify(error.response?.data)
                        : ''
                }`
            );
            if (error.response?.data?.error_message) {
                result.message = error.response.data.error_message;
            } else {
                result.message = error.message;
            }
        }

        return result;
    }
}
