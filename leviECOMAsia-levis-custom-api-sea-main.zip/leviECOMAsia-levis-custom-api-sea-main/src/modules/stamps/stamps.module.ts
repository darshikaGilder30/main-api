import { MiddlewareConsumer, Module } from '@nestjs/common';
import { StampsApiService } from './stamps-api.service';
import { HttpModule } from '@nestjs/axios';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { CacheHelperModule } from '../utils/cache/cache-helper.module';
import { StampsService } from './stamps.service';
import { LiquidTemplateService } from '../utils/liquid.service';
import { ShopifyAdminApiModule } from '../shopify-admin-api/shopify-admin-api.module';
import { OrderVouchersRedemptionModule } from 'src/entities/order-vouchers-redemption/order-vouchers-redemption.module';
import { CustomLoggerService } from '../utils/custom-logger.service';

@Module({
    imports: [
        HttpModule.registerAsync({
            imports: [ConfigModule],
            useFactory: async (configService) => ({
                timeout: 120000
            }),
            inject: [ConfigService]
        }),
        CacheHelperModule,
        ShopifyAdminApiModule,
        OrderVouchersRedemptionModule
    ],
    providers: [
        StampsApiService,
        StampsService,
        LiquidTemplateService,
        CustomLoggerService
    ],
    exports: [StampsService, StampsApiService]
})
export class StampsModule {
    configure(consumer: MiddlewareConsumer) {}
}
