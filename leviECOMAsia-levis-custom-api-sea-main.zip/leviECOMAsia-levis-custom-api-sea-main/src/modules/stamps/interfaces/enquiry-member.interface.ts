export interface GetMemberResponse {
    membership: Membership;
    tags: string[];
    user: User;
}

interface Membership {
    balance: number;
    created: string;
    is_blocked: boolean;
    redemption_allowed: boolean;
    level: number;
    level_text: string;
    member_status: string;
    referral_code: string;
    stamps: number;
    start_date: string;
    tags: string[];
    primary_card: PrimaryCard;
}

interface PrimaryCard {
    id: number;
    number: string;
    is_active: boolean;
    activated_time: string | null;
}

interface User {
    address: string;
    birthday: string;
    email: string;
    email_is_verified: boolean;
    gender: string;
    has_incorrect_email: boolean;
    has_pin: boolean;
    pin_is_blocked: boolean;
    has_password: boolean;
    id: string;
    id_card_file_name: string;
    id_number: string | null;
    is_active: boolean;
    is_anonymized: boolean;
    marital_status: number;
    member_ids: string[];
    name: string;
    notes: string;
    phone: string;
    phone_is_verified: boolean;
    picture_url: string;
    postal_code: string;
    protected_redemption: boolean;
    referral_code: string;
    registration_status: string;
    religion: number;
    wedding_date: string | null;
    site_activity: SiteActivity;
}

interface SiteActivity {
    id: number;
    registration_method: string;
}
