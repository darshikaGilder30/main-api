interface Store {
    display_name: string;
    id: number;
    name: string;
}

interface Item {
    id: number;
    name: string;
    quantity: number;
}

interface Payment {
    id: number;
    value: number;
    eligible_for_stamps: number;
    payment_method_code: string;
}

interface Transaction {
    created: number;
    discount: number | null;
    items: Item[];
    notes?: string;
    service_charge: number | null;
    stamps: number;
    status: string;
    store: Store;
    subtotal: number | null;
    tax: number | null;
    type: string | null;
    value: number;
    payments: Payment[];
}

interface TransactionResponse {
    transaction: Transaction;
}
