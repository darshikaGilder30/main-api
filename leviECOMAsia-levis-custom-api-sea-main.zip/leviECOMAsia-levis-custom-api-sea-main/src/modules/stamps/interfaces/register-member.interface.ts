export interface MemberLocation {
    district: {
        id: number;
        name: string;
    };
    regency: {
        id: number;
        name: string;
    };
    province: {
        id: number;
        name: string;
    };
}

export interface MembershipDetails {
    tags: string[];
    status: number;
    status_text: string;
    level: number;
    level_text: string;
    member_status: string;
    stamps: number;
    balance: number;
    is_blocked: boolean;
    referral_code: string;
    start_date: string;
    created: string;
    primary_card: {
        id: number;
        number: string;
        is_active: boolean;
        activated_time: string;
    };
}

export interface Member {
    id: string;
    name: string;
    gender: string;
    address: string;
    is_active: boolean;
    email: string;
    picture_url: string;
    birthday: string;
    phone: string;
    postal_code: string;
    protected_redemption: boolean;
    has_incorrect_email: boolean;
    marital_status: number;
    religion: number;
    wedding_date: string | null;
    id_number: string | null;
    id_card_file_name: string;
    phone_is_verified: boolean;
    email_is_verified: boolean;
    is_anonymized: boolean;
    has_pin: boolean;
    pin_is_blocked: boolean;
    has_password: boolean;
    notes: string;
    referral_code: string;
    registration_status: string;
    location: MemberLocation;
    membership: MembershipDetails;
    registering_employee_code: string;
}
