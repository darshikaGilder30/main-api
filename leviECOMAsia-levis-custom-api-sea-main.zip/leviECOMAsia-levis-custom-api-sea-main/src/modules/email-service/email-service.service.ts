import { Injectable, Logger } from '@nestjs/common';
import { emailPayloadDto } from './dto/email-payload.dto';
import { SESClient, SendEmailCommand } from "@aws-sdk/client-ses";
import { MailerService } from '@nestjs-modules/mailer';
import { ConfigService } from '@nestjs/config';
import { CustomLoggerService } from '../utils/custom-logger.service';
@Injectable()
export class EmailServiceService {
    private logger: CustomLoggerService;
    constructor(
        private readonly mailerService: MailerService, 
        private configService: ConfigService,
        private customLoggerService: CustomLoggerService
    ) {
        this.customLoggerService.setContext(EmailServiceService.name);
        this.logger = customLoggerService;
    }

    async send(emailPayload: emailPayloadDto): Promise<void> {
        if (!emailPayload.to) {

            this.logger.error('Invalid email payload');
            return;
        }

        if (this.configService.get('environment') === 'production') {
            const sesClient = new SESClient();
            try {
                const command = new SendEmailCommand({
                    Destination: {
                        ToAddresses: [
                            emailPayload.to.toString(),
                        ],
                    },
                    Message: {
                        Body: {
                            Html: {
                                Charset: "UTF-8",
                                Data: emailPayload.html,
                            },
                        },
                        Subject: {
                            Charset: "UTF-8",
                            Data: emailPayload.subject,
                        },
                    },
                    Source: emailPayload.from,
                });

                sesClient.send(command).then((res) => {
                    this.logger.debug(
                        `Email sent to ${emailPayload.to} with subject ${emailPayload.subject}`
                    );
                }).catch((error) => {
                    this.logger.error(`Error sending email: ${error} to ${emailPayload.to}`);
                })
            } catch (error) {
                this.logger.error(`Error sending email: ${error} to ${emailPayload.to}`);
            }
        } else {
            this.mailerService.sendMail({
                to: emailPayload.to,
                from: emailPayload.from,
                subject: emailPayload.subject,
                html: emailPayload.html
            }).then((res) => {
                this.logger.debug(
                    `Email sent to ${emailPayload.to} with subject ${emailPayload.subject}`
                );
            }).catch((error) => {
                this.logger.error(`Error sending email: ${error} to ${emailPayload.to}`);
            })
        }
    }
}
