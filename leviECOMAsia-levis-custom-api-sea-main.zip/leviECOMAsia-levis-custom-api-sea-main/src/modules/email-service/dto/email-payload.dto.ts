import { IsOptional, IsString } from 'class-validator';
import { StringOrArrayofStrings } from '../types/stringOrArrayofStrings.type';

export class emailPayloadDto {
    @IsOptional()
    to?: StringOrArrayofStrings;

    @IsOptional()
    cc?: StringOrArrayofStrings;

    @IsOptional()
    bcc?: StringOrArrayofStrings;

    @IsOptional()
    @IsString()
    from?: string;

    @IsOptional()
    @IsString()
    subject?: string;

    @IsOptional()
    @IsString()
    html?: string;
}
