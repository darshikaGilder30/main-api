import { Module } from '@nestjs/common';
import { EmailServiceService } from './email-service.service';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { MailerModule } from '@nestjs-modules/mailer';
import { CustomLoggerService } from '../utils/custom-logger.service';
@Module({
    imports: [
        MailerModule.forRootAsync({
            imports: [ConfigModule],
            useFactory: (configService: ConfigService) => ({
                transport: {
                    host: 'smtp.sendgrid.net',
                    port: '587',
                    secure: false,
                    auth: {
                        user: 'apikey',
                        pass: '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'
                    }
                }
            }),
            inject: [ConfigService]
        })
    ],
    providers: [EmailServiceService, CustomLoggerService],
    exports: [EmailServiceService]
})
export class EmailServiceModule {}
