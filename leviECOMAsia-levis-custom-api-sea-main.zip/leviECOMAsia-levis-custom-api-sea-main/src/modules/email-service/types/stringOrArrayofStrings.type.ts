export type StringOrArrayofStrings = string | string[];
