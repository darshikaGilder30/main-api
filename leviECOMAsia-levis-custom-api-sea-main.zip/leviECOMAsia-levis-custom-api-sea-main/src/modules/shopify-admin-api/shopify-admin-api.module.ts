import { Module } from '@nestjs/common';
import { ShopifyAdminApiService } from './shopify-admin-api.service';
import { ShopifyAdminRestApiService } from './shopify-admin-rest-api.service';
import { CustomLoggerService } from '../utils/custom-logger.service';

@Module({
    providers: [ShopifyAdminApiService, ShopifyAdminRestApiService, CustomLoggerService],
    exports: [ShopifyAdminApiService, ShopifyAdminRestApiService]
})
export class ShopifyAdminApiModule {}
