import { Injectable, Logger } from '@nestjs/common';
import '@shopify/shopify-api/adapters/node';
import {
    shopifyApi,
    ApiVersion,
    Session,
    LogSeverity
} from '@shopify/shopify-api';
import { ConfigService } from '@nestjs/config';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { MuleServiceResponse } from '../mule/interfaces/mule-general.interface';
import { CustomLoggerService } from '../utils/custom-logger.service';
@Injectable()
export class ShopifyAdminRestApiService {
    private logger: CustomLoggerService;
    constructor(
        private configService: ConfigService, 
        private customLoggerService: CustomLoggerService
    ) { 
        this.customLoggerService.setContext(ShopifyAdminRestApiService.name);
        this.logger = customLoggerService;
    }

    getClient(store: StoreDto) {
        const client = shopifyApi({
            apiKey: this.configService.get('shopify.appProxy.clientId'),
            apiSecretKey: this.configService.get(
                'shopify.appProxy.clientSecret'
            ),
            scopes: this.configService.get('shopify.appProxy.scopes'),
            adminApiAccessToken:
                store.storeIntegrations.shopify.credentials.access_token,
            hostName: store.shop,
            hostScheme: 'https',
            apiVersion: ApiVersion.October23,
            isEmbeddedApp: false,
            logger: {
                timestamps: true,
                httpRequests: true,
                level: LogSeverity.Debug,
                log: (level, data) => {
                    const body = data.split('Body:');
                    if (body.length > 1) {
                        this.logger.debug(JSON.stringify(JSON.parse(body[1])));
                    } else {
                        this.logger.debug(data);
                    }
                }
            }
        });

        const session = new Session({
            id: '',
            shop: store.shop,
            state: '',
            isOnline: false,
            accessToken:
                store.storeIntegrations.shopify.credentials.access_token
        });
        return new client.clients.Rest({
            session,
            apiVersion: ApiVersion.October23
        });
    }

    async createWebhook(
        store: StoreDto,
        topic: string,
        address: string,
        format: string = 'json'
    ) {
        this.logger.log(`${store.shop}: Registering Webhook ${topic}`);
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            const client = this.getClient(store);
            const webhook = await client.post({
                path: 'webhooks.json',
                data: {
                    webhook: {
                        topic,
                        address,
                        format
                    }
                }
            });
            result.data = webhook.body['webhooks'];
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;

            throw error;
        }

        return result;
    }

    async getWebhooks(store: StoreDto) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            const data = await this.getClient(store).get({
                path: 'webhooks.json'
            });

            result.data = data.body['webhooks'];
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;

            throw error;
        }

        return result;
    }

    async getOrderByOrderId(store: StoreDto, orderId: string) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false,
        }
        try {
            const client = this.getClient(store)
            const order = await client.get({
                path: `orders/${orderId}.json`,
            })
            result.data = order.body['order'];
            result.success = true

        } catch (error) {
            this.logger.error(error)
            result.message = error.message
            return result
        }

        return result
    }
}
