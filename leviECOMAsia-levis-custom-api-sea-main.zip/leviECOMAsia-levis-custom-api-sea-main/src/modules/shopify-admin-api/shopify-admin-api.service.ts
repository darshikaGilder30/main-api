import { HttpException, Injectable, Logger } from '@nestjs/common';
import '@shopify/shopify-api/adapters/node';
import {
    shopifyApi,
    ApiVersion,
    Session,
    LogSeverity
} from '@shopify/shopify-api';
import { ConfigService } from '@nestjs/config';
import { MuleServiceResponse } from '../mule/interfaces/mule-general.interface';
import { ShopifyCustomer } from './interfaces/shopify-customer.interface';
import { ShopifyCustomMeta } from 'src/enums/shopify-custom-meta.enum';
import { HelperService } from '../utils/helper.service';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { ShopifyProxyUpdateDto } from '../shopify-proxy/dto/shopify-proxy-auth-update.dto';
import { ShopifyStoreProperties } from './interfaces/store-properties.interface';
import * as moment from 'moment-timezone';
import { plainToInstance } from 'class-transformer';
import { ShopifyBasicDiscountCreateTransformer } from '../shopify-proxy/transformers/shopify-basic-discount-create.transformer';
import { AscentiesVoucherTransformer } from '../shopify-proxy/transformers/ascentis-voucher.transformer';
import { CustomLoggerService } from '../utils/custom-logger.service';
@Injectable()
export class ShopifyAdminApiService {
    private logger: CustomLoggerService;
    constructor(
        private configService: ConfigService,
        private customLoggerService: CustomLoggerService
    ) { 
        this.customLoggerService.setContext(ShopifyAdminApiService.name);
        this.logger = customLoggerService;
    }

    getClient(store: StoreDto) {
        this.logger.log(store.storeIntegrations.shopify.credentials.access_token);
        const client = shopifyApi({
            apiKey: this.configService.get('shopify.appProxy.clientId'),
            apiSecretKey: this.configService.get(
                'shopify.appProxy.clientSecret'
            ),
            scopes: this.configService.get('shopify.appProxy.scopes'),
            adminApiAccessToken:
                store.storeIntegrations.shopify.credentials.access_token,
            hostName: store.shop,
            hostScheme: 'https',
            apiVersion: ApiVersion.October23,
            isEmbeddedApp: false,
            logger: {
                timestamps: true,
                httpRequests: true,
                level: LogSeverity.Debug,
                log: (level, data) => {
                    const body = data.split('Body:');
                    if (body.length > 1) {
                        this.logger.debug(JSON.stringify(JSON.parse(body[1])));
                    } else {
                        this.logger.debug(data);
                    }
                }
            }
        });

        const session = new Session({
            id: '',
            shop: store.shop,
            state: '',
            isOnline: false,
            accessToken:
                store.storeIntegrations.shopify.credentials.access_token
        });
        return new client.clients.Graphql({
            session,
            apiVersion: ApiVersion.October23
        });
    }

    async searchCustomerByUsername(store: StoreDto, username: string) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        const attribute = username.includes('@') ? 'email' : 'phone';
        const limit = attribute === 'phone' ? 10 : 1;
        try {
            const data = await this.getClient(store).query({
                data: `query {
                    customers(first: ${limit}, query: "${attribute}:${username}") {
                    edges {
                        node {
                            id email displayName firstName lastName phone tags state
                            metafields(first: 20) {
                                edges {
                                  node {
                                    id
                                    key
                                    value
                                    namespace
                                  }
                                }
                            }
                            emailMarketingConsent { marketingState } 
                            smsMarketingConsent { marketingState }
                        }
                    }
                    }
                }`
            });

            if (attribute === 'phone' && data?.body['data']?.customers?.edges?.length > 1) {
                const phoneMatchedResult = data?.body['data']?.customers?.edges.find((customer) => {
                    return customer.node.phone === `${store.storeIntegrations.shopify.settings.callingCode}${username}`
                })

                result.data = (phoneMatchedResult ? phoneMatchedResult.node : null) as ShopifyCustomer;
            } else {
                result.data = data?.body['data']?.customers?.edges[0]
                    ?.node as ShopifyCustomer;
            }
            if (result.data) {
                result.data.metafields = result.data?.metafields?.edges?.map(
                    (edge) => edge.node
                );
            }
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
        }

        return result;
    }

    async getCustomer(store: StoreDto, customerId: string) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        customerId = customerId.replace('gid://shopify/Customer/', '');

        try {
            const data = await this.getClient(store).query({
                data: `query {
                    customer(id: "gid://shopify/Customer/${customerId}") {
                        id email displayName firstName lastName phone tags state emailMarketingConsent { marketingState } smsMarketingConsent { marketingState }
                        metafields(first: 20) {
                            edges {
                              node {
                                id
                                key
                                value
                                namespace
                              }
                            }
                        }
                        emailMarketingConsent { marketingState } 
                        smsMarketingConsent { marketingState }
                    }
                }`
            });

            result.data = data?.body['data']?.customer as ShopifyCustomer;

            if (result.data) {
                result.data.metafields = result.data?.metafields?.edges?.map(
                    (edge) => edge.node
                );
            }
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
        }

        return result;
    }

    async getMetafields(
        store: StoreDto,
        shopifyProxyRegisterDto: any,
        shopifyCustomer?: ShopifyCustomer
    ) {
        const metafields = [];

        if (shopifyProxyRegisterDto.gender) {
            metafields.push({
                namespace: 'custom',
                type: 'single_line_text_field',
                key: ShopifyCustomMeta.Gender,
                value: shopifyProxyRegisterDto.gender,
                id: shopifyCustomer?.metafields?.find(
                    (meta) => meta.key === ShopifyCustomMeta.Gender
                )?.id
            });
        }

        if (shopifyProxyRegisterDto.dob) {
            metafields.push({
                namespace: 'facts',
                type: 'date',
                key: ShopifyCustomMeta.DateOfBirth,
                value: shopifyProxyRegisterDto.dob,
                id: shopifyCustomer?.metafields?.find(
                    (meta) => meta.key === ShopifyCustomMeta.DateOfBirth
                )?.id
            });
        }

        if (shopifyProxyRegisterDto.membershipId) {
            metafields.push({
                namespace: 'custom',
                type: 'single_line_text_field',
                key: ShopifyCustomMeta.MembershipId,
                value: shopifyProxyRegisterDto.membershipId,
                id: shopifyCustomer?.metafields?.find(
                    (meta) => meta.key === ShopifyCustomMeta.MembershipId
                )?.id
            });
        }

        if (shopifyProxyRegisterDto.referralCode) {
            metafields.push({
                namespace: 'custom',
                type: 'single_line_text_field',
                key: ShopifyCustomMeta.ReferralCode,
                value: shopifyProxyRegisterDto.referralCode,
                id: shopifyCustomer?.metafields?.find(
                    (meta) => meta.key === ShopifyCustomMeta.ReferralCode
                )?.id
            });
        }

        if (shopifyProxyRegisterDto.membershipId) {
            const isStamps = store.storeIntegrations?.stamps?.active;
            metafields.push({
                namespace: 'custom',
                type: 'multi_line_text_field',
                key: ShopifyCustomMeta.QrCode,
                id: shopifyCustomer?.metafields?.find(
                    (meta) => meta.key === ShopifyCustomMeta.QrCode
                )?.id,
                value: await HelperService.generateQRCodeBase64(
                    isStamps
                        ? shopifyProxyRegisterDto.phone
                        : shopifyProxyRegisterDto.membershipId
                )
            });
        }

        if (shopifyProxyRegisterDto.verifiedSource) {
            metafields.push({
                namespace: 'custom',
                type: 'single_line_text_field',
                key: ShopifyCustomMeta.VerifiedSource,
                value: shopifyProxyRegisterDto.verifiedSource,
                id: shopifyCustomer?.metafields?.find(
                    (meta) => meta.key === ShopifyCustomMeta.VerifiedSource
                )?.id
            });
        }

        if (shopifyProxyRegisterDto.terms) {
            metafields.push({
                namespace: 'custom',
                type: 'boolean',
                key: ShopifyCustomMeta.Loyalty,
                value: shopifyProxyRegisterDto.terms.toString(),
                id: shopifyCustomer?.metafields?.find(
                    (meta) => meta.key === ShopifyCustomMeta.Loyalty
                )?.id
            });
        }

        if (shopifyProxyRegisterDto.loyaltyCardNo) {
            metafields.push({
                namespace: 'custom',
                type: 'single_line_text_field',
                key: ShopifyCustomMeta.LoyaltyCardNo,
                value: shopifyProxyRegisterDto.loyaltyCardNo,
                id: shopifyCustomer?.metafields?.find(
                    (meta) => meta.key === ShopifyCustomMeta.LoyaltyCardNo
                )?.id
            });
        }

        if (shopifyProxyRegisterDto.loyaltyPoints !== undefined) {
            metafields.push({
                namespace: 'custom',
                type: 'number_integer',
                key: ShopifyCustomMeta.LoyaltyPoints,
                value: shopifyProxyRegisterDto.loyaltyPoints.toString(),
                id: shopifyCustomer?.metafields?.find(
                    (meta) => meta.key === ShopifyCustomMeta.LoyaltyPoints
                )?.id
            });
        }

        if (shopifyProxyRegisterDto.membershipTierCode) {
            metafields.push({
                namespace: 'custom',
                type: 'single_line_text_field',
                key: ShopifyCustomMeta.MembershipTierCode,
                value: shopifyProxyRegisterDto.membershipTierCode,
                id: shopifyCustomer?.metafields?.find(
                    (meta) => meta.key === ShopifyCustomMeta.MembershipTierCode
                )?.id
            });
        }

        if (
            shopifyProxyRegisterDto.posSource &&
            !shopifyCustomer?.metafields?.find(
                (meta) => meta.key === ShopifyCustomMeta.Source
            )?.value
        ) {
            metafields.push({
                namespace: 'custom',
                type: 'single_line_text_field',
                key: ShopifyCustomMeta.Source,
                value: shopifyProxyRegisterDto.posSource.toString(),
                id: shopifyCustomer?.metafields?.find(
                    (meta) => meta.key === ShopifyCustomMeta.Source
                )?.id
            });
        }

        if (shopifyProxyRegisterDto.postalCode) {
            metafields.push({
                namespace: 'custom',
                type: 'single_line_text_field',
                key: ShopifyCustomMeta.PostalCode,
                value: shopifyProxyRegisterDto.postalCode,
                id: shopifyCustomer?.metafields?.find(
                    (meta) => meta.key === ShopifyCustomMeta.PostalCode
                )?.id
            });
        }

        return metafields;
    }

    async updateCustomerMetafields(
        store: StoreDto,
        shopifyCustomer: ShopifyCustomer,
        shopifyProxyRegisterDto: any
    ) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            const data = await this.getClient(store).query({
                data: {
                    query: `mutation customerUpdate($input: CustomerInput!) {
                    customerUpdate(input: $input) {
                      userErrors {
                        field
                        message
                      }
                      customer {
                        id
                        metafields(first: 20) {
                            edges {
                              node {
                                id
                                namespace
                                key
                                value
                              }
                            }
                        }
                      }
                    }
                  }`,
                    variables: {
                        input: {
                            id: shopifyCustomer.id,
                            metafields: await this.getMetafields(
                                store,
                                shopifyProxyRegisterDto,
                                shopifyCustomer
                            )
                        }
                    }
                }
            });
            result.data = data.body['data'].customerUpdate
                ?.customer as ShopifyCustomer;
            if (result.data) {
                result.data.metafields = result.data?.metafields?.edges?.map(
                    (edge) => edge.node
                );
            }

            if (data.body['data'].customerUpdate?.userErrors?.length) {
                result.message =
                    data.body['data'].customerUpdate?.userErrors[0]?.message;

                this.logger.error(`Customer Metafield update error: ${result.message}`, JSON.stringify(data.body['data'].customerUpdate?.userErrors));
            }
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
        }

        return result;
    }

    async updateSmsMarketingConsent(
        store: StoreDto,
        shopifyCustomer: ShopifyCustomer,
        smsOptIn: boolean
    ) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            const data = await this.getClient(store).query({
                data: {
                    query: `mutation customerSmsMarketingConsentUpdate($input: CustomerSmsMarketingConsentUpdateInput!) {
                        customerSmsMarketingConsentUpdate(input: $input) {
                            userErrors {
                                field
                                message
                            }
                            customer {
                                id
                                phone
                                smsMarketingConsent {
                                    marketingState
                                    marketingOptInLevel
                                    consentUpdatedAt
                                    consentCollectedFrom
                                }
                            }
                        }
                    }`,
                    variables: {
                        input: {
                            customerId: shopifyCustomer.id,
                            smsMarketingConsent: smsOptIn
                                ? {
                                    marketingState: 'SUBSCRIBED',
                                    marketingOptInLevel: 'SINGLE_OPT_IN'
                                }
                                : {
                                    marketingState: 'UNSUBSCRIBED',
                                    marketingOptInLevel: 'SINGLE_OPT_IN'
                                }
                        }
                    }
                }
            });

            result.data = data.body['data'].customerSmsMarketingConsentUpdate
                ?.customer as ShopifyCustomer;
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
        }

        return result;
    }

    async updateEmailMarketingConsent(
        store: StoreDto,
        shopifyCustomer: ShopifyCustomer,
        emailOptIn: boolean
    ) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            const data = await this.getClient(store).query({
                data: {
                    query: `mutation customerEmailMarketingConsentUpdate($input: CustomerEmailMarketingConsentUpdateInput!) {
                        customerEmailMarketingConsentUpdate(input: $input) {
                            userErrors {
                                field
                                message
                            }
                            customer {
                                id
                                email
                                emailMarketingConsent {
                                    marketingState
                                    marketingOptInLevel
                                    consentUpdatedAt
                                }
                            }
                        }
                    }`,
                    variables: {
                        input: {
                            customerId: shopifyCustomer.id,
                            emailMarketingConsent: emailOptIn
                                ? {
                                    marketingState: 'SUBSCRIBED',
                                    marketingOptInLevel: 'SINGLE_OPT_IN'
                                }
                                : {
                                    marketingState: 'UNSUBSCRIBED',
                                    marketingOptInLevel: 'SINGLE_OPT_IN'
                                }
                        }
                    }
                }
            });

            result.data = data.body['data'].customerEmailMarketingConsentUpdate
                ?.customer as ShopifyCustomer;
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
        }

        return result;
    }

    async updateCustomer(
        store: StoreDto,
        customerId: string,
        shopifyProxyUpdateDto: ShopifyProxyUpdateDto
    ) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            const data = await this.getClient(store).query({
                data: {
                    query: `mutation customerUpdate($input: CustomerInput!) {
                        customerUpdate(input: $input) {
                          userErrors {
                            field
                            message
                          }
                          customer {
                            id email displayName firstName lastName phone tags state
                            metafields(first: 20) {
                                edges {
                                  node {
                                    id
                                    key
                                    value
                                    namespace
                                  }
                                }
                            }
                            emailMarketingConsent { marketingState } 
                            smsMarketingConsent { marketingState }
                          }
                        }
                      }`,
                    variables: {
                        input: {
                            id: customerId,
                            ...shopifyProxyUpdateDto
                        }
                    }
                }
            });
            result.data = data.body['data'].customerUpdate
                ?.customer as ShopifyCustomer;

            if (data.body['data'].customerUpdate?.userErrors?.length) {
                throw new HttpException(
                    data.body['data'].customerUpdate.userErrors[0].message,
                    400
                );
            }
            if (result.data) {
                result.data.metafields = result.data?.metafields?.edges?.map(
                    (edge) => edge.node
                );
            }
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
        }

        return result;
    }

    async createMetafieldDefinition(store: StoreDto, metaDefinition: any) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            const data = await this.getClient(store).query({
                data: {
                    query: `mutation CreateMetafieldDefinition($definition: MetafieldDefinitionInput!) {
                        metafieldDefinitionCreate(definition: $definition) {
                          createdDefinition {
                            id
                            name
                          }
                          userErrors {
                            field
                            message
                            code
                          }
                        }
                      }`,
                    variables: {
                        definition: metaDefinition
                    }
                }
            });
            result.success = true;
            result.data =
                data.body['data'].metafieldDefinitionCreate?.createdDefinition;
            if (
                data.body['data'].metafieldDefinitionCreate?.userErrors?.length
            ) {
                result.message =
                    data.body[
                        'data'
                    ].metafieldDefinitionCreate?.userErrors[0]?.message;
                throw new Error(result.message);
            }
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
        }

        return result;
    }

    async enableStandardMetafieldDefinition(
        store: StoreDto,
        metaDefinition: any
    ) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            const data = await this.getClient(store).query({
                data: {
                    query: `mutation standardMetafieldDefinitionEnable($id: ID!, $ownerType: MetafieldOwnerType!, $pin: Boolean!, $visibleToStorefrontApi: Boolean!) {
                        standardMetafieldDefinitionEnable(id: $id, ownerType: $ownerType, pin: $pin, visibleToStorefrontApi: $visibleToStorefrontApi) {
                        createdDefinition {
                            name
                            key
                            namespace
                            description
                        }
                        userErrors {
                            field
                            message
                        }
                        }
                    }`,
                    variables: metaDefinition
                }
            });
            result.success = true;
            result.data =
                data.body[
                    'data'
                ].standardMetafieldDefinitionEnable?.createdDefinition;
            if (
                data.body['data'].standardMetafieldDefinitionEnable?.userErrors
                    ?.length
            ) {
                result.message =
                    data.body[
                        'data'
                    ].standardMetafieldDefinitionEnable?.userErrors[0]?.message;
                throw new Error(result.message);
            }
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
        }

        return result;
    }

    async getMetafieldDefinitions(store: StoreDto, ownerType: string) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            const metafields = [];
            let hasNextPage = true;
            let cursor = null;
            while (hasNextPage) {
                const data = await this.getClient(store).query({
                    data: {
                        query: `query {
                            metafieldDefinitions(first: 250, ownerType: ${ownerType}) {
                              edges {
                                node {
                                    id
                                    name
                                    key
                                    namespace
                                }
                              }
                            }
                        }`
                    }
                });

                metafields.push(
                    ...data.body['data'].metafieldDefinitions?.edges?.map(
                        (edge) => edge.node
                    )
                );
                hasNextPage =
                    data.body['data'].metafieldDefinitions?.pageInfo
                        ?.hasNextPage;
                cursor =
                    data.body['data'].metafieldDefinitions?.edges[
                        data.body['data'].metafieldDefinitions?.edges.length - 1
                    ]?.cursor;
            }

            result.data = metafields;
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
        }

        return result;
    }

    generateMetadefinitions(store: StoreDto) {
        const metaDefinitions = [];

        metaDefinitions.push({
            key: ShopifyCustomMeta.MembershipId,
            name: 'Membership Id',
            namespace: 'custom',
            type: 'single_line_text_field',
            description: 'Membership Id',
            ownerType: 'CUSTOMER',
            validations: [],
            pin: true
        });

        metaDefinitions.push({
            key: ShopifyCustomMeta.ReferralCode,
            name: 'Referral Code',
            namespace: 'custom',
            type: 'single_line_text_field',
            description: 'Referral Code',
            ownerType: 'CUSTOMER',
            validations: []
        });

        metaDefinitions.push({
            key: ShopifyCustomMeta.QrCode,
            name: 'QR Code',
            namespace: 'custom',
            type: 'multi_line_text_field',
            description: 'QR Code',
            ownerType: 'CUSTOMER',
            validations: []
        });

        metaDefinitions.push({
            key: ShopifyCustomMeta.VerifiedSource,
            name: 'Verified Source',
            namespace: 'custom',
            type: 'single_line_text_field',
            description: 'Verified Source',
            ownerType: 'CUSTOMER',
            validations: [
                {
                    name: 'choices',
                    value: JSON.stringify(['Email', 'Phone'])
                }
            ],
            pin: true
        });

        metaDefinitions.push({
            key: ShopifyCustomMeta.Loyalty,
            name: 'Loyalty',
            namespace: 'custom',
            type: 'boolean',
            description: 'Loyalty',
            ownerType: 'CUSTOMER',
            validations: []
        });

        metaDefinitions.push({
            key: ShopifyCustomMeta.LoyaltyCardNo,
            name: 'Loyalty Card No',
            namespace: 'custom',
            type: 'single_line_text_field',
            description: 'Loyalty Card No',
            ownerType: 'CUSTOMER',
            validations: []
        });

        metaDefinitions.push({
            key: ShopifyCustomMeta.LoyaltyPoints,
            name: 'Loyalty Points',
            namespace: 'custom',
            type: 'number_integer',
            description: 'Loyalty Points',
            ownerType: 'CUSTOMER',
            validations: [],
            pin: true
        });

        metaDefinitions.push({
            key: ShopifyCustomMeta.MembershipTierCode,
            name: 'Membership Tier Code',
            namespace: 'custom',
            type: 'single_line_text_field',
            description: 'Membership Tier Code',
            ownerType: 'CUSTOMER',
            validations: [],
            pin: true
        });

        metaDefinitions.push({
            key: ShopifyCustomMeta.DateOfBirth,
            name: 'Date of Birth',
            namespace: 'facts',
            type: 'date',
            description: 'Date of Birth',
            ownerType: 'CUSTOMER',
            validations: []
        });

        metaDefinitions.push({
            key: ShopifyCustomMeta.Source,
            name: 'Source',
            namespace: 'custom',
            type: 'single_line_text_field',
            description: 'Source',
            ownerType: 'CUSTOMER',
            validations: []
        });

        metaDefinitions.push({
            key: ShopifyCustomMeta.LoyaltyCardNo,
            name: 'Loyalty Card No',
            namespace: 'custom',
            type: 'single_line_text_field',
            description: 'Loyalty Card No',
            ownerType: 'CUSTOMER',
            validations: []
        });

        metaDefinitions.push({
            key: ShopifyCustomMeta.Gender,
            name: 'Gender',
            namespace: 'custom',
            type: 'single_line_text_field',
            description: 'Gender',
            ownerType: 'CUSTOMER',
            validations: [
                {
                    name: 'choices',
                    value: JSON.stringify(['Male', 'Female', 'Not Disclosed'])
                }
            ]
        });

        metaDefinitions.push({
            key: ShopifyCustomMeta.ClosingTime,
            name: 'Closing Time',
            namespace: 'custom',
            type: 'single_line_text_field',
            description: 'Closing Time',
            ownerType: 'LOCATION',
            validations: [],
            pin: true
        });

        metaDefinitions.push({
            key: ShopifyCustomMeta.OpeningTime,
            name: 'Opening Time',
            namespace: 'custom',
            type: 'single_line_text_field',
            description: 'Opening Time',
            ownerType: 'LOCATION',
            validations: [],
            pin: true
        });

        metaDefinitions.push({
            key: ShopifyCustomMeta.StoreCode,
            name: 'StoreCode',
            namespace: 'levi',
            type: 'single_line_text_field',
            description: 'Store code managed in X-store for inventory updation',
            ownerType: 'LOCATION',
            validations: [],
            pin: true
        });

        return metaDefinitions;
    }

    async updateCustomerTags(
        store: StoreDto,
        customerId: string,
        tags: string[]
    ) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            const data = await this.getClient(store).query({
                data: {
                    query: `mutation customerUpdate($input: CustomerInput!) {
                        customerUpdate(input: $input) {
                          userErrors {
                            field
                            message
                          }
                          customer {
                            id
                            email
                            displayName
                            firstName
                            lastName
                            phone
                            tags
                          }
                        }
                      }`,
                    variables: {
                        input: {
                            id: customerId,
                            tags
                        }
                    }
                }
            });

            result.data = data.body['data'].customerUpdate
                ?.customer as ShopifyCustomer;
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
        }

        return result;
    }

    async getShopProperties(store: StoreDto) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            const data = await this.getClient(store).query({
                data: `query {
                    shop {
                        url
                        name
                        weightUnit
                        unitSystem
                        currencyCode
                        ianaTimezone
                        taxesIncluded
                        timezoneOffset
                        myshopifyDomain
                        timezoneAbbreviation
                        checkoutApiSupported
                        timezoneOffsetMinutes
                        currencyFormats {
                            moneyFormat
                            moneyInEmailsFormat
                            moneyWithCurrencyFormat
                            moneyWithCurrencyInEmailsFormat
                        }
                    }
                }`
            });

            result.data = data?.body['data']?.shop as ShopifyStoreProperties;
            if (result.data) {
                result.data.metafields = result.data?.metafields?.edges?.map(
                    (edge) => edge.node
                );
            }
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
        }

        return result;
    }

    async getOrder(
        store: StoreDto,
        shopifyCustomer: ShopifyCustomer,
        getOrderDto: {
            orderId: string;
            username: string;
        }
    ) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        const type = getOrderDto.username?.includes('@') ? 'email' : 'phone';
        if (type === 'phone') {
            getOrderDto.username = `${store.storeIntegrations.shopify.settings.callingCode}${getOrderDto.username}`;
        }
        const orderId = getOrderDto.orderId?.replace(
            'gid://shopify/Order/',
            ''
        );
        const customerId = shopifyCustomer?.id?.replace(
            'gid://shopify/Customer/',
            ''
        );

        try {
            const data = await this.getClient(store).query({
                data: `query {
                      orders(first:1, query: "customer_id:${customerId} (name:${orderId} OR confirmation_number:${orderId})") {
                        edges {
                            node {
                                id
                                name
                                displayFinancialStatus
                                createdAt
                                displayFulfillmentStatus
                                cancelledAt
                                customAttributes {
                                    key
                                    value
                                }
                                tags
                                fulfillments(first: 10) {
                                    id
                                    displayStatus
                                    status
                                    trackingInfo (first: 10) {
                                        company
                                        number
                                        url
                                    }
                                    fulfillmentLineItems(first: 10) {
                                        edges {
                                            node {
                                                id
                                                quantity
                                                lineItem {
                                                    id
                                                    title
                                                    variant {
                                                        id
                                                        title
                                                    }
                                                }
                                            }
                                        }
                                    }   
                                }
                                customer {
                                    email
                                    firstName
                                    id
                                    lastName
                                    phone
                                }
                                shippingAddress {
                                    address1
                                    address2
                                    city
                                    company
                                    coordinatesValidated
                                    country
                                    countryCodeV2
                                    firstName
                                    formatted
                                    formattedArea
                                    lastName
                                    latitude
                                    longitude
                                    name
                                    phone
                                    province
                                    provinceCode
                                    zip
                                }
                                email
                                phone
                                lineItems(first: 10) {
                                    edges {
                                        node {
                                            id
                                            variant {
                                                id
                                                title
                                                image {
                                                    altText
                                                    id
                                                    url (transform: {
                                                        maxHeight: 120,
                                                        maxWidth: 160
                                                    })
                                                }
                                                displayName
                                                price
                                                selectedOptions {
                                                    name
                                                    value
                                                }
                                            }
                                            image {
                                                altText
                                                id
                                                url (transform: {
                                                    maxHeight: 120,
                                                    maxWidth: 160
                                                })
                                            }
                                            originalTotalSet {
                                                shopMoney {
                                                    amount
                                                    currencyCode
                                                }
                                            }
                                            originalUnitPriceSet {
                                                shopMoney {
                                                    amount
                                                    currencyCode
                                                }
                                            }
                                            quantity
                                            title
                                            variantTitle
                                        }
                                    }
                                }
                            }
                        }
                    }
                }`
            });
            result.data = data?.body['data']?.orders?.edges[0]?.node as any;

            if (result.data) {
                result.data.lineItems = result.data?.lineItems?.edges?.map(
                    (edge) => edge.node
                );
            }

            if (result.data?.customer) {
                if (
                    type === 'email' &&
                    result.data.customer.email !== getOrderDto.username
                ) {
                    throw new Error('Invalid email address');
                } else if (
                    type === 'phone' &&
                    result.data.customer.phone !== getOrderDto.username
                ) {
                    throw new Error('Invalid phone number');
                }
            }

            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
        }

        return result;
    }

    async getDiscounts(store: StoreDto) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            const data = await this.getClient(store).query({
                data: `query {
                    priceRuleDiscounts(first: 10) {
                      edges {
                        node {
                          allocationMethod
                          code
                          targetSelection
                          targetTypes
                          title
                          value {
                            ... on PriceRulePercentageValue {
                              percentage
                            }
                            ... on PriceRuleFixedAmountValue {
                              amount
                            }
                          }
                        }
                      }
                    }
                  }`
            });

            result.data = data?.body['data']?.priceRuleDiscounts?.edges?.map(
                (edge) => edge.node
            );

            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;

            throw error;
        }
    }

    async findLocations(store: StoreDto) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        const query = `active:true`;

        // fetch location address and name with pagination loop

        try {
            const locations = [];
            let hasNextPage = true;
            let cursor = null;
            while (hasNextPage) {
                const data = await this.getClient(store).query({
                    data: `query {
                        locations(first: 250, query: "${query}", after: ${cursor}) {
                          edges {
                            node {
                              id
                              name
                              address {
                                formatted
                                latitude
                                longitude
                                phone
                              }
                              shipsInventory
                              metafields(first: 5) {
                                edges {
                                  node {
                                    id
                                    key
                                    value
                                    namespace
                                  }
                                }
                              }
                            }
                          }
                          pageInfo {
                            hasNextPage
                            hasPreviousPage
                            endCursor
                          }
                        }
                      }`
                });

                for (const location of data.body['data'].locations?.edges) {
                    location.node.metafields =
                        location.node?.metafields?.edges?.map(
                            (edge) => edge.node
                        );
                    locations.push(location.node);
                }

                hasNextPage = data.body['data'].locations?.pageInfo?.hasNextPage;
                cursor = data.body['data'].locations?.pageInfo?.endCursor || null;
            }
            result.data = locations;
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;

            throw error;
        }

        return result;
    }

    async getLocationById(store: StoreDto, locationId: number) {
		const result: MuleServiceResponse = {
			data: null,
			message: '',
			success: false,
		}
		// fetch location address and name with pagination loop
		try {
			const data = await this.getClient(store).query({
				data: `query {
                  location(id: "gid://shopify/Location/${locationId}")  {
                    id
                    name
                    address {
                      address1
                      address2
                      city
                      country
                      formatted
                      phone
                      zip
                    }
                  }
                }`,
			})

			result.data = data?.body['data']?.location
			if (result.data) {
				result.data.metafields = result.data?.metafields?.edges?.map(
					(edge) => edge.node
				)
			}
			result.success = true
		} catch (error) {
			this.logger.error(error)
			result.message = error.message
		}

		return result
	}

    // Get inventoryitem which have stock and selected locationid
    async getInventoryItems(store: StoreDto, sku: string) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            const data = await this.getClient(store).query({
                data: `query {
                    inventoryItems(first: 1, query:"sku:${sku}") {
                      edges {
                        node {
                          tracked
                          inventoryLevels(first: 110) {
                            edges {
                                node {
                                    location {
                                        id
                                        name
                                        address {
                                            formatted
                                            latitude
                                            longitude
                                            phone
                                        }
                                        shipsInventory
                                        metafields(first: 3, keys:["custom.opening_time", "custom.closing_time", "levi.store_code"]) {
                                            nodes {
                                                namespace
                                                key
                                                value
                                            }
                                        }
                                    }
                                    quantities(names:["available"]) {
                                        name
                                        quantity
                                    }
                                }
                            }
                          }
                        }
                      }
                    }
                }`
            });
            
            result.data = data?.body['data']?.inventoryItems?.edges?.map(
                (edge) => edge.node
            );

            result.data[0].inventoryLevels = result.data[0]?.inventoryLevels?.edges?.map(
                (edge) => edge.node
            );

            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
        }

        return result;
    }

    async getVariant(store: StoreDto, variantId: string) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        variantId = variantId.replace('gid://shopify/ProductVariant/', '');

        try {
            const data = await this.getClient(store).query({
                data: `query {
                    productVariant(id: "gid://shopify/ProductVariant/${variantId}") {
                      id
                      title
                      sku
                    }
                  }`
            });
            result.data = data?.body['data']?.productVariant as any;

            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;
        }

        return result;
    }

    async getProductVariantById(store: StoreDto, variantId: number) {
		const result: MuleServiceResponse = {
			data: null,
			message: '',
			success: false,
		}
		try {
			const data = await this.getClient(store).query({
				data: `query {
                productVariant(id: "gid://shopify/ProductVariant/${variantId}") {
                  title
                  displayName
                  createdAt
                  price
                  compareAtPrice
                  inventoryQuantity
                  availableForSale
                  selectedOptions {
                    name
                    value
                  }
                  image {
                    url (transform: {
                        maxHeight: 120,
                        maxWidth: 160
                    })
                  }
                  product {
                    featuredImage {
                        url (transform: {
                            maxHeight: 120,
                            maxWidth: 160
                        })
                    }
                    metafields(first: 25) {
                      edges {
                        node {
                          id
                          key
                          value
                          namespace
                        }
                      }
                    }
                  }
                }
              }`,
			})

			result.data = data?.body['data']?.productVariant
			if (result.data) {
				result.data.metafields = result.data?.metafields?.edges?.map(
					(edge) => edge.node
				)
			}
			result.success = true
		} catch (error) {
			this.logger.error(error)
			result.message = error.message
		}

		return result
	}

    async searchDiscountCode(store: StoreDto, code: string) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            const data = await this.getClient(store).query({
                data: {
                    query: `query codeDiscountNodeByCode($code: String!) {
                        codeDiscountNodeByCode(code: $code) {
                            codeDiscount {
                                __typename
                                ... on DiscountCodeBasic {
                                  title
                                  startsAt
                                  endsAt
                                  appliesOncePerCustomer
                                  discountClass
                                  combinesWith {
                                      orderDiscounts
                                      productDiscounts
                                      shippingDiscounts
                                  }
                                  customerSelection {
                                    __typename
                                    ... on DiscountCustomers {
                                        customers {
                                            id
                                        }
                                    }
                                  }
                                  minimumRequirement {
                                      __typename
                                      ... on DiscountMinimumSubtotal {
                                          greaterThanOrEqualToSubtotal {
                                              amount
                                          }
                                      }
                                      ... on DiscountMinimumQuantity {
                                          greaterThanOrEqualToQuantity
                                      }
                                  }
                                  customerGets {
                                    value {
                                        __typename
                                        ... on DiscountAmount {
                                            amount {
                                                amount
                                            }
                                            appliesOnEachItem
                                        }
                                        ... on DiscountOnQuantity {
                                            quantity {
                                                quantity
                                            }
                                        }
                                        ... on DiscountPercentage {
                                            percentage
                                        }
                                    }
                                    appliesOnOneTimePurchase
                                    items {
                                      __typename
                                      ... on AllDiscountItems {
                                          allItems
                                      }
                                      ... on DiscountCollections {
                                          collections(first: 100) {
                                              nodes {
                                                  id
                                              }
                                          }
                                      }
                                      ... on DiscountProducts {
                                          productVariants(first: 100) {
                                              nodes {
                                                  id
                                              }
                                          }
                                          products(first: 100) {
                                              nodes {
                                                  id
                                              }
                                          }
                                      }
                                    }
                                }
                                }
                            }
                            id
                        }
                    }`,
                    variables: {
                        code
                    }
                }
            });

            result.data = data?.body['data']?.codeDiscountNodeByCode;

            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;

            throw error;
        }

        return result;
    }

    async createDiscountCode(store: StoreDto, discountCode: any) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            const data = await this.getClient(store).query({
                data: {
                    query: `mutation discountCodeBasicCreate($basicCodeDiscount: DiscountCodeBasicInput!) {
                        discountCodeBasicCreate(basicCodeDiscount: $basicCodeDiscount) {
                          codeDiscountNode {
                            codeDiscount {
                              ... on DiscountCodeBasic {
                                title
                                codes(first: 10) {
                                  nodes {
                                    code
                                  }
                                }
                                startsAt
                                endsAt
                                customerSelection {
                                    __typename
                                    ... on DiscountCustomers {
                                        customers {
                                            id
                                        }
                                    }
                                }
                                customerGets {
                                  value {
                                    ... on DiscountPercentage {
                                      percentage
                                    }
                                  }
                                  items {
                                    ... on AllDiscountItems {
                                      allItems
                                    }
                                  }
                                }
                                appliesOncePerCustomer
                              }
                            }
                          }
                          userErrors {
                            field
                            code
                            message
                          }
                        }
                    }`,
                    variables: {
                        basicCodeDiscount: discountCode
                    }
                }
            });
            
            result.data =
                data.body['data'].discountCodeBasicCreate?.codeDiscountNode;
            if (data.body['data'].discountCodeBasicCreate?.userErrors?.length) {
                result.message =
                    data.body[
                        'data'
                    ].discountCodeBasicCreate?.userErrors[0]?.message;
                throw new Error(result.message);
            }
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;

            throw error;
        }

        return result;
    }

    async deleteDiscountCode(store: StoreDto, discountCodeId: string) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        discountCodeId = discountCodeId.replace(
            'gid://shopify/DiscountCode/',
            ''
        );

        try {
            const data = await this.getClient(store).query({
                data: {
                    query: `mutation discountCodeDelete($id: ID!) {
                        discountCodeDelete(id: $id) {
                          deletedCodeDiscountId
                          userErrors {
                            field
                            code
                            message
                          }
                        }
                      }`,
                    variables: {
                        id: discountCodeId
                    }
                }
            });
            result.data =
                data.body['data'].discountCodeDelete?.deletedCodeDiscountId;
            if (data.body['data'].discountCodeDelete?.userErrors?.length) {
                result.message =
                    data.body[
                        'data'
                    ].discountCodeDelete?.userErrors[0]?.message;
                throw new Error(result.message);
            }
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;

            throw error;
        }

        return result;
    }

    async createWebhook(store: StoreDto, topic: string, arn: string) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            await this.getClient(store).query({
                data: {
                    query: `mutation eventBridgeWebhookSubscriptionCreate($topic: WebhookSubscriptionTopic!, $webhookSubscription: EventBridgeWebhookSubscriptionInput!) {
                        eventBridgeWebhookSubscriptionCreate(topic: $topic, webhookSubscription: $webhookSubscription) {
                          webhookSubscription {
                            id
                            topic
                            format
                            endpoint {
                              __typename
                              ... on WebhookEventBridgeEndpoint {
                                arn
                              }
                            }
                          }
                        }
                    }`,
                    variables: {
                        topic,
                        webhookSubscription: {
                            arn,
                            format: 'JSON'
                        }
                    }
                }
            });

            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;

            throw error;
        }

        return result;
    }

    async createRedTabFunctionDiscount(store: StoreDto, functionId: string) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            await this.getClient(store).query({
                data: {
                    query: `mutation discountAutomaticAppCreate($automaticAppDiscount: DiscountAutomaticAppInput!) {
                        discountAutomaticAppCreate(automaticAppDiscount: $automaticAppDiscount) {
                          userErrors {
                            field
                            message
                          }
                          automaticAppDiscount {
                            discountId
                            title
                            startsAt
                            endsAt
                            status
                            appDiscountType {
                              appKey
                              functionId
                            }
                            combinesWith {
                              orderDiscounts
                              productDiscounts
                              shippingDiscounts
                            }
                          }
                        }
                      }`,
                    variables: {
                        automaticAppDiscount: {
                            "title": "RedTab™ Loyalty Points",
                            functionId,
                            "combinesWith": {
                                "orderDiscounts": true,
                                "productDiscounts": true,
                                "shippingDiscounts": true
                            },
                            startsAt: moment().format('YYYY-MM-DDTHH:mm:ssZ')
                        }
                    }
                }
            });

            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;

            throw error;
        }

        return result;
    }

    async createPaymentCustomizationFunction(store: StoreDto, functionId: string) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            await this.getClient(store).query({
                data: {
                    query: `mutation paymentCustomizationCreate($paymentCustomization: PaymentCustomizationInput!) {
                        paymentCustomizationCreate(paymentCustomization: $paymentCustomization) {
                          paymentCustomization {
                            id
                          }
                          userErrors {
                            field
                            message
                          }
                        }
                    }`,
                    variables: {
                        paymentCustomization: {
                            enabled: true,
                            functionId,
                            title: "LevisPaymentCustomization"
                        }
                    }
                }
            });

            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;

            throw error;
        }

        return result;
    }

    async getCustomAppFunction(store: StoreDto, apiType: string) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            const data = await this.getClient(store).query({
                data: `query shopifyFunctions {
                    shopifyFunctions(first: 10, apiType: "${apiType}") {
                      nodes {
                        id
                        appKey
                      }
                    }
                }`
            });

            result.data = data.body['data'].shopifyFunctions.nodes

            if (result.data.length) {
                for (const functionNode of result.data) {
                    if (functionNode.appKey === this.configService.get('shopify.appProxy.clientId')) {
                        result.data = functionNode;
                        break;
                    } else {
                        result.data = null;
                    }
                }
            } else {
                result.data = null;
            }

            result.success = true;
        } catch (error) {
            this.logger.error(error);
            this.logger.error(JSON.stringify(error.response?.errors));
            result.message = error.message;

            throw error;
        }

        return result;
    }

    async getPaymentCustomization(store: StoreDto, functionId: string) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        try {
            const data = await this.getClient(store).query({
                data: `query paymentCustomizations {
                    paymentCustomizations(first:1, query: "functionId:${functionId}") {
                        nodes {
                            id
                            enabled
                            title
                            functionId
                        }
                    }
                }`
            });

            result.data = data.body['data'].paymentCustomizations.nodes.length ? data.body['data'].paymentCustomizations.nodes[0] : null
            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;

            throw error;
        }

        return result;
    }

    async createOrGetCustomerDiscount(
        store: StoreDto,
        shopifyCustomer: ShopifyCustomer,
        voucher: AscentiesVoucherTransformer
    ) {
        const shopifyDiscount =
            await this.searchDiscountCode(
                store,
                voucher.id
            );
        if (shopifyDiscount.success && shopifyDiscount.data) {
            return shopifyDiscount.data;
        }
        
        // Get Base Discount
        const baseDiscount =
            await this.searchDiscountCode(
                store,
                voucher.code
            );
        
        if (baseDiscount.success && baseDiscount.data?.codeDiscount) {
            const discountCode = plainToInstance(
                ShopifyBasicDiscountCreateTransformer,
                baseDiscount.data.codeDiscount,
                {
                    exposeUnsetFields: true,
                    strategy: 'excludeAll'
                }
            );
            discountCode.customerSelection.customers.add.push(
                shopifyCustomer.id
            );
            discountCode.code = voucher.id;
            discountCode.title = voucher.id;
            discountCode.appliesOncePerCustomer = true;
            const discount =
                await this.createDiscountCode(
                    store,
                    discountCode
                );

            if (discount.success && discount.data) {
                return discount.data;
            }
        }

        return null;
    }

    async deleteDiscountIfExist(
        store: StoreDto,
        shopifyCustomer: ShopifyCustomer,
        discountCode: string
    ) {
        const shopifyDiscount =
            await this.searchDiscountCode(
                store,
                discountCode
            );
        
        if (shopifyDiscount.success && shopifyDiscount.data) {
            if (
                shopifyDiscount.data.codeDiscount?.customerSelection?.customers
                    .length &&
                shopifyDiscount.data.codeDiscount?.customerSelection
                    ?.customers[0]?.id === shopifyCustomer.id
            ) {
                const discount =
                    await this.deleteDiscountCode(
                        store,
                        shopifyDiscount.data.id
                    );
                if (discount.success) {
                    this.logger.debug(
                        `delete discount code ${discountCode} for customer ${shopifyCustomer.email} success`
                    );
                    return true;
                } {
                    this.logger.debug(
                        `delete discount code ${discountCode} for customer ${shopifyCustomer.email} failed`
                    );
                    return false;
                }
            }
        }

        return true;
    }

    async getOrderMetafields(store: StoreDto, orderId: string) {
        const result: MuleServiceResponse = {
            data: null,
            message: '',
            success: false
        };

        orderId = orderId.replace('gid://shopify/Order/', '');

        try {
            const data = await this.getClient(store).query({
                data: {
                    query: `query orderMetafields($id: ID!) {
                        order(id: $id) {
                          metafields(first: 5) {
                            edges {
                              node {
                                id
                                key
                                value
                                namespace
                              }
                            }
                          }
                        }
                      }`,
                    variables: {
                        id: `gid://shopify/Order/${orderId}`
                    }
                }
            });
            result.data = data?.body['data']?.order?.metafields?.edges?.map(
                (edge) => edge.node
            );

            result.success = true;
        } catch (error) {
            this.logger.error(error);
            result.message = error.message;

            throw error;
        }

        return result;
    }
}
