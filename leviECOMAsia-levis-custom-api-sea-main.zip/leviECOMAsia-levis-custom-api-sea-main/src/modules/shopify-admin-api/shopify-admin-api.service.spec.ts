import { Test, TestingModule } from '@nestjs/testing';
import { ShopifyAdminApiService } from './shopify-admin-api.service';

describe('ShopifyAdminApiService', () => {
  let service: ShopifyAdminApiService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ShopifyAdminApiService],
    }).compile();

    service = module.get<ShopifyAdminApiService>(ShopifyAdminApiService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
