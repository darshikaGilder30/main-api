export interface ShopifyCustomer {
    id: string
    email: string
    displayName: string
    firstName: string
    lastName: string
    phone: string
    metafields: Metafield[],
    tags: string[],
    cardEnquiry?: any;
    state?: string;
  }
  
  export interface Metafield {
    id?: string
    value: string
    key: string
    namespace: string
  }
  