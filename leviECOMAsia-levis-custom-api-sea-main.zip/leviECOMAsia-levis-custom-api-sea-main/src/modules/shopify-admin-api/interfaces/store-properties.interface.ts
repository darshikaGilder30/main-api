export interface ShopifyStoreProperties {
    url?: string;
    name?: string;
    currencyCode?: string;
    ianaTimezone?: string;
    taxesIncluded?: boolean;
    timezoneOffset?: string;
    myshopifyDomain?: string;
    weightUnit?: weightUnitEnum;
    unitSystem?: unitSystemEnum;
    timezoneAbbreviation?: string;
    checkoutApiSupported?: boolean;
    timezoneOffsetMinutes?: number;
    currencyFormats?: CurrencyFormats;
}

export interface CurrencyFormats {
    moneyFormat: string;
    moneyInEmailsFormat: string;
    moneyWithCurrencyFormat: string;
    moneyWithCurrencyInEmailsFormat: string;
}

export enum unitSystemEnum {
    IMPERIAL_SYSTEM,
    METRIC_SYSTEM
}

export enum weightUnitEnum {
    GRAMS,
    KILOGRAMS,
    OUNCES,
    POUNDS
}
