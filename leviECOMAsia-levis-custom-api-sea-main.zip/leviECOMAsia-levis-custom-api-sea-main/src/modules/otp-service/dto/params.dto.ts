import { IsOptional, IsString } from 'class-validator';

export class OtpServiceParamsDto {
    @IsOptional()
    @IsString()
    otp: string;

    @IsString()
    templateCode: string;
}
