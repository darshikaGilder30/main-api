import { Module } from '@nestjs/common';
import { OtpServiceService } from './otp-service.service';
import { EmailServiceModule } from '../email-service/email-service.module';
import { LiquidTemplateService } from '../utils/liquid.service';
import { TemplatesModule } from 'src/entities/templates/templates.module';
import { SmsServiceModule } from '../sms-service/sms-service.module';
import { CustomLoggerService } from '../utils/custom-logger.service';

@Module({
    imports: [EmailServiceModule, TemplatesModule, SmsServiceModule],
    providers: [OtpServiceService, LiquidTemplateService, CustomLoggerService],
    exports: [OtpServiceService]
})
export class OtpServiceModule {}
