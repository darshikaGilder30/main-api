import { HttpException, Inject, Injectable, Logger } from '@nestjs/common';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Cache } from 'cache-manager';
import { EmailServiceService } from '../email-service/email-service.service';
import { OtpServiceParamsDto } from './dto/params.dto';
import { LiquidTemplateService } from '../utils/liquid.service';
import { TemplatesService } from 'src/entities/templates/templates.service';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { SmsServiceService } from '../sms-service/sms-service.service';
import { CustomLoggerService } from '../utils/custom-logger.service';

@Injectable()
export class OtpServiceService {
    private logger: CustomLoggerService;
    constructor(
        @Inject(CACHE_MANAGER) private cacheManager: Cache,
        private emailService: EmailServiceService,
        private liquidService: LiquidTemplateService,
        private templateService: TemplatesService,
        private smsService: SmsServiceService,
        private customLoggerService: CustomLoggerService
    ) {
        this.customLoggerService.setContext(OtpServiceService.name);
        this.logger = customLoggerService;
    }

    async send(
        store: StoreDto,
        username: string,
        params: OtpServiceParamsDto
    ): Promise<void> {
        const type = username?.includes('@') ? 'email' : 'sms';
        const emailTemplate = await this.templateService.findTemplate(
            type,
            params.templateCode,
            'en' // need to change based on country
        );

        if (!emailTemplate) {
            throw new HttpException('template not found', 404);
        }

        if (type === 'email') {
            
            this.emailService.send({
                to: username,
                from: `"Levi’s® ${store.storeIntegrations.shopify.settings.countryName}" <${store.storeIntegrations.email.credentials.fromEmail}>`,
                subject: emailTemplate?.meta['subject'],
                html: await this.liquidService.renderHtml(
                    store,
                    emailTemplate?.template,
                    params
                )
            }).then((res) => {
                this.logger.log(`email otp sent to ${username}`);
            }).catch((err) => {
                this.logger.error(`email otp failed to send to ${username}`, err);
            })
        } else {
            username = username.replace(/\D/g, '');
            this.smsService.send(store, {
                to: `${store.storeIntegrations.shopify.settings.callingCode}${username}`,
                html: await this.liquidService.renderHtml(
                    store,
                    emailTemplate?.template,
                    params
                )
            }).then((res) => {
                this.logger.log(`sms otp sent to ${username}`);
            }).catch((err) => {
                this.logger.error(`sms otp failed to send to ${username}`, JSON.stringify(err?.response?.data));
            })
        }
    }
}
