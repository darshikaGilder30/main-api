import { Injectable } from '@nestjs/common';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { CrmLoyaltyAbstract } from './crm-loyalty.abstract';
import { AscentisLoyalty } from './vendors/ascentis-loyalty.vendor';
import { StampsLoyalty } from './vendors/stamps-loyalty.vendor';

@Injectable()
export class CrmLoyaltyFactory {
    constructor(
        private readonly ascentisIntegration: AscentisLoyalty,
        private readonly stampsIntegration: StampsLoyalty
    ) {}

    getIntegration(store: StoreDto): CrmLoyaltyAbstract | undefined {
        if (store.storeIntegrations.ascentis?.active) {
            return this.ascentisIntegration;
        } else if (store.storeIntegrations.stamps?.active) {
            return this.stampsIntegration;
        } else {
            return undefined;
        }
    }
}
