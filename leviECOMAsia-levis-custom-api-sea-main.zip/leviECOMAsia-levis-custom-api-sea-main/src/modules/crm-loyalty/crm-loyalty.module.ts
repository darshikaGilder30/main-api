import { Module } from '@nestjs/common';
import { CrmLoyaltyService } from './crm-loyalty.service';
import { CrmLoyaltyFactory } from './crm-loyalty.factory';
import { AscentisLoyalty } from './vendors/ascentis-loyalty.vendor';
import { MuleModule } from '../mule/mule.module';
import { StampsLoyalty } from './vendors/stamps-loyalty.vendor';
import { StampsModule } from '../stamps/stamps.module';
import { CustomLoggerService } from '../utils/custom-logger.service';

@Module({
    imports: [MuleModule, StampsModule],
    providers: [
        CustomLoggerService,
        CrmLoyaltyService,
        CrmLoyaltyFactory,
        AscentisLoyalty,
        StampsLoyalty
    ],
    exports: [CrmLoyaltyService, CrmLoyaltyFactory]
})
export class CrmLoyaltyModule {}
