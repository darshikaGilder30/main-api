import { Expose, Transform, Type } from 'class-transformer';
import { AuthUserInfoTransformer } from 'src/modules/shopify-proxy/transformers/auth-user-info.transformer';
import { GetMemberResponse } from 'src/modules/stamps/interfaces/enquiry-member.interface';
import { StampsCardInfoTransformer } from 'src/modules/stamps/transformers/stamps-card-info.transformer';

interface TransformerInput {
    shopifyCustomerInfo: AuthUserInfoTransformer;
    stampsMember: GetMemberResponse;
}

export class StampsMemberEnquireInfoTransformer {
    @Expose()
    @Transform((value) => {
        let firstName = value.obj.shopifyCustomerInfo?.firstName;
        if (!firstName) {
            const nameParts = value.obj.user?.name?.split(' ');
            firstName = nameParts[0];
        }
        return firstName;
    })
    firstName: string;
    @Expose()
    @Transform((value) => {
        let lastName = value.obj.shopifyCustomerInfo?.lastName;
        if (!lastName) {
            const nameParts = value.obj.user?.name?.split(' ');
            lastName = nameParts.length > 1 ? nameParts.slice(1).join(' ') : '';
        }

        return lastName;
    })
    lastName: string;

    @Expose()
    @Transform((value) => {
        return value.obj.shopifyCustomerInfo?.email || value.obj.user?.email;
    })
    email: string;

    @Expose()
    @Transform((value) => {
        return value.obj.shopifyCustomerInfo?.phone || value.obj.user?.phone;
    })
    phone: string;

    @Expose()
    @Transform((value) => {
        return value.obj.user.member_ids?.length > 0
            ? value.obj.user.member_ids[0]
            : value.obj.user.id;
    })
    membershipId: string;

    @Expose()
    @Transform((value) => {
        const gender =
            value.obj.shopifyCustomerInfo?.gender ||
            (value.obj.user?.gender == 'female'
                ? 'F'
                : value.obj.user?.gender === 'male'
                ? 'M'
                : value.obj.user?.gender === 'unspecified'
                ? 'D'
                : '');
        return gender === 'F'
            ? 'Female'
            : gender === 'M'
            ? 'Male'
            : gender === 'D'
            ? 'Not Disclosed'
            : null;
    })
    gender: string;

    @Expose()
    @Transform((value) => {
        return value.obj.shopifyCustomerInfo?.dob || value.obj.user?.birthday;
    })
    dob: string;

    @Expose()
    @Transform((value) => {
        return value.obj.membership?.referral_code;
    })
    referralCode: string;

    @Expose()
    @Transform((value) => {
        return value.obj.user?.referral_code || null;
    })
    userReferralCode: string;

    @Expose()
    @Transform((value) => {
        return value.obj.shopifyCustomerInfo?.emailOptIn;
    })
    emailOptIn: boolean;

    @Expose()
    @Transform((value) => {
        return value.obj.shopifyCustomerInfo?.smsOptIn || false;
    })
    smsOptIn: boolean;

    @Expose()
    @Transform((value) => {
        return value.obj.shopifyCustomerInfo?.tags || ['no_password'];
    })
    tags: string[];
}

export class StampsMemberEnquireTransformer {
    @Expose({
        name: 'ReturnStatus'
    })
    returnStatus: number;

    @Type(() => StampsMemberEnquireInfoTransformer)
    @Expose({
        name: 'member'
    })
    memberInfo: StampsMemberEnquireInfoTransformer;

    @Type(() => StampsCardInfoTransformer)
    @Expose({
        name: 'cardInfo'
    })
    cardInfo: StampsCardInfoTransformer;
}
