import { Expose, Transform, Type } from 'class-transformer';
import { HelperService } from 'src/modules/utils/helper.service';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { AuthUserInfoTransformer } from 'src/modules/shopify-proxy/transformers/auth-user-info.transformer';
import { AscentiesCardInfoTransformer } from 'src/modules/shopify-proxy/transformers/ascentis-card-info.transformer';

export class AscentisMemberEnquireInfoTransformer {
    @Expose()
    @Transform((value) => {
        return (
            value.obj.shopifyCustomerInfo?.firstName ||
            value.obj.member.DynamicFieldLists.find(
                (field) => field.Name === 'FirstName'
            )?.ColValue
        );
    })
    firstName: string;

    @Expose()
    @Transform((value) => {
        return (
            value.obj.shopifyCustomerInfo?.lastName ||
            value.obj.member.DynamicFieldLists.find(
                (field) => field.Name === 'LastName'
            )?.ColValue
        );
    })
    lastName: string;

    @Expose()
    @Transform((value) => {
        return (
            value.obj.shopifyCustomerInfo?.email ||
            value.obj.member.Email
        );
    })
    email: string;

    @Expose()
    @Transform((value) => {
        const shopifyCustomerInfo: AuthUserInfoTransformer =
            value.obj.shopifyCustomerInfo;
        const member = value.obj.member;
        const store: StoreDto = value.obj.store;

        return (
            shopifyCustomerInfo?.phone ||
            (member.MobileNo
                ? member.MobileNo.replaceAll(
                      store.storeIntegrations.shopify.settings.callingCode,
                      ''
                  )
                : null)
        );
    })
    phone: string;

    @Expose()
    @Transform((value) => {
        return value.obj.member.MemberID;
    })
    membershipId: string;

    @Expose()
    @Transform((value) => {
        const shopifyCustomerInfo: AuthUserInfoTransformer =
            value.obj.shopifyCustomerInfo;
        const member = value.obj.member;

        return shopifyCustomerInfo?.gender || member.Gender === 'F'
            ? 'Female'
            : member.Gender === 'M'
            ? 'Male'
            : member.Gender === 'D'
            ? 'Not Disclosed'
            : '';
    })
    gender: string;

    @Expose()
    @Transform((value) => {
        const shopifyCustomerInfo: AuthUserInfoTransformer =
            value.obj.shopifyCustomerInfo;
        const member = value.obj.member;
        const store: StoreDto = value.obj.store;

        return shopifyCustomerInfo?.dob || member.DOB
            ? HelperService.parseAcentiesData(
                  member.DOB,
                  'YYYY-MM-DD',
                  store.storeIntegrations.shopify.settings.timezone
              )
            : null;
    })
    dob: string;

    @Expose()
    @Transform((value) => {
        return value.obj.member.ReferralCode;
    })
    referralCode: string;

    @Expose()
    @Transform((value) => {
        const shopifyCustomerInfo: AuthUserInfoTransformer =
            value.obj.shopifyCustomerInfo;
        const member = value.obj.member;
        return shopifyCustomerInfo?.emailOptIn
            ? true
            : member.MailingLists?.length && member.MailingLists[0].Name !== ''
            ? true
            : false;
    })
    emailOptIn: boolean;

    @Expose()
    @Transform((value) => {
        const shopifyCustomerInfo: AuthUserInfoTransformer =
            value.obj.shopifyCustomerInfo;
        const member = value.obj.member;
        return shopifyCustomerInfo?.smsOptIn
            ? true
            : member.DynamicColumnLists?.length &&
              member.DynamicColumnLists.find((col) => col.Name === 'NotifySMS')
                  ?.ColValue === 'True'
            ? true
            : false;
    })
    smsOptIn: boolean;

    @Expose()
    @Transform((value) => {
        return value.obj.shopifyCustomerInfo?.tags || ['no_password'];
    })
    tags: string[];
}

export class AscentisMemberEnquireTransformer {
    @Expose({
        name: 'ReturnStatus'
    })
    returnStatus: number;

    @Type(() => AscentisMemberEnquireInfoTransformer)
    @Expose({
        name: 'member'
    })
    memberInfo: AscentisMemberEnquireInfoTransformer;

    @Type(() => AscentiesCardInfoTransformer)
    @Expose()
    cardInfo: AscentiesCardInfoTransformer
}
