import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { ShopifyCustomer } from '../shopify-admin-api/interfaces/shopify-customer.interface';
import { AscentisMemberEnquireTransformer } from './transformers/ascentis-member-enquiry.transformer';
import { ShopifyProxyRegisterDto } from '../shopify-proxy/dto/shopify-proxy-auth-register.dto';
import { ShopifyProxyUpdateDto } from '../shopify-proxy/dto/shopify-proxy-auth-update.dto';
import { StampsMemberEnquireTransformer } from './transformers/stamps-member-enquiry.transformer';

export abstract class CrmLoyaltyAbstract {
    abstract memberEnquiry(
        store: StoreDto,
        username: string,
        shopifyCustomer?: ShopifyCustomer
    ): Promise<AscentisMemberEnquireTransformer | StampsMemberEnquireTransformer>;

    abstract memberRegister(
        store: StoreDto,
        shopifyProxyRegisterDto: ShopifyProxyRegisterDto
    ): Promise<string>;

    abstract memberUpdate(
        store: StoreDto,
        shopifyProxyUpdateDto: ShopifyProxyUpdateDto
    ): Promise<string>;
}
