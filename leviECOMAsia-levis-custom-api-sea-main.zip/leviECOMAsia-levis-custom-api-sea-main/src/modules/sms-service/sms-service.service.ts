import { HttpService } from '@nestjs/axios';
import { Injectable } from '@nestjs/common';
import { emailPayloadDto } from '../email-service/dto/email-payload.dto';
import { lastValueFrom } from 'rxjs';
import * as formData from 'form-data';
import { StoreDto } from 'src/entities/stores/dto/stores.dto';
import { CustomLoggerService } from '../utils/custom-logger.service';

@Injectable()
export class SmsServiceService {
    private logger: CustomLoggerService;
    constructor(
        private httpService: HttpService, 
        private customLoggerService: CustomLoggerService
    ) {
        this.customLoggerService.setContext(SmsServiceService.name);
        this.logger = customLoggerService;
    }

    async send(store: StoreDto, smsPayload: emailPayloadDto): Promise<any> {
        const payload = new formData();
        payload.append('From', store.storeIntegrations.sms.credentials.exotelFrom);
        payload.append('To', smsPayload.to);
        payload.append('Body', smsPayload.html);

        return (await lastValueFrom(
            this.httpService.post(`https://api.exotel.com/v1/Accounts/${store.storeIntegrations.sms.credentials.exotelAccountSid}/Sms/send.json`, payload, {
                auth: {
                    username: store.storeIntegrations.sms.credentials.exotelAuthKey,
                    password: store.storeIntegrations.sms.credentials.exotelAuthToken
                },
                headers: {
                    'Content-Type': `multipart/form-data; boundary=${payload.getBoundary()}`,
                }
            })
        ));
    }
}
