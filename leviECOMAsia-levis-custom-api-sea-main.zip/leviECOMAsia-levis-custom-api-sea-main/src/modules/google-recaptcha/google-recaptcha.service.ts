import { HttpService } from '@nestjs/axios';
import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { lastValueFrom } from 'rxjs';
import { CustomLoggerService } from '../utils/custom-logger.service';
import * as formData from 'form-data';

@Injectable()
export class GoogleRecaptchaService {
    private logger: CustomLoggerService;
    constructor(
        private readonly httpService: HttpService,
        private readonly configService: ConfigService,
        private readonly customLoggerService: CustomLoggerService
    ) {
        this.customLoggerService.setContext(GoogleRecaptchaService.name);
        this.logger = customLoggerService;
    }

    async verifyCaptcha(token: string): Promise<boolean> {
        const payload = new formData();
        payload.append('secret', this.configService.get('google.recaptcha.secret'));
        payload.append('response', token);
        try {
            const response = await lastValueFrom(
                this.httpService.post('/siteverify', payload)
            );

            console.log(response.data);

            return response.data?.success;
        } catch (error) {
            this.logger.error(error);
        }

        return false;
    }
}
