import { Module } from '@nestjs/common';
import { GoogleRecaptchaService } from './google-recaptcha.service';
import { HttpModule } from '@nestjs/axios';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { CustomLoggerService } from '../utils/custom-logger.service';

@Module({
  imports: [
    HttpModule.registerAsync({
      imports: [ConfigModule],
      useFactory: async (configService) => ({
          timeout: 120000,
          baseURL: configService.get('google.recaptcha.url')
      }),
      inject: [ConfigService]
  })
  ],
  providers: [GoogleRecaptchaService, CustomLoggerService],
  exports: [GoogleRecaptchaService]
})
export class GoogleRecaptchaModule {}
