import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { HttpModule } from '@nestjs/axios';
import { CacheModule } from '@nestjs/cache-manager';
import { ShopifyProxyModule } from './modules/shopify-proxy/shopify-proxy.module';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { ShopifyOauthModule } from './modules/shopify-oauth/shopify-oauth.module';
import configuration from './configuration';
import { RedisClientOptions } from 'redis';
import { StoresModule } from './entities/stores/stores.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { StoreIntegrationsModule } from './entities/store-integrations/store-integrations.module';
import { I18nModule } from 'nestjs-i18n';
import * as path from 'path';
import { MuleModule } from './modules/mule/mule.module';
import { IsReferralCodeValid } from './validation-rules/referral-code/referral-code.decorator';
import { ioRedisStore } from '@tirke/node-cache-manager-ioredis';
import { CacheHelperModule } from './modules/utils/cache/cache-helper.module';
import { LineModule } from './modules/line/line.module';
import { CustomAcceptLanguageResolver } from './modules/utils/cutom-accept-lang.resolver';
import { StampsModule } from './modules/stamps/stamps.module';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { AuditLogModule } from './entities/audit-logs/audit-log.module';
import { CustomLoggerService } from './modules/utils/custom-logger.service';

@Module({
    imports: [
        ConfigModule.forRoot({
            isGlobal: true,
            load: [configuration]
        }),
        CacheModule.registerAsync<RedisClientOptions>({
            imports: [ConfigModule],
            useFactory: (configService: ConfigService) => ({
                store: ioRedisStore,
                ...(configService.get('redis.cluster')
                    ? {
                          clusterConfig: {
                              nodes: [
                                  {
                                      host: configService.get('redis.host'),
                                      port: 6379
                                  }
                              ]
                          }
                          //   redisOptions: {
                          //     tls: true,
                          //   }
                      }
                    : {
                          url: configService.get('redis.url')
                      })
            }),
            inject: [ConfigService],
            isGlobal: true
        }),
        TypeOrmModule.forRootAsync({
            imports: [ConfigModule],
            useFactory: (configService: ConfigService) => ({
                type: 'postgres',
                host: configService.get('database.host'),
                port: +configService.get<number>('database.port'),
                username: configService.get('database.username'),
                password: configService.get('database.password'),
                database: configService.get('database.name'),
                entities: [__dirname + '/**/*.entity{.ts,.js}'],
                synchronize: true, // Don't use this option for prod mode
                keepConnectionAlive: true,
                timezone: 'UTC',
                ssl: configService.get('database.ssl'),
                extra: configService.get('database.ssl')
                    ? {
                          ssl: {
                              rejectUnauthorized: false
                          }
                      }
                    : null,
                autoLoadEntities: true
            }),
            inject: [ConfigService]
        }),
        I18nModule.forRoot({
            fallbackLanguage: 'en',
            loaderOptions: {
                path: path.join(__dirname, '/i18n/'),
                watch: true
            },
            resolvers: [CustomAcceptLanguageResolver],
            typesOutputPath: path.join(
                __dirname,
                '../src/generated/i18n.generated.ts'
            )
        }),
        HttpModule,
        CacheHelperModule,
        StoresModule,
        ShopifyProxyModule,
        ShopifyOauthModule,
        StoreIntegrationsModule,
        MuleModule,
        LineModule,
        StampsModule,
        EventEmitterModule.forRoot(),
        AuditLogModule
    ],
    controllers: [AppController],
    providers: [
        AppService,
        IsReferralCodeValid,
        CustomLoggerService
    ],
    exports: [
        CustomLoggerService,
        IsReferralCodeValid
    ]
})
export class AppModule {}
