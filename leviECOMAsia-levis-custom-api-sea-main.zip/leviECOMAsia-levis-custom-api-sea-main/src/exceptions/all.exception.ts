import {
    ExceptionFilter,
    Catch,
    ArgumentsHost,
    HttpException,
    HttpStatus,
    BadRequestException
} from '@nestjs/common';
import { HttpAdapterHost } from '@nestjs/core';
import { I18nContext, I18nValidationException } from 'nestjs-i18n';
import { LineResponseMessageCode } from 'src/enums/line-response-message-code.enum';
import { I18nTranslations } from 'src/generated/i18n.generated';

@Catch()
export class AllExceptionsFilter implements ExceptionFilter {
    constructor(
        private readonly httpAdapterHost: HttpAdapterHost
    ) {}

    catch(exception: any, host: ArgumentsHost): void {
        const { httpAdapter } = this.httpAdapterHost;
        const request = host.switchToHttp().getRequest();
        const i18n = I18nContext.current<I18nTranslations>(host);

        if (request.storeIntegrationAccess || request.url.includes('line-app')) {
            if (
                exception instanceof BadRequestException ||
                exception instanceof I18nValidationException
            ) {
                const response = host.switchToHttp().getResponse();
                response.status(422).json({
                    messageCode: LineResponseMessageCode.InvalidData,
                    Message: i18n?.translate('exception.validation_error'),
                    ErrorCode: 422,
                    errors: exception['errors'].map((error) => {
                        return {
                            property: error.property,
                            constraints: [Object.entries(error.constraints).map(
                                ([key, value]: any) => {
                                    return {
                                        key,
                                        message: i18n?.translate(
                                            value.split('|')[0],
                                            {
                                                args: value.split('|').slice(1)
                                            }
                                        )
                                    };
                                }
                            )[0]]
                        };
                    })
                });

                return;
            }

            const ctx = host.switchToHttp();

            const httpStatus =
                exception instanceof HttpException
                    ? exception.getStatus()
                    : HttpStatus.INTERNAL_SERVER_ERROR;

            const responseBody = {
                messageCode: LineResponseMessageCode.SomethigWentWrong,
                Message:
                    exception instanceof HttpException && exception.getResponse()['message']
                        ? exception.getResponse()['message']
                        : exception?.message,
                ErrorCode: 500,
            };
            httpAdapter.reply(ctx.getResponse(), responseBody, httpStatus);
        } else {  
            if (
                exception instanceof BadRequestException ||
                exception instanceof I18nValidationException
            ) {
                const response = host.switchToHttp().getResponse();
                const message = exception.getResponse();
                response.status(422).json({
                    data: null,
                    message: i18n.translate('exception.validation_error'),
                    errors: exception['errors'].map((error) => {
                        return {
                            property: error.property,
                            constraints: [Object.entries(error.constraints).map(
                                ([key, value]: any) => {
                                    let args = value.split('|').slice(1);
                                    if (args?.length && args[0]?.startsWith('{')) {
                                        args = JSON.parse(args[0])?.args;
                                    }
                                    return {
                                        key,
                                        message: i18n.translate(
                                            value.split('|')[0],
                                            {
                                                args
                                            }
                                        )
                                    };
                                }
                            )[0]]
                        };
                    })
                });

                return;
            }

            const ctx = host.switchToHttp();

            const httpStatus =
                exception instanceof HttpException
                    ? exception.getStatus()
                    : HttpStatus.INTERNAL_SERVER_ERROR;

            const responseBody = {
                timestamp: new Date().toISOString(),
                message:
                    exception instanceof HttpException && exception.getResponse()
                        ? exception.getResponse()
                        : exception?.message,
                data: null
            };
            if (!(exception instanceof HttpException)) {
                console.error(exception);
            }
            httpAdapter.reply(ctx.getResponse(), responseBody, httpStatus);
        }
    }
}
