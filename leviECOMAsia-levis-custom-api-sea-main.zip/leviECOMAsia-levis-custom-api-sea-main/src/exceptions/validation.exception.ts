import {
    ArgumentsHost,
    BadRequestException,
    Catch,
    ExceptionFilter
} from '@nestjs/common';

@Catch()
export class ValidationFilter<T> implements ExceptionFilter {
    catch(exception: T, host: ArgumentsHost) {
        if (exception instanceof BadRequestException) {
            const response = host.switchToHttp().getResponse();
            const message = exception.getResponse()['message'].join('\n');
            response
                .status(422)
                .json({
                    data: null,
                    message
                });
        }
    }
}
